"""Рендер спрайтов для NYKLIMA SNAKE на RTX 3050 через CUDA (CuPy).

Запуск: py -3.11 -B tools/render_sprites.py
Создаёт build\sprite_food.bmp, sprite_body.bmp, sprite_head.bmp (64x64, 24bpp).
Скрипт сборки встраивает их в FAT16-образ, игра грузит как текстуры NGL.
"""

from __future__ import annotations

from pathlib import Path
import struct

import cupy as cp

KERNEL = r"""
extern "C" __global__
void sprite_food(unsigned char* out, int size) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int n = gridDim.x * blockDim.x;
    for (int idx = i; idx < size * size; idx += n) {
        int px = idx % size, py = idx / size;
        float fx = (2.0f * px - size) / (float)size;
        float fy = (2.0f * py - size) / (float)size;
        float d = sqrtf(fx * fx + fy * fy);
        float glow = fmaxf(0.0f, 1.0f - d);
        float core = fmaxf(0.0f, 1.0f - d * 3.0f);
        float ring = fmaxf(0.0f, 1.0f - fabsf(d - 0.55f) * 6.0f);
        out[idx * 3 + 0] = (unsigned char)fminf(255.0f, 60 * glow + 235 * core + 120 * ring);
        out[idx * 3 + 1] = (unsigned char)fminf(255.0f, 18 * glow + 80 * core + 30 * ring);
        out[idx * 3 + 2] = (unsigned char)fminf(255.0f, 18 * glow + 55 * core + 25 * ring);
    }
}

extern "C" __global__
void sprite_body(unsigned char* out, int size) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int n = gridDim.x * blockDim.x;
    for (int idx = i; idx < size * size; idx += n) {
        int px = idx % size, py = idx / size;
        float fx = (2.0f * px - size) / (float)size;
        float fy = (2.0f * py - size) / (float)size;
        float d = sqrtf(fx * fx + fy * fy);
        float scale = (sinf(px * 0.55f) + 1.0f) * 0.5f;
        float body = fmaxf(0.0f, 1.0f - d * 1.15f);
        float shine = fmaxf(0.0f, 1.0f - sqrtf((fx + 0.25f) * (fx + 0.25f) + (fy + 0.3f) * (fy + 0.3f)) * 2.2f);
        out[idx * 3 + 0] = (unsigned char)(20 * body + 40 * shine);
        out[idx * 3 + 1] = (unsigned char)(fminf(255.0f, (120 + 70 * scale) * body + 200 * shine));
        out[idx * 3 + 2] = (unsigned char)(fminf(255.0f, (60 + 40 * scale) * body + 160 * shine));
    }
}

extern "C" __global__
void sprite_head(unsigned char* out, int size) {
    int i = blockIdx.x * blockDim.x + threadIdx.x;
    int n = gridDim.x * blockDim.x;
    for (int idx = i; idx < size * size; idx += n) {
        int px = idx % size, py = idx / size;
        float fx = (2.0f * px - size) / (float)size;
        float fy = (2.0f * py - size) / (float)size;
        float d = sqrtf(fx * fx + fy * fy);
        float body = fmaxf(0.0f, 1.0f - d * 1.1f);
        float core = fmaxf(0.0f, 1.0f - d * 2.6f);
        float eye_l = fmaxf(0.0f, 1.0f - sqrtf((fx + 0.28f) * (fx + 0.28f) + (fy + 0.22f) * (fy + 0.22f)) * 7.0f);
        float eye_r = fmaxf(0.0f, 1.0f - sqrtf((fx - 0.28f) * (fx - 0.28f) + (fy + 0.22f) * (fy + 0.22f)) * 7.0f);
        float eye = fmaxf(eye_l, eye_r);
        out[idx * 3 + 0] = (unsigned char)fminf(255.0f, 25 * body + 60 * core);
        out[idx * 3 + 1] = (unsigned char)fminf(255.0f, (150 + 105 * core) * body);
        out[idx * 3 + 2] = (unsigned char)fminf(255.0f, (190 + 65 * core) * body + 255 * eye * 0.6f);
    }
}
"""


def save_bmp(path: Path, size: int, rgb: bytes) -> None:
    row_size = size * 3
    padding = (4 - (row_size % 4)) % 4
    pixel_size = (row_size + padding) * size
    file_size = 54 + pixel_size
    header = (
        b"BM"
        + struct.pack("<IHHI", file_size, 0, 0, 54)
        + struct.pack("<IIIHHIIIIII", 40, size, size, 1, 24, 0, pixel_size, 2835, 2835, 0, 0)
    )
    rows = []
    for y in range(size):
        row = rgb[y * row_size : (y + 1) * row_size]
        rows.append(row + b"\x00" * padding)
    path.write_bytes(header + b"".join(reversed(rows)))


def main() -> None:
    size = 64
    out = cp.zeros(size * size * 3, dtype=cp.uint8)
    blocks, threads = 8, 512
    out_dir = Path(__file__).resolve().parent.parent / "build"
    out_dir.mkdir(exist_ok=True)

    sprites = {
        "sprite_food.bmp": cp.RawKernel(KERNEL, "sprite_food"),
        "sprite_body.bmp": cp.RawKernel(KERNEL, "sprite_body"),
        "sprite_head.bmp": cp.RawKernel(KERNEL, "sprite_head"),
    }
    for name, kernel in sprites.items():
        kernel((blocks,), (threads,), (out, cp.int32(size)))
        host = cp.asnumpy(out).tobytes()
        save_bmp(out_dir / name, size, host)
        print(f"rendered on {cp.cuda.runtime.getDeviceProperties(0)['name']}: {name}")


if __name__ == "__main__":
    main()
