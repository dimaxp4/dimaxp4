param([Parameter(Mandatory)][string]$Root, [Parameter(Mandatory)][string]$Output)
$ErrorActionPreference = 'Stop'
$sectorSize = 512; $sectors = 32768; $volumeStart = 2048; $volumeSectors = $sectors - $volumeStart
$spc = 1; $reserved = 1; $fats = 2; $spf = 129; $rootEntries = 512; $rootSectors = 32
$image = [byte[]]::new($sectorSize * $sectors)
$volumeOffset = $volumeStart * $sectorSize
function U16([int]$at,[int]$v){ $at += $script:volumeOffset; [void]($image[$at]=[byte]($v -band 0xff)); [void]($image[$at+1]=[byte](($v -shr 8) -band 0xff)) }
function U32([int]$at,[uint32]$v){ $at += $script:volumeOffset; for($i=0;$i -lt 4;$i++){ [void]($image[$at+$i]=[byte](($v -shr (8*$i)) -band 0xff)) } }
function Ascii([int]$at,[string]$s){ [System.Text.Encoding]::ASCII.GetBytes($s).CopyTo($image,$script:volumeOffset+$at) }

# MBR with one active FAT16 partition covering the volume.
$image[446] = 0x80
$image[446+4] = 0x06
for($i=0;$i -lt 4;$i++){ $image[446+8+$i] = [byte](($volumeStart -shr (8*$i)) -band 0xff) }
for($i=0;$i -lt 4;$i++){ $image[446+12+$i] = [byte](($volumeSectors -shr (8*$i)) -band 0xff) }
$image[510] = 0x55; $image[511] = 0xaa

# FAT16 boot sector at the partition start.
$image[$volumeOffset] = 0xeb; $image[$volumeOffset+1] = 0x3c; $image[$volumeOffset+2] = 0x90
Ascii 3 'NYKLIMA '; U16 11 $sectorSize; $image[$volumeOffset+13]=$spc; U16 14 $reserved; $image[$volumeOffset+16]=$fats; U16 17 $rootEntries; U16 19 $volumeSectors; $image[$volumeOffset+21]=0xf8; U16 22 $spf; U16 24 32; U16 26 64; U32 28 $volumeStart; $image[$volumeOffset+36]=0x80; $image[$volumeOffset+38]=0x29; U32 39 0x31474b4e; Ascii 43 'NYKLIMA OS '; Ascii 54 'FAT16   '; $image[$volumeOffset+510]=0x55; $image[$volumeOffset+511]=0xaa
$fatOffset = $reserved*$sectorSize; U16 $fatOffset 0xfff8; U16 ($fatOffset+2) 0xffff
$dataSector = $reserved + $fats*$spf + $rootSectors; $nextCluster = 2
function Set-Fat([int]$cluster,[int]$value) { foreach($fat in 0..($fats-1)){ U16 (($reserved+$fat*$spf)*$sectorSize+$cluster*2) $value } }
function Allocate([int]$bytes) { $script:first=$script:nextCluster; $count=[Math]::Max(1,[Math]::Ceiling($bytes / ($sectorSize*$spc))); for($i=0;$i -lt $count;$i++){ $cluster=$script:nextCluster++; Set-Fat $cluster ($(if($i -eq $count-1){0xffff}else{$cluster+1})) }; return $script:first }
function ClusterOffset([int]$cluster) { return (($dataSector + ($cluster-2)*$spc)*$sectorSize) }
function Entry([int]$at,[string]$name,[byte]$attr,[int]$cluster,[int]$size) { Ascii $at $name.PadRight(11,' '); $image[$volumeOffset+$at+11]=$attr; U16 ($at+26) $cluster; U32 ($at+28) $size }
function LfnEntry([int]$at,[string]$longName,[string]$shortName) {
    $short = [System.Text.Encoding]::ASCII.GetBytes($shortName.PadRight(11,' ')); [byte]$sum=0
    foreach($b in $short) { $sum = [byte]((((($sum -band 1) -shl 7) + ($sum -shr 1)) + $b) -band 0xff) }
    $image[$volumeOffset+$at]=0x41; $image[$volumeOffset+$at+11]=0x0f; $image[$volumeOffset+$at+12]=0; $image[$volumeOffset+$at+13]=$sum; U16 ($at+26) 0
    $chars = @(); foreach($c in $longName.ToCharArray()){ $chars += [int][char]$c }; $chars += 0; while($chars.Count -lt 13){ $chars += 0xffff }
    $offsets = @(1,3,5,7,9,14,16,18,20,22,24,28,30); for($i=0;$i -lt 13;$i++){ U16 ($at+$offsets[$i]) $chars[$i] }
}
function PutFile([string]$path) { $bytes=[IO.File]::ReadAllBytes($path); $cluster=Allocate $bytes.Length; $bytes.CopyTo($image,($volumeOffset + (ClusterOffset $cluster))); return @{Cluster=$cluster; Size=$bytes.Length} }
$efi=Allocate $sectorSize; $boot=Allocate $sectorSize
$bootx=PutFile "$Root\build\BOOTX64.EFI"; $kernel=PutFile "$Root\build\kernel.elf"; $readme=PutFile "$Root\boot\README.TXT"
$rootAt=($reserved+$fats*$spf)*$sectorSize; Entry $rootAt 'EFI' 0x10 $efi 0; Entry ($rootAt+32) 'BOOT' 0x10 $boot 0; Entry ($rootAt+64) 'KERNEL  ELF' 0x20 $kernel.Cluster $kernel.Size; Entry ($rootAt+96) 'README  TXT' 0x20 $readme.Cluster $readme.Size
# Первая свободная запись корня: EFI/BOOT/KERNEL/README заняли слоты 0-3.
# Дырка из нулевых записей недопустима — нулевой байт имени означает конец
# каталога, и сканер FS не увидит файлы дальше дырки.
$nextEntry = 128
$framePath = Join-Path $Root 'build\g1frame.bmp'
if (Test-Path $framePath) { $frame = PutFile $framePath; Entry ($rootAt+$nextEntry) 'G1FRAME BMP' 0x20 $frame.Cluster $frame.Size; $nextEntry += 32 }
$gamePath = Join-Path $Root 'build\game_snake.elf'
if (Test-Path $gamePath) { $game = PutFile $gamePath; Entry ($rootAt+$nextEntry) 'SNAKE   ELF' 0x20 $game.Cluster $game.Size; $nextEntry += 32 }
foreach ($sprite in @('sprite_food', 'sprite_body', 'sprite_head')) {
    $p = Join-Path $Root "build\$sprite.bmp"
    if (Test-Path $p) { $s = PutFile $p; $short = $sprite -replace '^sprite_', ''; $name = ($short.ToUpper().PadRight(8)) + 'BMP'; Entry ($rootAt+$nextEntry) $name 0x20 $s.Cluster $s.Size; $nextEntry += 32 }
}
$efiAt=ClusterOffset $efi; Entry $efiAt '.          ' 0x10 $efi 0; Entry ($efiAt+32) '..         ' 0x10 0 0; Entry ($efiAt+64) 'BOOT' 0x10 $boot 0
$bootAt=ClusterOffset $boot; Entry $bootAt '.          ' 0x10 $boot 0; Entry ($bootAt+32) '..         ' 0x10 $efi 0; Entry ($bootAt+64) 'BOOTX64 EFI' 0x20 $bootx.Cluster $bootx.Size
[IO.File]::WriteAllBytes($Output,$image)
Write-Host "Created partitioned UEFI FAT16 disk: $Output"