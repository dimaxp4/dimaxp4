/* Экран загрузки NYKLIMA OS: рисуем напрямую в GOP framebuffer.
   Отладочные значения при этом уходят в COM1, а не на экран. */

#include "splash.h"

#define FONT_W 5
#define FONT_H 7

typedef struct {
    uint32_t *base;
    uint64_t w, h, pitch_px;
} surf_t;

static surf_t s;

/* Палитра — та же, что на рабочем столе ядра (wm.c/fbdraw.h). */
#define C_BG_HI   0x00101626u
#define C_BG_LO   0x00323a48u
#define C_ACCENT  0x0040d9ffu
#define C_TEXT    0x00d6e4f0u
#define C_MUTED   0x008aa4bdu
#define C_TRACK   0x00162238u

static void px(uint64_t x, uint64_t y, uint32_t c) {
    if (x >= s.w || y >= s.h) return;
    s.base[y * s.pitch_px + x] = c;
}

static void fill(uint64_t x, uint64_t y, uint64_t w, uint64_t h, uint32_t c) {
    for (uint64_t yy = 0; yy < h; ++yy)
        for (uint64_t xx = 0; xx < w; ++xx) px(x + xx, y + yy, c);
}

static void rect(uint64_t x, uint64_t y, uint64_t w, uint64_t h, uint32_t c) {
    fill(x, y, w, 1, c);
    fill(x, y + h - 1, w, 1, c);
    fill(x, y, 1, h, c);
    fill(x + w - 1, y, 1, h, c);
}

/* Тот же глиф 5x7, что в fbdraw.c, — визуальная преемственность со столом. */
static const uint8_t font[45][FONT_H] = {
    {0x1e,0x11,0x11,0x11,0x11,0x11,0x1e},{0x04,0x0c,0x04,0x04,0x04,0x04,0x0e},
    {0x1e,0x01,0x01,0x1e,0x10,0x10,0x1f},{0x1e,0x01,0x01,0x0e,0x01,0x01,0x1e},
    {0x11,0x11,0x11,0x1f,0x01,0x01,0x01},{0x1f,0x10,0x10,0x1e,0x01,0x01,0x1e},
    {0x0e,0x10,0x10,0x1e,0x11,0x11,0x0e},{0x1f,0x01,0x02,0x04,0x08,0x08,0x08},
    {0x0e,0x11,0x11,0x0e,0x11,0x11,0x0e},{0x0e,0x11,0x11,0x0f,0x01,0x01,0x0e},
    {0x0e,0x11,0x11,0x1f,0x11,0x11,0x11},{0x1e,0x11,0x11,0x1e,0x11,0x11,0x1e},
    {0x0e,0x11,0x10,0x10,0x10,0x11,0x0e},{0x1e,0x11,0x11,0x11,0x11,0x11,0x1e},
    {0x1f,0x10,0x10,0x1e,0x10,0x10,0x1f},{0x1f,0x10,0x10,0x1e,0x10,0x10,0x10},
    {0x0e,0x11,0x10,0x17,0x11,0x11,0x0e},{0x11,0x11,0x11,0x1f,0x11,0x11,0x11},
    {0x0e,0x04,0x04,0x04,0x04,0x04,0x0e},{0x01,0x01,0x01,0x01,0x11,0x11,0x0e},
    {0x11,0x12,0x14,0x18,0x14,0x12,0x11},{0x10,0x10,0x10,0x10,0x10,0x10,0x1f},
    {0x11,0x1b,0x15,0x15,0x11,0x11,0x11},{0x11,0x19,0x15,0x13,0x11,0x11,0x11},
    {0x0e,0x11,0x11,0x11,0x11,0x11,0x0e},{0x1e,0x11,0x11,0x1e,0x10,0x10,0x10},
    {0x0e,0x11,0x11,0x11,0x15,0x12,0x0d},{0x1e,0x11,0x11,0x1e,0x14,0x12,0x11},
    {0x0f,0x10,0x10,0x0e,0x01,0x01,0x1e},{0x1f,0x04,0x04,0x04,0x04,0x04,0x04},
    {0x11,0x11,0x11,0x11,0x11,0x11,0x0e},{0x11,0x11,0x11,0x11,0x11,0x0a,0x04},
    {0x11,0x11,0x11,0x15,0x15,0x15,0x0a},{0x11,0x11,0x0a,0x04,0x0a,0x11,0x11},
    {0x11,0x11,0x0a,0x04,0x04,0x04,0x04},{0x1f,0x01,0x02,0x04,0x08,0x10,0x1f},
    {0,0,0,0,0,0,0},
    {0,0,0,0,0,0x04,0x04},{0,0,0,0,0,0x04,0x08},{0,0,0,0x1f,0,0,0},
    {0,0,0,0,0,0,0x1f},{0x01,0x02,0x02,0x04,0x08,0x08,0x10},{0,0x04,0,0,0,0x04,0},
    {0x04,0x04,0x04,0x04,0x04,0,0x04},{0x0e,0x11,0x01,0x02,0x04,0,0x04}
};

static int glyph_index(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'z') c = (char)(c - 'a' + 'A');
    if (c >= 'A' && c <= 'Z') return 10 + c - 'A';
    switch (c) {
        case ' ': return 36;
        case '.': return 37;
        case '-': return 39;
        case '_': return 40;
        case '/': return 41;
        case '!': return 43;
    }
    return 36;
}

static void text(uint64_t x, uint64_t y, const char *str, uint32_t color, int scale) {
    for (; str && *str; ++str, x += (FONT_W + 1) * scale) {
        const uint8_t *g = font[glyph_index(*str)];
        for (int row = 0; row < FONT_H; ++row)
            for (int col = 0; col < FONT_W; ++col)
                if (g[row] & (1u << (4 - col)))
                    fill(x + col * scale, y + row * scale, scale, scale, color);
    }
}

static uint64_t text_w(const char *str, int scale) {
    uint64_t n = 0;
    while (str && str[n]) ++n;
    return n * (FONT_W + 1) * scale;
}

/* Плотный "звёздный" фон из детерминированного хеша — без PRNG и памяти. */
static uint32_t hash_px(uint64_t x, uint64_t y) {
    uint64_t h = x * 0x9e3779b97f4a7c15ull ^ (y << 24) ^ (y * 0xd1b54a32d192ed03ull);
    h ^= h >> 27; h *= 0x2545f4914f6cdd1dull; h ^= h >> 23;
    return (uint32_t)(h & 0xffffffffu);
}

static void draw_background(void) {
    for (uint64_t y = 0; y < s.h; ++y) {
        uint32_t t = (uint32_t)((y * 256ull) / (s.h ? s.h : 1));
        uint32_t r = 0x10 + ((0x32 - 0x10) * t) / 256;
        uint32_t g = 0x16 + ((0x3a - 0x16) * t) / 256;
        uint32_t b = 0x26 + ((0x48 - 0x26) * t) / 256;
        uint32_t c = (r << 16) | (g << 8) | b;
        uint32_t *row = s.base + y * s.pitch_px;
        for (uint64_t x = 0; x < s.w; ++x) row[x] = c;
    }
    for (uint64_t y = 0; y < s.h; y += 2)
        for (uint64_t x = 0; x < s.w; x += 2) {
            uint32_t h = hash_px(x, y);
            /* ~1/256 пар - редкие тусклые "звёзды" в двух яркостях. */
            if ((h & 0xff) == 0) px(x, y, (h & 0x100) ? 0x1c2c48u : 0x142034u);
        }
}

/* Сетка-"дышащий" квадрат из контуров: логотип G1. */
static void draw_logo(uint64_t cx, uint64_t cy) {
    int scale = 6;
    uint64_t box = 48 * scale / 2; /* 144 px половина */
    rect(cx - box, cy - box, box * 2, box * 2, C_ACCENT);
    rect(cx - box + 6, cy - box + 6, box * 2 - 12, box * 2 - 12, C_TRACK);
    text(cx - text_w("NYKLIMA OS", scale) / 2, cy - box + 6 + 6,
         "NYKLIMA OS", C_ACCENT, scale);
    /* Крупный знак G1 в центре рамки. */
    text(cx - text_w("G1", 12) / 2, cy - 6 * FONT_H + 14, "G1", C_TEXT, 12);
    text(cx - text_w("G1 DESKTOP", 2) / 2, cy + box - 2 * FONT_H - 8,
         "G1 DESKTOP", C_MUTED, 2);
}

/* Прогресс: трек + заполнение + метка шага. (step 0..total) */
static void draw_progress(int step, int total, const char *label) {
    uint64_t bar_w = s.w * 3 / 5;
    uint64_t bar_x = (s.w - bar_w) / 2;
    uint64_t bar_y = s.h * 4 / 5;
    uint64_t bar_h = 14;

    fill(bar_x, bar_y, bar_w, bar_h, C_TRACK);
    rect(bar_x, bar_y, bar_w, bar_h, C_ACCENT);
    if (step > 0) {
        uint64_t frac = (uint64_t)step * (bar_w - 2) / (uint64_t)(total > 0 ? total : 1);
        fill(bar_x + 1, bar_y + 1, frac, bar_h - 2, C_ACCENT);
    }
    /* Сегментные засечки. */
    for (int i = 1; i < total; ++i)
        fill(bar_x + i * (bar_w - 2) / total, bar_y + 1, 1, bar_h - 2, C_BG_HI);

    if (label) {
        uint64_t lx = (s.w - text_w(label, 2)) / 2;
        fill(lx - 8, bar_y + bar_h + 10, text_w(label, 2) + 16, 2 * FONT_H + 4, C_BG_HI);
        text(lx, bar_y + bar_h + 12, label, C_TEXT, 2);
    }
}

/* Стереть зону бара перед перерисовкой (фон детерминированный).
   Граница — 3/5 высоты: логотип (рамка до cy+box ≈ 2/5+144px) должен
   переживать перерисовку шага, иначе стирается его низ и подпись. */
static void clear_lower(void) {
    uint64_t y0 = s.h * 3 / 5;
    for (uint64_t y = y0; y < s.h; ++y) {
        uint32_t t = (uint32_t)((y * 256ull) / (s.h ? s.h : 1));
        uint32_t r = 0x10 + ((0x32 - 0x10) * t) / 256;
        uint32_t g = 0x16 + ((0x3a - 0x16) * t) / 256;
        uint32_t b = 0x26 + ((0x48 - 0x26) * t) / 256;
        uint32_t c = (r << 16) | (g << 8) | b;
        uint32_t *row = s.base + y * s.pitch_px;
        for (uint64_t x = 0; x < s.w; ++x) row[x] = c;
    }
    for (uint64_t y = y0; y < s.h; y += 2)
        for (uint64_t x = 0; x < s.w; x += 2) {
            uint32_t h = hash_px(x, y);
            if ((h & 0xff) == 0) px(x, y, (h & 0x100) ? 0x1c2c48u : 0x142034u);
        }
}

void splash_start(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop) {
    if (!gop || !gop->Mode || !gop->Mode->Info) return;
    s.base = (uint32_t *)(uint64_t)gop->Mode->FrameBufferBase;
    s.w = gop->Mode->Info->HorizontalResolution;
    s.h = gop->Mode->Info->VerticalResolution;
    s.pitch_px = gop->Mode->Info->PixelsPerScanLine;
    if (!s.base || !s.w || !s.h) return;
    draw_background();
    draw_logo(s.w / 2, s.h * 2 / 5);
}

void splash_step(int step, int total, const char *label) {
    if (!s.base) return;
    clear_lower();
    draw_progress(step, total, label);
}

void splash_fail(const char *msg) {
    if (!s.base) return;
    clear_lower();
    draw_progress(-1, 6, "BOOT FAILED");
    text((s.w - text_w(msg, 2)) / 2, s.h * 9 / 10, msg, 0x00ff6f7cu, 2);
}
