#ifndef NYKLIMA_SPLASH_H
#define NYKLIMA_SPLASH_H

#include "uefi.h"

/* Графический экран загрузки поверх GOP: логотип, прогресс-бар по шагам.
   Рисует прямыми записями в framebuffer — работает только до
   ExitBootServices (после него рисовать не нужно, ядро вскоре рисует стол). */

void splash_start(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop);
/* step: 0..total; label — имя шага под баром. */
void splash_step(int step, int total, const char *label);
/* Сообщение об ошибке вместо метки шага. */
void splash_fail(const char *msg);

#endif
