#include "uefi.h"
#include "splash.h"

#define LIMINE_COMMON_MAGIC 0xc7b1dd30df4c8b88, 0x0a82e883a194f07b

#define LIMINE_BASE_REVISION(N) { 0xf9562b2d5c95a6c8, 0x6a7b384944536bdc, (N) }

#define LIMINE_REQUESTS_START_MARKER { 0xf6b8f4b39de7d1ae, 0xfab91a6940fcb9cf, \
                                        0x785c6ed015d3e316, 0x181e920a7852b9d9 }
#define LIMINE_REQUESTS_END_MARKER { 0xadc0e0531bb10d03, 0x9572709f31764c62 }

#define LIMINE_HHDM_REQUEST_ID { LIMINE_COMMON_MAGIC, 0x48dcf1cb8ad2b852, 0x63984e959a98244b }
#define LIMINE_FRAMEBUFFER_REQUEST_ID { LIMINE_COMMON_MAGIC, 0x9d5827dcd881dd75, 0xa3148604f6fab11b }
#define LIMINE_MEMMAP_REQUEST_ID { LIMINE_COMMON_MAGIC, 0x67cf3d9d378a806f, 0xe304acdfc50c3c62 }
#define LIMINE_EXECUTABLE_ADDRESS_REQUEST_ID { LIMINE_COMMON_MAGIC, 0x71ba76863cc55f63, 0xb2644a48c516a487 }
#define LIMINE_RSDP_REQUEST_ID { LIMINE_COMMON_MAGIC, 0xc5e77b6b397e7b43, 0x27637845accdcf3c }
#define LIMINE_ENTRY_POINT_REQUEST_ID { LIMINE_COMMON_MAGIC, 0x13d86c035a1cd3e1, 0x2b0caa89d8f3026a }

#define LIMINE_MEMMAP_USABLE 0
#define LIMINE_MEMMAP_RESERVED 1
#define LIMINE_MEMMAP_ACPI_RECLAIMABLE 2
#define LIMINE_MEMMAP_ACPI_NVS 3
#define LIMINE_MEMMAP_BAD_MEMORY 4
#define LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE 5
#define LIMINE_MEMMAP_EXECUTABLE_AND_MODULES 6
#define LIMINE_MEMMAP_FRAMEBUFFER 7
#define LIMINE_MEMMAP_RUNTIME_SERVICES_DATA 8
#define LIMINE_MEMMAP_RESERVED_MAPPED 9

#define PAGE_SIZE 4096
#define HUGE_PAGE_SIZE (2ULL * 1024 * 1024)
#define ENTRIES_PER_TABLE 512

#define PTE_PRESENT  (1ULL << 0)
#define PTE_WRITABLE (1ULL << 1)
#define PTE_HUGE     (1ULL << 7)

#define PML4_IDX(a) (((a) >> 39) & 0x1ff)
#define PDPT_IDX(a) (((a) >> 30) & 0x1ff)
#define PD_IDX(a)   (((a) >> 21) & 0x1ff)
#define PT_IDX(a)   (((a) >> 12) & 0x1ff)

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
} limine_hhdm_request_t;

typedef struct {
    uint64_t revision;
    uint64_t offset;
} limine_hhdm_response_t;

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
} limine_framebuffer_request_t;

typedef struct {
    void *address;
    uint64_t width;
    uint64_t height;
    uint64_t pitch;
    uint16_t bpp;
    uint8_t memory_model;
    uint8_t red_mask_size;
    uint8_t red_mask_shift;
    uint8_t green_mask_size;
    uint8_t green_mask_shift;
    uint8_t blue_mask_size;
    uint8_t blue_mask_shift;
    uint8_t unused[7];
    uint64_t edid_size;
    void *edid;
    uint64_t mode_count;
    void **modes;
} limine_framebuffer_t;

typedef struct {
    uint64_t revision;
    uint64_t framebuffer_count;
    limine_framebuffer_t **framebuffers;
} limine_framebuffer_response_t;

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
} limine_memmap_request_t;

typedef struct {
    uint64_t base;
    uint64_t length;
    uint64_t type;
} limine_memmap_entry_t;

typedef struct {
    uint64_t revision;
    uint64_t entry_count;
    limine_memmap_entry_t **entries;
} limine_memmap_response_t;

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
} limine_executable_address_request_t;

typedef struct {
    uint64_t revision;
    uint64_t physical_base;
    uint64_t virtual_base;
} limine_executable_address_response_t;

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
} limine_rsdp_request_t;

typedef struct {
    uint64_t revision;
    void *address;
} limine_rsdp_response_t;

typedef void (*limine_entry_point)(void);

typedef struct {
    uint64_t id[4];
    uint64_t revision;
    void *response;
    limine_entry_point entry;
} limine_entry_point_request_t;

typedef struct {
    uint64_t id[4];
    uint64_t revision[3];
} limine_base_revision_t;

static uint64_t requests_start[] __attribute__((used)) = LIMINE_REQUESTS_START_MARKER;
static uint64_t requests_end[] __attribute__((used)) = LIMINE_REQUESTS_END_MARKER;

static EFI_SYSTEM_TABLE *gST;
static EFI_BOOT_SERVICES *gBS;
static EFI_HANDLE gImageHandle;

static uint64_t g_hhdm_offset = 0x4000000000ULL;
static uint64_t g_kernel_phys_base = 0;
static uint64_t g_kernel_virt_base = 0xffffffff80000000ULL;
static void *g_kernel_entry = 0;

static limine_hhdm_request_t hhdm_request = {
    .id = LIMINE_HHDM_REQUEST_ID,
    .revision = 0,
    .response = NULL
};
static limine_hhdm_response_t hhdm_response = { 0 };

static limine_framebuffer_request_t fb_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST_ID,
    .revision = 0,
    .response = NULL
};
static limine_framebuffer_response_t fb_response = { 0 };
static limine_framebuffer_t fb_info = { 0 };

static limine_memmap_request_t memmap_request = {
    .id = LIMINE_MEMMAP_REQUEST_ID,
    .revision = 0,
    .response = NULL
};
static limine_memmap_response_t memmap_response = { 0 };

static limine_executable_address_request_t exec_addr_request = {
    .id = LIMINE_EXECUTABLE_ADDRESS_REQUEST_ID,
    .revision = 0,
    .response = NULL
};
static limine_executable_address_response_t exec_addr_response = { 0 };

static limine_rsdp_request_t rsdp_request = {
    .id = LIMINE_RSDP_REQUEST_ID,
    .revision = 0,
    .response = NULL
};
static limine_rsdp_response_t rsdp_response = { 0 };

static limine_entry_point_request_t entry_request = {
    .id = LIMINE_ENTRY_POINT_REQUEST_ID,
    .revision = 0,
    .response = NULL,
    .entry = NULL
};

static limine_base_revision_t base_revision __attribute__((used)) = {
    .id = { 0xf9562b2d5c95a6c8, 0x6a7b384944536bdc, 6 }
};

static void print(const char16_t *s);

/* Freestanding: clang на -O0 генерирует вызов memcpy для инициализации
   локальных массивов, а библиотеки в UEFI-приложении нет. */
void *memcpy(void *dst, const void *src, uint64_t n) {
    unsigned char *d = (unsigned char *)dst;
    const unsigned char *s = (const unsigned char *)src;
    while (n--) *d++ = *s++;
    return dst;
}

/* С момента старта splash текстовый вывод ConOut убран с экрана: отладка
   идёт прямо в COM1 (UART уже инициализирован прошивкой для консоли). */
static int g_splash = 0;

static uint8_t com_inb(uint16_t port) {
    uint8_t v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(port)); return v;
}

static void com_putc(char c) {
    while (!(com_inb(0x3fd) & 0x20)) { }
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)c), "Nd"((uint16_t)0x3f8));
}

static void print(const char16_t *s) {
    if (g_splash) {
        for (; *s; ++s) {
            char c = (char)*s;
            if (c == '\n') com_putc('\r');
            com_putc(c);
        }
        return;
    }
    gST->ConOut->OutputString(gST->ConOut, (char16_t *)s);
}

static void print_hex(uint64_t v) {
    char16_t buf[20];
    int i = 0;
    buf[i++] = L'0'; buf[i++] = L'x';
    int started = 0;
    for (int sh = 60; sh >= 0; sh -= 4) {
        uint8_t n = (v >> sh) & 0xf;
        if (!started && sh > 0 && n == 0) continue;
        started = 1;
        buf[i++] = n < 10 ? L'0' + n : L'a' + n - 10;
    }
    if (!started) buf[i++] = L'0';
    buf[i] = 0;
    print(buf);
}

static void print_dec(uint64_t v) {
    char buf[24];
    int i = 0;
    do { buf[i++] = (char)('0' + (v % 10)); v /= 10; } while (v);
    char16_t out[24];
    int n = 0;
    while (i > 0) out[n++] = (char16_t)buf[--i];
    out[n] = 0;
    print(out);
}

static void print_str(const char *s) {
    char16_t buf[128];
    int i = 0;
    while (s[i] && i < 127) { buf[i] = (char16_t)s[i]; i++; }
    buf[i] = 0;
    print(buf);
}

static void *alloc_pages(uint64_t pages);
static void patch_kernel_requests(uint8_t *image, uint64_t size);

static void *alloc_pages(uint64_t pages) {
    void *ptr = NULL;
    EFI_STATUS status = gBS->AllocatePages(EFI_ALLOCATE_ANY_PAGES, EFI_LOADER_DATA, pages, (EFI_PHYSICAL_ADDRESS *)&ptr);
    return status == EFI_SUCCESS ? ptr : NULL;
}

static void free_pages(void *ptr, uint64_t pages) {
    gBS->FreePages((EFI_PHYSICAL_ADDRESS)(uint64_t)ptr, pages);
}

static void *alloc_pool(uint64_t size) {
    void *ptr = NULL;
    gBS->AllocatePool(EFI_LOADER_DATA, size, &ptr);
    return ptr;
}

static void free_pool(void *ptr) {
    gBS->FreePool(ptr);
}

static uint64_t efi_mem_type_to_limine(uint32_t type) {
    switch (type) {
        case 0x7: return LIMINE_MEMMAP_USABLE;
        case 0x2: case 0x3: return LIMINE_MEMMAP_EXECUTABLE_AND_MODULES;
        case 0x4: case 0x5: return LIMINE_MEMMAP_BOOTLOADER_RECLAIMABLE;
        case 0x6: return LIMINE_MEMMAP_RUNTIME_SERVICES_DATA;
        case 0x8: return LIMINE_MEMMAP_ACPI_RECLAIMABLE;
        case 0x9: return LIMINE_MEMMAP_ACPI_NVS;
        case 0xA: case 0xB: return LIMINE_MEMMAP_RESERVED_MAPPED;
        default: return LIMINE_MEMMAP_RESERVED;
    }
}

static int load_kernel(EFI_FILE_PROTOCOL *root) {
    EFI_FILE_PROTOCOL *kernel_file = NULL;
    EFI_GUID file_info_id = EFI_FILE_INFO_ID;
    uint64_t info_size = 0;
    
    EFI_STATUS status = root->Open(root, (EFI_FILE_PROTOCOL **)&kernel_file, L"KERNEL.ELF", EFI_FILE_MODE_READ, 0);
    if (status != EFI_SUCCESS) {
        print_str("Failed to open KERNEL.ELF\n");
        return -1;
    }
    
    status = kernel_file->GetInfo(kernel_file, &file_info_id, &info_size, NULL);
    if (status != EFI_BUFFER_TOO_SMALL || info_size < 16) {
        print_str("GetInfo size failed status=");
        print_hex(status);
        print_str(" size=");
        print_hex(info_size);
        print_str("\n");
        kernel_file->Close(kernel_file);
        return -1;
    }
    void *info = alloc_pool(info_size);
    if (!info) {
        kernel_file->Close(kernel_file);
        return -1;
    }
    status = kernel_file->GetInfo(kernel_file, &file_info_id, &info_size, info);
    if (status != EFI_SUCCESS) {
        print_str("GetInfo failed\n");
        free_pool(info);
        kernel_file->Close(kernel_file);
        return -1;
    }
    uint64_t file_size = *(uint64_t *)((uint8_t *)info + 8);
    free_pool(info);
    
    uint64_t pages = (file_size + PAGE_SIZE - 1) / PAGE_SIZE;
    uint8_t *file_buf = alloc_pages(pages);
    if (!file_buf) {
        print_str("Failed to allocate kernel buffer\n");
        kernel_file->Close(kernel_file);
        return -1;
    }
    
    uint64_t read_size = file_size;
    status = kernel_file->Read(kernel_file, &read_size, file_buf);
    kernel_file->Close(kernel_file);
    
    if (status != EFI_SUCCESS || read_size != file_size) {
        print_str("Failed to read kernel\n");
        free_pages(file_buf, pages);
        return -1;
    }
    
    if (file_size < 64 || file_buf[0] != 0x7f || file_buf[1] != 'E' || file_buf[2] != 'L' || file_buf[3] != 'F') {
        print_str("Invalid ELF\n");
        free_pages(file_buf, pages);
        return -1;
    }
    
    if (file_buf[4] != 2 || file_buf[5] != 1) {
        print_str("Not ELF64 little-endian\n");
        free_pages(file_buf, pages);
        return -1;
    }
    
    uint16_t e_machine = *(uint16_t *)(file_buf + 18);
    if (e_machine != 0x3e) {
        print_str("Not x86-64\n");
        free_pages(file_buf, pages);
        return -1;
    }
    
    uint64_t e_entry = *(uint64_t *)(file_buf + 24);
    uint64_t e_phoff = *(uint64_t *)(file_buf + 32);
    uint16_t e_phentsize = *(uint16_t *)(file_buf + 54);
    uint16_t e_phnum = *(uint16_t *)(file_buf + 56);
    
    if (e_phentsize != 56 || e_phnum > 32) {
        print_str("Bad program headers\n");
        free_pages(file_buf, pages);
        return -1;
    }

    uint64_t image_end = 0;
    for (int i = 0; i < e_phnum; ++i) {
        uint8_t *ph = file_buf + e_phoff + (uint64_t)i * e_phentsize;
        uint32_t p_type = *(uint32_t *)(ph + 0);
        uint64_t p_offset = *(uint64_t *)(ph + 8);
        uint64_t p_vaddr = *(uint64_t *)(ph + 16);
        uint64_t p_filesz = *(uint64_t *)(ph + 32);
        uint64_t p_memsz = *(uint64_t *)(ph + 40);
        if (p_type != 1 || !p_memsz) continue;
        if (p_vaddr < g_kernel_virt_base || p_memsz > ~p_vaddr ||
            p_offset > file_size || p_filesz > file_size - p_offset ||
            p_filesz > p_memsz) {
            print_str("Invalid PT_LOAD\n");
            free_pages(file_buf, pages);
            return -1;
        }
        uint64_t end = p_vaddr + p_memsz - g_kernel_virt_base;
        if (end > image_end) image_end = end;
    }
    if (!image_end || image_end > 8ULL * 1024 * 1024) {
        print_str("Kernel image too large\n");
        free_pages(file_buf, pages);
        return -1;
    }

    uint64_t image_pages = (image_end + PAGE_SIZE - 1) / PAGE_SIZE;
    uint8_t *kernel_buf = alloc_pages(image_pages);
    if (!kernel_buf) {
        print_str("Failed to allocate kernel image\n");
        free_pages(file_buf, pages);
        return -1;
    }
    for (uint64_t i = 0; i < image_pages * PAGE_SIZE; ++i) kernel_buf[i] = 0;

    for (int i = 0; i < e_phnum; ++i) {
        uint8_t *ph = file_buf + e_phoff + (uint64_t)i * e_phentsize;
        uint32_t p_type = *(uint32_t *)(ph + 0);
        uint64_t p_offset = *(uint64_t *)(ph + 8);
        uint64_t p_vaddr = *(uint64_t *)(ph + 16);
        uint64_t p_filesz = *(uint64_t *)(ph + 32);
        if (p_type != 1 || !p_filesz) continue;
        uint64_t dst = p_vaddr - g_kernel_virt_base;
        for (uint64_t j = 0; j < p_filesz; ++j) kernel_buf[dst + j] = file_buf[p_offset + j];
    }
    free_pages(file_buf, pages);

    patch_kernel_requests(kernel_buf, image_pages * PAGE_SIZE);

    /* ELF64 e_entry уже содержит полный виртуальный адрес ядра. */
    g_kernel_entry = (void *)e_entry;
    entry_request.entry = (limine_entry_point)g_kernel_entry;
    
    exec_addr_response.physical_base = (uint64_t)kernel_buf;
    exec_addr_response.virtual_base = g_kernel_virt_base;
    exec_addr_request.response = &exec_addr_response;
    
    hhdm_response.offset = g_hhdm_offset;
    hhdm_request.response = &hhdm_response;
    
    g_kernel_phys_base = (uint64_t)kernel_buf;
    
    print_str("Kernel loaded at phys=");
    print_hex(g_kernel_phys_base);
    print_str(" virt=");
    print_hex(g_kernel_virt_base);
    print_str(" entry=");
    print_hex((uint64_t)g_kernel_entry);
    print_str("\n");
    
    return 0;
}

/* Протокол Limine — ABI между загрузчиком и ядром: Limine находит запросы
   в секции .limine_requests образа ядра и записывает в них указатели на
   ответы. Загрузчик делает то же самое: сканирует образ по magic-ID и
   патчит поле response (id[4] + revision + response = смещение 40).
   Заполненные ответы лежат в памяти загрузчика — она остаётся
   identity-отображённой (0..4 ГБ) в таблицах ядра. */
static void patch_kernel_requests(uint8_t *image, uint64_t size) {
    static const uint64_t ids[][4] = {
        LIMINE_HHDM_REQUEST_ID,
        LIMINE_FRAMEBUFFER_REQUEST_ID,
        LIMINE_MEMMAP_REQUEST_ID,
        LIMINE_EXECUTABLE_ADDRESS_REQUEST_ID,
        LIMINE_RSDP_REQUEST_ID
    };
    void *responses[] = {
        &hhdm_response, &fb_response, &memmap_response,
        &exec_addr_response, &rsdp_response
    };
    for (int r = 0; r < 5; ++r) {
        for (uint64_t off = 0; off + 48 <= size; off += 8) {
            int match = 1;
            for (int w = 0; w < 4; ++w)
                if (*(uint64_t *)(image + off + w * 8) != ids[r][w]) { match = 0; break; }
            if (match) {
                *(void **)(image + off + 40) = responses[r];
                break;
            }
        }
    }
}

static int setup_framebuffer(EFI_GRAPHICS_OUTPUT_PROTOCOL *gop) {
    if (!gop) return -1;

    if (!gop->Mode || !gop->Mode->Info) {
        print_str("GOP mode unavailable\n");
        return -1;
    }
    EFI_GRAPHICS_OUTPUT_MODE_INFORMATION *info = gop->Mode->Info;
    
    fb_info.address = (void *)gop->Mode->FrameBufferBase;
    fb_info.width = info->HorizontalResolution;
    fb_info.height = info->VerticalResolution;
    fb_info.pitch = info->PixelsPerScanLine * 4;
    fb_info.bpp = 32;
    fb_info.memory_model = 1;
    fb_info.red_mask_size = 8; fb_info.red_mask_shift = 16;
    fb_info.green_mask_size = 8; fb_info.green_mask_shift = 8;
    fb_info.blue_mask_size = 8; fb_info.blue_mask_shift = 0;
    for (int i = 0; i < 7; ++i) fb_info.unused[i] = 0;
    fb_info.edid_size = 0; fb_info.edid = NULL;
    fb_info.mode_count = 0; fb_info.modes = NULL;
    
    /* Массив указателей обязан быть статическим: локальная переменная
       умерла бы вместе с кадром setup_framebuffer, а ядро читает
       framebuffers[0] много позже, когда стек уже перезаписан. */
    static limine_framebuffer_t *fb_list[1] = { &fb_info };

    fb_response.framebuffer_count = 1;
    fb_response.framebuffers = fb_list;
    fb_request.response = &fb_response;
    
    print_str("Framebuffer: ");
    print_dec(fb_info.width);
    print_str("x");
    print_dec(fb_info.height);
    print_str(" pitch=");
    print_dec(fb_info.pitch);
    print_str(" addr=");
    print_hex((uint64_t)fb_info.address);
    print_str("\n");
    
    return 0;
}

/* Ответ ядру держим в статических массивах: любые AllocatePool после
   GetMemoryMap меняют карту и делают её устаревшей, а заполнение из
   статических данных ничего не выделяет. Обновляются перед каждым
   вызовом ExitBootServices. */
#define MAX_MEMMAP_ENTRIES 512
static limine_memmap_entry_t memmap_entry_data[MAX_MEMMAP_ENTRIES];
static limine_memmap_entry_t *memmap_entry_ptrs[MAX_MEMMAP_ENTRIES];

static void fill_memmap(void *map, uint64_t map_size, uint64_t desc_size) {
    uint64_t count = desc_size ? map_size / desc_size : 0;
    if (count > MAX_MEMMAP_ENTRIES) count = MAX_MEMMAP_ENTRIES;
    uint64_t limine_count = 0;
    for (uint64_t i = 0; i < count; ++i) {
        EFI_MEMORY_DESCRIPTOR *desc = (EFI_MEMORY_DESCRIPTOR *)((uint8_t *)map + i * desc_size);
        if (desc->NumberOfPages == 0) continue;
        memmap_entry_data[limine_count].base = desc->PhysicalStart;
        memmap_entry_data[limine_count].length = desc->NumberOfPages * PAGE_SIZE;
        memmap_entry_data[limine_count].type = efi_mem_type_to_limine(desc->Type);
        memmap_entry_ptrs[limine_count] = &memmap_entry_data[limine_count];
        limine_count++;
    }
    memmap_response.entry_count = limine_count;
    memmap_response.entries = memmap_entry_ptrs;
    memmap_request.response = &memmap_response;
}

static int build_memmap() {
    uint64_t map_size = 0, map_key = 0, desc_size = 0;
    uint32_t desc_version = 0;

    gBS->GetMemoryMap(&map_size, NULL, &map_key, &desc_size, &desc_version);
    map_size += desc_size * 16;

    void *memmap = alloc_pool(map_size);
    if (!memmap) return -1;

    EFI_STATUS status = gBS->GetMemoryMap(&map_size, memmap, &map_key, &desc_size, &desc_version);
    if (status != EFI_SUCCESS) {
        free_pool(memmap);
        return -1;
    }

    fill_memmap(memmap, map_size, desc_size);
    free_pool(memmap);

    print_str("Memory map entries: ");
    print_dec(memmap_response.entry_count);
    print_str("\n");

    return 0;
}

static int find_rsdp() {
    for (uint64_t i = 0; i < gST->NumberOfTableEntries; ++i) {
        EFI_CONFIGURATION_TABLE *tbl = &((EFI_CONFIGURATION_TABLE *)gST->ConfigurationTable)[i];
        EFI_GUID acpi_guid = EFI_ACPI_20_TABLE_GUID;
        if (guid_eq(&tbl->VendorGuid, &acpi_guid)) {
            rsdp_response.address = tbl->VendorTable;
            rsdp_request.response = &rsdp_response;
            print_str("RSDP found at ");
            print_hex((uint64_t)tbl->VendorTable);
            print_str("\n");
            return 0;
        }
        EFI_GUID acpi1_guid = EFI_ACPI_TABLE_GUID;
        if (guid_eq(&tbl->VendorGuid, &acpi1_guid)) {
            rsdp_response.address = tbl->VendorTable;
            rsdp_request.response = &rsdp_response;
            print_str("RSDP (v1) found at ");
            print_hex((uint64_t)tbl->VendorTable);
            print_str("\n");
            return 0;
        }
    }
    print_str("RSDP not found\n");
    return -1;
}

/* ExitBootServices требует свежий map_key: любой Allocate/FreePool после
   GetMemoryMap делает ключ недействительным (EFI_INVALID_PARAMETER) —
   по спецификации полагается перечитать карту и повторить. Перед каждым
   вызовом обновляем и ответ ядру, чтобы он получил финальную карту. */
static int exit_boot_services() {
    for (int attempt = 0; attempt < 8; ++attempt) {
        uint64_t map_size = 0, map_key = 0, desc_size = 0;
        uint32_t desc_version = 0;

        gBS->GetMemoryMap(&map_size, NULL, &map_key, &desc_size, &desc_version);
        map_size += desc_size * 16;

        void *memmap = alloc_pool(map_size);
        if (!memmap) return -1;

        EFI_STATUS status = gBS->GetMemoryMap(&map_size, memmap, &map_key, &desc_size, &desc_version);
        if (status != EFI_SUCCESS) {
            free_pool(memmap);
            return -1;
        }

        /* Между этим fill_memmap и ExitBootServices ничего не выделяет. */
        fill_memmap(memmap, map_size, desc_size);

        status = gBS->ExitBootServices(gImageHandle, map_key);
        if (status == EFI_SUCCESS) {
            gBS = NULL;
            gST = NULL;
            return 0;
        }
        free_pool(memmap);
        print_str("ExitBootServices retry ");
        print_dec((uint64_t)attempt);
        print_str(" status=");
        print_hex(status);
        print_str("\n");
        if (status != EFI_INVALID_PARAMETER) return -1;
    }
    return -1;
}

static uint64_t g_pml4[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pdpt_low[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pd_id[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pd_hhdm[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pdpt_kern[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pd_kern[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t g_pt_kern[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));

static uint64_t pt_phys(void *table) {
    /* Таблицы выделены UEFI-загрузчиком и находятся по identity-адресам.
       Они не являются частью загруженного high-half образа ядра. */
    return (uint64_t)table;
}

static void setup_paging() {
    for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
        g_pml4[i] = 0; g_pdpt_low[i] = 0; g_pdpt_kern[i] = 0; g_pd_kern[i] = 0;
    }
    for (int p = 0; p < 4; ++p)
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
            g_pd_id[p][i] = 0; g_pd_hhdm[p][i] = 0; g_pt_kern[p][i] = 0;
        }

    /* Identity-map 0..4 GiB so the UEFI stack and loader code survive CR3. */
    g_pml4[0] = pt_phys(&g_pdpt_low[0]) | PTE_PRESENT | PTE_WRITABLE;
    for (int p = 0; p < 4; ++p) {
        g_pdpt_low[p] = pt_phys(&g_pd_id[p][0]) | PTE_PRESENT | PTE_WRITABLE;
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i)
            g_pd_id[p][i] = ((uint64_t)(p * ENTRIES_PER_TABLE + i) * HUGE_PAGE_SIZE)
                          | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
    }

    /* HHDM shares PML4[0] for the chosen 256 GiB offset, but uses distinct PDs. */
    uint64_t hstart = PDPT_IDX(g_hhdm_offset);
    for (int p = 0; p < 4 && hstart + (uint64_t)p < ENTRIES_PER_TABLE; ++p) {
        g_pdpt_low[hstart + (uint64_t)p] = pt_phys(&g_pd_hhdm[p][0]) | PTE_PRESENT | PTE_WRITABLE;
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i)
            g_pd_hhdm[p][i] = ((uint64_t)(p * ENTRIES_PER_TABLE + i) * HUGE_PAGE_SIZE)
                            | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
    }

    /* Kernel high half: independent tables with 4 KiB mappings. */
    uint64_t kpml4 = PML4_IDX(g_kernel_virt_base);
    uint64_t kpdpt = PDPT_IDX(g_kernel_virt_base);
    g_pml4[kpml4] = pt_phys(&g_pdpt_kern[0]) | PTE_PRESENT | PTE_WRITABLE;
    g_pdpt_kern[kpdpt] = pt_phys(&g_pd_kern[0]) | PTE_PRESENT | PTE_WRITABLE;
    for (int p = 0; p < 4; ++p) {
        g_pd_kern[p] = pt_phys(&g_pt_kern[p][0]) | PTE_PRESENT | PTE_WRITABLE;
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
            uint64_t off = ((uint64_t)p * ENTRIES_PER_TABLE + i) * PAGE_SIZE;
            g_pt_kern[p][i] = (g_kernel_phys_base + off) | PTE_PRESENT | PTE_WRITABLE;
        }
    }

    uint64_t pml4_phys = pt_phys(&g_pml4[0]);
    __asm__ volatile("movq %0, %%cr3" : : "r"(pml4_phys) : "memory");
}

EFI_STATUS EFIAPI efi_main(EFI_HANDLE ImageHandle, EFI_SYSTEM_TABLE *SystemTable) {
    gImageHandle = ImageHandle;
    gST = SystemTable;
    gBS = SystemTable->BootServices;

    /* Splash как можно раньше: дальше весь текст идёт только в COM1. */
    EFI_GUID gop_guid = EFI_GRAPHICS_OUTPUT_PROTOCOL_GUID;
    EFI_GRAPHICS_OUTPUT_PROTOCOL *gop = NULL;
    EFI_STATUS status = gBS->LocateProtocol(&gop_guid, NULL, (void **)&gop);
    if (status == EFI_SUCCESS && gop) splash_start(gop);
    g_splash = 1;
    splash_step(1, 6, "INIT");
    gBS->Stall(150000);

    EFI_LOADED_IMAGE_PROTOCOL *loaded_image = NULL;
    EFI_GUID lip_guid = EFI_LOADED_IMAGE_PROTOCOL_GUID;
    status = gBS->HandleProtocol(ImageHandle, &lip_guid, (void **)&loaded_image);
    if (status != EFI_SUCCESS || !loaded_image) {
        splash_fail("LOADER ERROR");
        return EFI_LOAD_ERROR;
    }

    EFI_DEVICE_PATH_PROTOCOL *device_path = loaded_image ? loaded_image->FilePath : NULL;
    EFI_GUID fs_guid = EFI_SIMPLE_FILE_SYSTEM_PROTOCOL_GUID;
    EFI_SIMPLE_FILE_SYSTEM_PROTOCOL *fs = NULL;

    if (device_path) {
        status = gBS->HandleProtocol(loaded_image->DeviceHandle, &fs_guid, (void **)&fs);
        if (status != EFI_SUCCESS) {
            print_str("Device filesystem status: ");
            print_hex(status);
            print_str("\n");
        }
    }
    if (!fs) {
        status = gBS->LocateProtocol(&fs_guid, NULL, (void **)&fs);
        if (status != EFI_SUCCESS) {
            print_str("Locate filesystem status: ");
            print_hex(status);
            print_str("\n");
        }
    }
    if (!fs) {
        splash_fail("NO FILESYSTEM");
        return EFI_LOAD_ERROR;
    }

    EFI_FILE_PROTOCOL *root = NULL;
    status = fs->OpenVolume(fs, (EFI_FILE_PROTOCOL **)&root);
    if (!root) {
        splash_fail("NO FILESYSTEM");
        return EFI_LOAD_ERROR;
    }

    splash_step(2, 6, "KERNEL");
    gBS->Stall(150000);
    if (load_kernel(root) != 0) {
        splash_fail("KERNEL ERROR");
        root->Close(root);
        return EFI_LOAD_ERROR;
    }

    splash_step(3, 6, "DISPLAY");
    gBS->Stall(150000);
    if (setup_framebuffer(gop) != 0) {
        splash_fail("DISPLAY ERROR");
        root->Close(root);
        return EFI_LOAD_ERROR;
    }

    splash_step(4, 6, "MEMORY");
    gBS->Stall(150000);
    if (build_memmap() != 0) {
        splash_fail("MEMORY ERROR");
        root->Close(root);
        return EFI_LOAD_ERROR;
    }

    splash_step(5, 6, "ACPI");
    gBS->Stall(150000);
    find_rsdp();

    root->Close(root);
    setup_paging();

    splash_step(6, 6, "START");
    gBS->Stall(400000); /* короткая пауза с заполненным баром */

    if (exit_boot_services() != 0) {
        /* После EBS рисовать нельзя (нет сервисов), но GOP-кадр ещё жив. */
        com_putc('!'); com_putc('\r'); com_putc('\n');
        return EFI_LOAD_ERROR;
    }

    __asm__ volatile("cli");

    limine_entry_point kmain = (limine_entry_point)g_kernel_entry;
    kmain();

    for (;;) __asm__ volatile("hlt");

    return EFI_SUCCESS;
}
