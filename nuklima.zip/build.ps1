param([switch]$Run)
$ErrorActionPreference = 'Stop'
$root = $PSScriptRoot

function Find-Tool($Name) {
    $fromPath = Get-Command $Name -ErrorAction SilentlyContinue
    if ($fromPath) { return $fromPath.Source }
    $candidates = @(
        'C:\Program Files\LLVM\bin'
        'C:\Program Files (x86)\LLVM\bin'
        'C:\Program Files\Android\AndroidNDK\android-ndk-r23c\toolchains\llvm\prebuilt\windows-x86_64\bin'
        'C:\Program Files (x86)\Android\AndroidNDK\android-ndk-r23c\toolchains\llvm\prebuilt\windows-x86_64\bin'
    )
    foreach ($dir in $candidates) {
        $path = Join-Path $dir $Name
        if (Test-Path $path) { return $path }
    }
    return $null
}

$clang = Find-Tool 'clang.exe'
$lld = Find-Tool 'ld.lld.exe'
$lldlink = Find-Tool 'lld-link.exe'
if (-not $clang -or -not $lld -or -not $lldlink) {
    throw "clang.exe, ld.lld.exe, and/or lld-link.exe were not found on PATH or in common LLVM/NDK locations. Install LLVM and ensure the tools are available."
}

New-Item -ItemType Directory -Force "$root\build" | Out-Null
$cflags = @('--target=x86_64-unknown-elf','-ffreestanding','-fno-stack-protector','-fno-pic','-mcmodel=kernel','-mno-red-zone','-mno-sse','-mno-mmx','-nostdinc','-Wall','-Wextra','-Werror','-Ikernel/include')
# -Wno-excessive-regsave: ISR-обработчики вызывают обычные функции; это warning
# о производительности (сохранение всех регистров), а не о корректности. Наши ISR
# завершаются halt, производительность не важна.
& $clang @cflags -Wno-excessive-regsave -c kernel/src/main.c -o "$root\build\main.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for main.c.' }
& $clang @cflags -c kernel/src/fs.c -o "$root\build\fs.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for fs.c.' }
& $clang @cflags -c kernel/src/disk.c -o "$root\build\disk.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for disk.c.' }
& $clang @cflags -c kernel/src/paging.c -o "$root\build\paging.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for paging.c.' }
& $clang @cflags -c kernel/src/mem.c -o "$root\build\mem.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for mem.c.' }
# fbdraw/wm: SSE разрешён — компилятор векторизует блиты (4 пикселя за итерацию).
# Эти модули не выполняются в контексте ISR, XMM-состояние сохранять не нужно.
$gfxflags2 = @('--target=x86_64-unknown-elf','-ffreestanding','-fno-stack-protector','-fno-pic','-mcmodel=kernel','-mno-red-zone','-msse2','-fno-math-errno','-nostdinc','-Wall','-Wextra','-Werror','-Ikernel/include')
& $clang @gfxflags2 -c kernel/src/fbdraw.c -o "$root\build\fbdraw.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for fbdraw.c.' }
& $clang @gfxflags2 -c kernel/src/wm.c -o "$root\build\wm.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for wm.c.' }
& $clang @cflags -c kernel/src/texload.c -o "$root\build\texload.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for texload.c.' }
& $clang @cflags -c kernel/src/pgm.c -o "$root\build\pgm.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for pgm.c.' }
& $clang @cflags -c kernel/src/cpu.c -o "$root\build\cpu.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for cpu.c.' }
& $clang @cflags -c kernel/src/sched.c -o "$root\build\sched.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for sched.c.' }
# Трамплин AP: 16->64 бит, сырой blob для физического 0x8000.
& $clang --target=i386 -c kernel/src/trampoline.S -o "$root\build\trampoline.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for trampoline.S.' }
$objcopy = Find-Tool 'llvm-objcopy.exe'
if (-not $objcopy) { throw 'llvm-objcopy.exe was not found.' }
& $lld -m elf_i386 -T kernel/tramp.ld -o "$root\build\trampoline.elf" "$root\build\trampoline.o"
if ($LASTEXITCODE) { throw 'ld.lld linking failed for trampoline.elf.' }
& $objcopy -O binary --only-section=.text "$root\build\trampoline.elf" "$root\build\trampoline.bin"
if ($LASTEXITCODE) { throw 'objcopy failed for trampoline.bin.' }
& $clang --target=x86_64-unknown-elf -c kernel/src/trampblob.S -o "$root\build\trampblob.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for trampblob.S.' }
& $clang @cflags -c kernel/src/smp.c -o "$root\build\smp.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for smp.c.' }
# Программы: PIE + относительные релокации — загружаются pgm_run() из FAT16.
$pgmcflags = @('--target=x86_64-unknown-elf','-ffreestanding','-fno-stack-protector','-fno-pic','-mcmodel=small','-mno-red-zone','-mno-sse','-mno-mmx','-fPIC','-fno-unwind-tables','-fno-asynchronous-unwind-tables','-fno-builtin','-nostdinc','-Wall','-Wextra','-Werror','-Ikernel/include')
& $clang @pgmcflags -c kernel/src/game_snake.c -o "$root\build\game_snake.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for game_snake.c.' }
& $lld -pie -nostdlib -z max-page-size=0x1000 --entry nyklima_main -o "$root\build\game_snake.elf" "$root\build\game_snake.o"
if ($LASTEXITCODE) { throw 'ld.lld linking failed for game_snake.elf.' }
# gfx.c — рендерер: SSE разрешён и включён явно (FP только здесь, ISR его не использует).
$gfxflags = @('--target=x86_64-unknown-elf','-ffreestanding','-fno-stack-protector','-fno-pic','-mcmodel=kernel','-mno-red-zone','-msse2','-fno-math-errno','-nostdinc','-Wall','-Wextra','-Werror','-Ikernel/include')
& $clang @gfxflags -c kernel/src/gfx.c -o "$root\build\gfx.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for gfx.c.' }
# ET_EXEC, а не -pie: Limine не принимает ET_DYN без PT_DYNAMIC.
& $lld -m elf_x86_64 -nostdlib -no-pie -z max-page-size=0x1000 -T "$root\kernel\linker.ld" -o "$root\build\kernel.elf" "$root\build\main.o" "$root\build\fs.o" "$root\build\disk.o" "$root\build\paging.o" "$root\build\mem.o" "$root\build\fbdraw.o" "$root\build\wm.o" "$root\build\texload.o" "$root\build\pgm.o" "$root\build\cpu.o" "$root\build\sched.o" "$root\build\smp.o" "$root\build\trampblob.o" "$root\build\gfx.o"
if ($LASTEXITCODE) { throw 'ld.lld linking failed.' }

# UEFI bootloader (replaces Limine)
$uefi_cflags = @('--target=x86_64-pc-windows-msvc','-ffreestanding','-fno-stack-protector','-fno-pic','-mno-red-zone','-mno-sse','-mno-mmx','-fno-builtin','-nostdinc','-Wall','-Wextra','-Werror','-Iuefi','-Ikernel/include','-DUEFI_BUILD')
& $clang @uefi_cflags -c uefi/main.c -o "$root\build\uefi_main.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for uefi/main.c.' }
& $clang @uefi_cflags -c uefi/splash.c -o "$root\build\splash.o"
if ($LASTEXITCODE) { throw 'clang compilation failed for uefi/splash.c.' }
& $lldlink -subsystem:efi_application -entry:efi_main -nodefaultlib -dll -out:"$root\build\BOOTX64.EFI" "$root\build\uefi_main.o" "$root\build\splash.o"
if ($LASTEXITCODE) { throw 'lld-link failed for BOOTX64.EFI.' }

& "$root\scripts\New-Fat16Image.ps1" -Root $root -Output "$root\build\nyklima-uefi.img"
if ($Run) { & "$root\scripts\Run-VirtualBox.ps1" -Root $root }
