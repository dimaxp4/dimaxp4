#ifndef NYKLIMA_PAGING_H
#define NYKLIMA_PAGING_H

#include <stdint.h>
#include <limine.h>

/* Инициализировать собственные таблицы страниц:
 * - при поддержке 1 ГБ страниц: identity+HHDM для ВСЕХ диапазонов карты
 *   памяти (кроме BAD), а не фиксированных 4 ГБ
 * - иначе fallback: identity-map первые 4 ГБ физической памяти (2 МБ
 *   страницы) и те же 4 ГБ в области HHDM
 * - отобразить сам образ ядра (базисы загрузчик отдаёт по запросу
 *   executable address)
 * - загрузить физический адрес pml4 в CR3
 * Если базисы ядра неизвестны (0), CR3 не переключается.
 */
void paging_init(uint64_t hhdm_offset, uint64_t kernel_phys_base,
                 uint64_t kernel_virt_base,
                 struct limine_memmap_response *memmap);

/* Базисы ядра, переданные в paging_init. */
void paging_get_bases(uint64_t *phys, uint64_t *virt);

/* Физический адрес PML4 (для запуска AP-ядер). */
uint64_t paging_pml4_phys(void);

/* Вернуть физический адрес, соответствующий виртуальному (через HHDM). */
static inline uint64_t phys_from_virt(uint64_t hhdm, uint64_t virt) {
    if (virt >= hhdm) return virt - hhdm;
    return virt;
}

#endif
