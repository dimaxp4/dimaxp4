#ifndef NYKLIMA_DISK_H
#define NYKLIMA_DISK_H
#include <stdint.h>

int disk_read(uint32_t lba, uint8_t *buffer);
int disk_write(uint32_t lba, const uint8_t *buffer);
int disk_read_multi(uint32_t lba, uint8_t *buffer, uint16_t count);
int disk_write_multi(uint32_t lba, const uint8_t *buffer, uint16_t count);

#endif