#ifndef NYKLIMA_FS_H
#define NYKLIMA_FS_H
#include <stdint.h>
#include <stddef.h>
#define FS_MAX_FILES 32
#define FS_NAME_MAX 32
#define FS_DATA_MAX 512
struct fs_file { char name[FS_NAME_MAX]; uint8_t data[FS_DATA_MAX]; size_t size; uint32_t disk_size; uint16_t first_cluster; uint32_t dir_sector; uint16_t dir_offset; int used; };
void fs_init(void);
int fs_create(const char *name);
int fs_write(const char *name, const uint8_t *data, size_t size);
int fs_read(const char *name, uint8_t *out, size_t cap, size_t *written);
int fs_delete(const char *name);
size_t fs_list(char names[][FS_NAME_MAX], size_t cap);
void fs_mark_dirty(void);
int fs_is_ram(void);
uint32_t fs_disk_kb(void);
/* Реальный размер файла на диске (может быть больше кэша FS_DATA_MAX). */
uint32_t fs_disk_size(const char *name);
/* Прямое чтение цепочки кластеров в буфер произвольного размера. */
int fs_read_direct(const char *name, uint8_t *out, uint32_t cap, uint32_t *written);
#endif
