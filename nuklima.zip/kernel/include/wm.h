#ifndef NYKLIMA_WM_H
#define NYKLIMA_WM_H

#include <stdint.h>
#include <stddef.h>
#include <fs.h>

struct limine_framebuffer;

#define WM_MAX_WINDOWS 6
#define WM_TASKBAR_H 28

enum {
    WM_CONTENT_FILES = 1,
    WM_CONTENT_INFO,
    WM_CONTENT_CUBE,
    WM_CONTENT_DETAIL,
    WM_CONTENT_SETTINGS
};

struct wm_window {
    int used;
    int x, y, w, h;
    int z;
    int content;
    char title[14];
    /* files */
    int selected, scroll;
    /* detail */
    char detail_name[FS_NAME_MAX];
    uint8_t detail_data[FS_DATA_MAX];
    size_t detail_size;
};

void wm_init(int screen_w, int screen_h);
struct wm_window *wm_open(int content, const char *title, int x, int y, int w, int h);
void wm_close(struct wm_window *win);
void wm_toggle(int content, const char *title, int x, int y, int w, int h);
struct wm_window *wm_focused(void);
int wm_has_cube(void);

/* Отрисовать рабочий стол: обои, окна, taskbar. */
void wm_draw(struct limine_framebuffer *fb, uint32_t ticks);

/* Окно куба (для анимации) или NULL. */
struct wm_window *wm_cube_window(void);

/* Перерисовать в backbuffer только это окно (+перекрывающие сверху) и
   блитнуть в экран только его прямоугольник. В ~20 раз дешевле полного
   кадра — используется для плавной анимации. */
void wm_repaint_window(struct limine_framebuffer *fb, struct wm_window *win, uint32_t ticks);

/* Обработка события мыши; возвращает 1, если нужна перерисовка. */
int wm_mouse(int mx, int my, int buttons);

/* Горячие клавиши рабочего стола; возвращает 1, если нужна перерисовка. */
int wm_key(uint8_t scancode, uint32_t ticks);

#endif
