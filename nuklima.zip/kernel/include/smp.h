#ifndef NYKLIMA_SMP_H
#define NYKLIMA_SMP_H

#include <stdint.h>
#include <limine.h>

#define SMP_MAX_CPUS 4

/* Запустить AP-ядра (ACPI MADT + INIT/SIPI). Возвращает число AP онлайн.
   rsdp/memmap — ответы Limine, pml4_phys — физический адрес PML4 ядра. */
int smp_init(struct limine_rsdp_response *rsdp,
             struct limine_memmap_response *memmap,
             uint64_t pml4_phys);

int smp_up(void);              /* SMP инициализирован */
int smp_self_index(void);      /* индекс текущего CPU (0 = BSP) */
int smp_online_count(void);

/* Маршрутизация legacy IRQ через IOAPIC и подтверждение прерывания LAPIC. */
int smp_ioapic_ready(void);
void smp_irq_eoi(void);

/* Спинлок (x86 TSO + lock prefix). */
static inline void spin_lock(volatile int *l) {
    for (;;) {
        while (*l) __asm__ volatile("pause");
        if (__sync_lock_test_and_set(l, 1) == 0) return;
    }
}
static inline void spin_unlock(volatile int *l) {
    __sync_lock_release(l);
}

#endif
