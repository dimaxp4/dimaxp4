#ifndef NYKLIMA_GFX_H
#define NYKLIMA_GFX_H

#include <stdint.h>
#include <stddef.h>

struct limine_framebuffer;

/* Инициализировать рендерер под разрешение кадрового буфера:
   выделить цветовой и Z-буферы, включить SSE. */
void gfx_init(size_t width, size_t height);

/* Отрисовать кадр сцены (вращающийся куб) на весь экран.
   time_ticks — время в тиках таймера 100 Гц. Возвращает 1 при успехе. */
int gfx_render_frame(struct limine_framebuffer *fb, uint32_t time_ticks);

/* Отрисовать куб в прямоугольник кадрового буфера (для окна). */
int gfx_render_cube_fb(struct limine_framebuffer *fb, int x, int y, uint32_t time_ticks);

/* Слот кадра, отрендеренного NYKLIMA G1 на хосте (мост 3050→FAT16→NGL).
   id текстуры NGL или -1. Кадр рисуется фоном в окне CUBE. */
void gfx_set_frame_texture(int id);

int gfx_ready(void);

/* --- NGL: OpenGL-подобный программный конвейер (immediate mode) ---
   Сначала ngl_bind_target (куда рисовать), затем viewport/clear,
   матрицы (PROJECTION/MODEVIEW), геометрия между ngl_begin/ngl_end.
   Цвет — интерполируется по вершинам (Gouraud), Z-тест всегда включён. */

enum { NGL_TRIANGLES = 1, NGL_QUADS };
enum { NGL_PROJECTION = 0, NGL_MODELVIEW = 1 };

/* Привязать цель рендера (буферы выделяются через pmm_alloc_contig). */
void ngl_bind_target(uint32_t *pix, float *zbuf, int w, int h);

void ngl_viewport(int x, int y, int w, int h);
void ngl_clear_color(float r, float g, float b);
void ngl_clear(void);

void ngl_matrix_mode(int mode);
void ngl_load_identity(void);
void ngl_perspective(float fovy_deg, float aspect, float znear, float zfar);
void ngl_translatef(float x, float y, float z);
/* Вращение вокруг произвольной оси (формула Родригеса). */
void ngl_rotatef(float angle_deg, float ax, float ay, float az);

void ngl_color3f(float r, float g, float b);
void ngl_begin(int mode);
void ngl_vertex3f(float x, float y, float z);
void ngl_end(void);

/* --- Текстуры (RGB24, repeat wrap, билинейная фильтрация, GL_MODULATE) ---
   ngl_texture() копирует данные в пул и возвращает id (или -1).
   ngl_bind_texture(-1) отключает текстурирование — только цвета вершин. */
#define NGL_MAX_TEX 4
#define NGL_TEX_MAX 128

int ngl_texture(int w, int h, const uint8_t *rgb);
void ngl_bind_texture(int id);
void ngl_tex_coord2f(float u, float v);

/* --- Состояние конвейера (аналоги glEnable/glDepthMask/glFog) ---
   NGL_BLEND: смешивание dst = src*a + dst*(1-a), alpha из ngl_color4f.
   NGL_FOG: линейный туман по глазной дистанции (start..end, цвет).
   ngl_depth_mask(0) — рисовать без записи в Z-буфер (для прозрачного
   прохода после непрозрачной геометрии). */
enum { NGL_BLEND = 1, NGL_FOG = 2 };

void ngl_enable(int cap);
void ngl_disable(int cap);
void ngl_color4f(float r, float g, float b, float a);
void ngl_depth_mask(int flag);
void ngl_fog_range(float start, float end);
void ngl_fog_color(float r, float g, float b);

/* 2D-спрайт: блит текстуры (билинейно) в прямоугольник кадрового буфера. */
void gfx_blit_texture(struct limine_framebuffer *fb, int id, int x, int y, int w, int h);

#endif
