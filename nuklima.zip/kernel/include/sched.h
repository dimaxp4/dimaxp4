#ifndef NYKLIMA_SCHED_H
#define NYKLIMA_SCHED_H

#include <stdint.h>

/* Кооперативная многопоточность ядра: потоки со своими стеками,
   round-robin переключение контекста (callee-saved), sleep/wake.
   Фундамент под вытесняющую многозадачность и будущий SMP. */

void sched_init(void);

/* Создать поток; возвращает 0 при успехе. Стек 32 КБ из PMM. */
int thread_create(const char *name, void (*fn)(void *), void *arg);

/* Отдать процессор следующему готовому потоку. */
void thread_yield(void);

/* Спать n тиков PIT (100 Гц). */
void thread_sleep(uint32_t ticks);

/* Число живых потоков. */
int sched_thread_count(void);

/* SMP: вызываются на AP-ядре после старта (не возвращаются). */
void sched_ap_online(int idx);
void sched_ap_idle(int idx);

#endif
