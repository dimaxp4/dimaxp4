#ifndef NYKLIMA_FBDRAW_H
#define NYKLIMA_FBDRAW_H

#include <stdint.h>
#include <stddef.h>

struct limine_framebuffer;

/* Палитра NYKLIMA */
#define FB_BG      0x101828
#define FB_PANEL   0x162238
#define FB_BORDER  0x315176
#define FB_CYAN    0x40d9ff
#define FB_GREEN   0x54e38e
#define FB_TEXT    0xd6e4f0
#define FB_MUTED   0x8aa4bd
#define FB_ORANGE  0xffc857
#define FB_RED     0xff6f7c
#define FB_PURPLE  0xb28dff
#define FB_DARK    0x0a0f18

void fb_fill(struct limine_framebuffer *fb, size_t x, size_t y, size_t w, size_t h, uint32_t color);
void fb_rect(struct limine_framebuffer *fb, size_t x, size_t y, size_t w, size_t h, uint32_t color);
void fb_text(struct limine_framebuffer *fb, size_t x, size_t y, const char *s, uint32_t color, size_t scale);
void fb_text_uint(struct limine_framebuffer *fb, size_t x, size_t y, uint32_t v, uint32_t color, size_t scale);

#endif
