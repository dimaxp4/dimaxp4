#ifndef NYKLIMA_TEXLOAD_H
#define NYKLIMA_TEXLOAD_H

/* Загрузка BMP-файла (24bpp, BI_RGB) из FAT16 в текстуру NGL.
   Крупные изображения даунскейлятся до 128x128 (nearest).
   Возвращает id текстуры или отрицательный код ошибки:
   -1 нет файла, -2 нет памяти, -3 ошибка чтения, -4 не BMP24, -5 слишком большой. */
int texload_bmp(const char *name);

#endif
