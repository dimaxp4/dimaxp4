#ifndef NYK_STDDEF_H
#define NYK_STDDEF_H
#if !defined(_MSC_VER)
typedef unsigned long size_t;
#endif
#define NULL ((void*)0)
#endif
