#ifndef NYKLIMA_PGM_H
#define NYKLIMA_PGM_H

#include <stdint.h>
#include <stddef.h>
#include <fs.h>

struct limine_framebuffer;

/* API, которое ядро передаёт программе. Программа НЕ связана с ядром
   статически — всё общение через эту таблицу (мини-syscall-интерфейс). */
struct pgm_api {
    int version;
    struct limine_framebuffer *fb;
    volatile const uint32_t *ticks; /* тики PIT 100 Гц */
    /* неблокирующее чтение клавиатуры: 1 — сканкод получен */
    int (*kbd_pop)(uint8_t *sc);
    /* примитивы fbdraw */
    void (*fill)(struct limine_framebuffer *, size_t, size_t, size_t, size_t, uint32_t);
    void (*rect)(struct limine_framebuffer *, size_t, size_t, size_t, size_t, uint32_t);
    void (*text)(struct limine_framebuffer *, size_t, size_t, const char *, uint32_t, size_t);
    void (*text_uint)(struct limine_framebuffer *, size_t, size_t, uint32_t, uint32_t, size_t);
    /* текстуры: загрузка BMP из FAT16 и 2D-спрайт (рендерился на 3050) */
    int (*texload)(const char *name);
    void (*sprite)(struct limine_framebuffer *, int id, int x, int y, int w, int h);
};

/* Загрузить ELF-программу из FAT16 и запустить (функция nyklima_main(api)).
   Программа обязана быть PIE (relative relocs применяет загрузчик).
   Возврат из nyklima_main = возврат в рабочий стол.
   0 — успех, <0 — код ошибки загрузчика. */
int pgm_run(const char *name, struct pgm_api *api);

#endif
