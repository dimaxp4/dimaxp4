#ifndef NYKLIMA_CPU_H
#define NYKLIMA_CPU_H

#include <stdint.h>

/* Детекция и включение расширенных инструкций CPU (CPUID + XCR0).
   cpu_init() обязан вызываться до любого кода, использующего AVX. */
void cpu_init(void);

int cpu_has_avx(void);
int cpu_has_avx2(void);
int cpu_has_avx512f(void);
int cpu_has_sse42(void);
int cpu_has_bmi2(void);
uint64_t cpu_xcr0(void);

#endif
