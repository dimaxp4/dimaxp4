#ifndef NYKLIMA_MEM_H
#define NYKLIMA_MEM_H

#include <stdint.h>
#include <stddef.h>

#include <limine.h>

/* Инициализация bitmap-PMM по карте памяти Limine; диапазон ядра исключается
   из выдачи (kernel_phys_end = 0 отключает проверку). */
void pmm_init(uint64_t hhdm_offset, struct limine_memmap_response *memmap,
              uint64_t kernel_phys_base, uint64_t kernel_phys_end);

/* Выделить/освободить физическую страницу 4 КБ (виртуальный адрес через HHDM). */
void *pmm_alloc(void);
void pmm_free(void *page);

/* Выделить pages подряд идущих страниц (виртуальный адрес через HHDM). */
void *pmm_alloc_contig(uint64_t pages);

/* Освободить pages подряд идущих страниц, выделенных pmm_alloc_contig. */
void pmm_free_contig(void *page, uint64_t pages);

/* Число свободных страниц. */
uint64_t pmm_free_pages(void);

/* Общее число страниц в PMM-регионе. */
uint64_t pmm_total_pages(void);

/* HHDM offset от Limine. */
uint64_t mem_hhdm(void);

/* Подключить кучу: start — виртуальный адрес (через HHDM), length — байты. */
void heap_attach(void *start, size_t length);

/* Аллокатор с реальным освобождением. */
void *kmalloc(size_t size);
void kfree(void *ptr);

#endif