/* Планировщик потоков (SMP): per-CPU current, глобальная очередь с
   спинлоком, round-robin, sleep/wake. Состояния:
   RUNNABLE — можно брать любому CPU, RUNNING — выполняется, SLEEPING — ждёт,
   DEAD — завершён. */

#include <stdint.h>
#include <stddef.h>
#include <mem.h>
#include <sched.h>
#include <smp.h>

#if !defined(_MSC_VER)

#define MAX_THREADS 8
#define THREAD_STACK_PAGES 8 /* 32 КБ */

enum { T_RUNNABLE = 1, T_RUNNING, T_SLEEPING, T_DEAD };

struct thread {
    int used;
    volatile int state;
    uint32_t wake_tick;
    uint64_t rsp;
    uint8_t *stack;
    const char *name;
    void (*fn)(void *);
    void *arg;
    int owner_cpu; /* -1 = любой CPU; иначе привязан */
};

static struct thread threads[MAX_THREADS];
static struct thread *cpu_current[SMP_MAX_CPUS];
static struct thread idle_threads[SMP_MAX_CPUS];
static volatile int rq_lock = 0;
static int thread_count = 0;

extern volatile uint32_t pit_ticks;

/* Переключение контекста. naked: аргументы rdi=from, rsi=to.
   offsetof(struct thread, rsp) == 16 — закреплено статик-ассертом ниже. */
__attribute__((naked)) static void thread_switch(struct thread *from, struct thread *to) {
    __asm__ volatile(
        "pushq %rbx\n\t"
        "pushq %rbp\n\t"
        "pushq %r12\n\t"
        "pushq %r13\n\t"
        "pushq %r14\n\t"
        "pushq %r15\n\t"
        "movq %rsp, 16(%rdi)\n\t"
        "movq 16(%rsi), %rsp\n\t"
        "popq %r15\n\t"
        "popq %r14\n\t"
        "popq %r13\n\t"
        "popq %r12\n\t"
        "popq %rbp\n\t"
        "popq %rbx\n\t"
        "ret\n\t");
}

_Static_assert(__builtin_offsetof(struct thread, rsp) == 16, "thread.rsp must be at offset 16");

static void thread_trampoline(void) {
    struct thread *t = cpu_current[smp_self_index()];
    t->fn(t->arg);
    spin_lock(&rq_lock);
    t->state = T_DEAD;
    spin_unlock(&rq_lock);
    for (;;) thread_yield();
}

void sched_init(void) {
    for (int i = 0; i < MAX_THREADS; ++i) threads[i].used = 0;
    for (int i = 0; i < SMP_MAX_CPUS; ++i) cpu_current[i] = NULL;
    threads[0].used = 1;
    threads[0].state = T_RUNNING;
    threads[0].name = "main";
    threads[0].stack = NULL;
    threads[0].owner_cpu = 0;
    cpu_current[0] = &threads[0];
    thread_count = 1;
}

int thread_create(const char *name, void (*fn)(void *), void *arg) {
    spin_lock(&rq_lock);
    for (int i = 1; i < MAX_THREADS; ++i) {
        if (threads[i].used) continue;
        uint8_t *stack = (uint8_t *)pmm_alloc_contig(THREAD_STACK_PAGES);
        if (!stack) { spin_unlock(&rq_lock); return -1; }
        struct thread *t = &threads[i];
        t->used = 1;
        t->state = T_RUNNABLE;
        t->name = name;
        t->fn = fn;
        t->arg = arg;
        t->stack = stack;
        t->wake_tick = 0;
        t->owner_cpu = -1;
        size_t size = THREAD_STACK_PAGES * 4096;
        uint64_t top = (uint64_t)(stack + size);
        *(uint64_t *)(top - 64) = 0;
        *(uint64_t *)(top - 56) = 0;
        *(uint64_t *)(top - 48) = 0;
        *(uint64_t *)(top - 40) = 0;
        *(uint64_t *)(top - 32) = 0;
        *(uint64_t *)(top - 24) = 0;
        *(uint64_t *)(top - 16) = (uint64_t)thread_trampoline;
        t->rsp = top - 64;
        thread_count++;
        spin_unlock(&rq_lock);
        return 0;
    }
    spin_unlock(&rq_lock);
    return -1;
}

/* Вызывается под rq_lock. */
static struct thread *pick_next_locked(struct thread *from, int idx, uint32_t now) {
    /* idle_threads не принадлежат массиву threads: не вычитать несвязанные
       указатели. Для idle начинаем обход с первого пользовательского слота. */
    int start = (from >= threads && from < threads + MAX_THREADS)
        ? (int)(from - threads) : MAX_THREADS - 1;
    for (int k = 1; k <= MAX_THREADS; ++k) {
        struct thread *t = &threads[(start + k) % MAX_THREADS];
        if (!t->used || t == from) continue;
        if (t->owner_cpu >= 0 && t->owner_cpu != idx) continue;
        if (t->state == T_SLEEPING && (int32_t)(now - t->wake_tick) >= 0) t->state = T_RUNNABLE;
        if (t->state == T_RUNNABLE) {
            t->state = T_RUNNING;
            return t;
        }
    }
    return from;
}

/* Если переключаться некуда, спящий поток не должен продолжать работу:
   ждём PIT, пока не наступит wake_tick. */
static void wait_until_awake(struct thread *from) {
    while (from->state == T_SLEEPING) {
        if ((int32_t)(pit_ticks - from->wake_tick) >= 0) {
            from->state = T_RUNNABLE;
            break;
        }
        __asm__ volatile("hlt");
    }
    if (from->state == T_RUNNABLE) from->state = T_RUNNING;
}

void thread_yield(void) {
    int idx = smp_self_index();
    struct thread *from = cpu_current[idx];
    if (!from) return;
    spin_lock(&rq_lock);
    if (from->state == T_RUNNING) from->state = T_RUNNABLE;
    struct thread *to = pick_next_locked(from, idx, pit_ticks);
    cpu_current[idx] = to;
    spin_unlock(&rq_lock);
    if (to != from) thread_switch(from, to);
}

void thread_sleep(uint32_t ticks) {
    int idx = smp_self_index();
    struct thread *from = cpu_current[idx];
    if (!from) return;
    spin_lock(&rq_lock);
    from->state = T_SLEEPING;
    from->wake_tick = pit_ticks + ticks;
    struct thread *to = pick_next_locked(from, idx, pit_ticks);
    cpu_current[idx] = to;
    spin_unlock(&rq_lock);
    if (to != from) thread_switch(from, to);
    else wait_until_awake(from);
}

int sched_thread_count(void) { return thread_count; }

/* --- AP --- */
static void ap_idle(int idx) {
    struct thread *idle = &idle_threads[idx];
    idle->used = 1;
    idle->state = T_RUNNING;
    idle->name = "idle";
    idle->owner_cpu = idx;
    idle->stack = NULL;
    cpu_current[idx] = idle;
    for (;;) {
        spin_lock(&rq_lock);
        struct thread *to = pick_next_locked(idle, idx, pit_ticks);
        cpu_current[idx] = to;
        spin_unlock(&rq_lock);
        if (to != idle) thread_switch(idle, to);
        else __asm__ volatile("pause");
    }
}

void sched_ap_online(int idx) {
    (void)idx;
    spin_lock(&rq_lock);
    thread_count++; /* idle-поток */
    spin_unlock(&rq_lock);
}

void sched_ap_idle(int idx) { ap_idle(idx); }

#else

void sched_init(void) { }
int thread_create(const char *name, void (*fn)(void *), void *arg) { (void)name; (void)fn; (void)arg; return -1; }
void thread_yield(void) { }
void thread_sleep(uint32_t ticks) { (void)ticks; }
int sched_thread_count(void) { return 1; }
void sched_ap_online(int idx) { (void)idx; }
void sched_ap_idle(int idx) { (void)idx; }

#endif