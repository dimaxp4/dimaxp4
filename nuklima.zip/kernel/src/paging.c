#include <paging.h>

#define PAGE_SIZE 4096
#define HUGE_PAGE_SIZE (2ULL * 1024 * 1024)
#define ENTRIES_PER_TABLE 512

#define PTE_PRESENT  (1ULL << 0)
#define PTE_WRITABLE (1ULL << 1)
#define PTE_HUGE     (1ULL << 7)

#define PML4_IDX(a) (((a) >> 39) & 0x1ff)
#define PDPT_IDX(a) (((a) >> 30) & 0x1ff)

/* Все таблицы живут в .bss ядра по виртуальным адресам верхней половины,
   но записи PTE и CR3 обязаны содержать ФИЗИЧЕСКИЕ адреса. Физический
   адрес страницы ядра = kernel_phys_base + (виртуальный - kernel_virt_base);
   оба базиса загрузчик отдаёт по запросу executable address. */
static uint64_t g_phys_base = 0;
static uint64_t g_virt_base = 0;

static uint64_t pml4[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));

static uint64_t pt_phys(const void *table) {
    return g_phys_base + ((uint64_t)table - g_virt_base);
}

void paging_get_bases(uint64_t *phys, uint64_t *virt) {
    if (phys) *phys = g_phys_base;
    if (virt) *virt = g_virt_base;
}

uint64_t paging_pml4_phys(void) {
    return pt_phys(&pml4[0]);
}

static uint64_t pdpt_low[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE))); /* identity [0..3] + HHDM [start..] в одном PDPT */
static uint64_t pd_id[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t pd_hhdm[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t pdpt_ext[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE))); /* HHDM, когда PML4 != 0 */
static uint64_t pdpt_kern[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t pd_kern[ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));
static uint64_t pt_kern[4][ENTRIES_PER_TABLE] __attribute__((aligned(PAGE_SIZE)));

void paging_init(uint64_t hhdm_offset, uint64_t kernel_phys_base,
                 uint64_t kernel_virt_base,
                 struct limine_memmap_response *memmap) {
    /* .bss уже обнулён, но перестрахуемся. */
    for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
        pml4[i] = 0;
        pdpt_low[i] = 0;
        pdpt_ext[i] = 0;
        pdpt_kern[i] = 0;
        pd_kern[i] = 0;
    }
    for (int p = 0; p < 4; ++p) {
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
            pd_id[p][i] = 0;
            pd_hhdm[p][i] = 0;
            pt_kern[p][i] = 0;
        }
    }

    g_phys_base = kernel_phys_base;
    g_virt_base = kernel_virt_base;
    if (!g_phys_base || !g_virt_base) return;

    int gb_pages = 0;
    {
        uint32_t a, b, c, d;
        __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000000), "c"(0));
        if (a >= 0x80000001) {
            __asm__ volatile("cpuid" : "=a"(a), "=b"(b), "=c"(c), "=d"(d) : "a"(0x80000001), "c"(0));
            gb_pages = (d >> 26) & 1; /* PDPE1GB */
        }
    }

    if (gb_pages && memmap && hhdm_offset && hhdm_offset < (1ULL << 39)) {
        /* Полная карта памяти 1 ГБ страницами: identity по pdpt_low[g],
           HHDM — по pdpt_low[(hhdm>>30)+g] (та же запись). Всё в одном
           PDPT без 32 КБ промежуточных таблиц. */
        pml4[0] = pt_phys(&pdpt_low[0]) | PTE_PRESENT | PTE_WRITABLE;
        for (uint64_t i = 0; i < memmap->entry_count; ++i) {
            struct limine_memmap_entry *e = memmap->entries[i];
            if (!e || e->type == LIMINE_MEMMAP_BAD_MEMORY || !e->length) continue;
            uint64_t lo = e->base, hi = e->base + e->length;
            for (uint64_t g = lo >> 30; g <= (hi ? (hi - 1) >> 30 : 0) && g < 256; ++g) {
                uint64_t pte = (g << 30) | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
                pdpt_low[g] = pte;                       /* identity g ГБ */
                uint64_t h_idx = (hhdm_offset >> 30) + g;
                if (h_idx < ENTRIES_PER_TABLE) pdpt_low[h_idx] = pte; /* HHDM */
            }
        }
    } else {
        /* Fallback: identity-map первые 4 ГБ: PML4[0] → pdpt_low[0..3]. */
        pml4[0] = pt_phys(&pdpt_low[0]) | PTE_PRESENT | PTE_WRITABLE;
        for (int pdpt_idx = 0; pdpt_idx < 4; ++pdpt_idx) {
            pdpt_low[pdpt_idx] = pt_phys(&pd_id[pdpt_idx][0]) | PTE_PRESENT | PTE_WRITABLE;
            for (int pd_idx = 0; pd_idx < ENTRIES_PER_TABLE; ++pd_idx) {
                uint64_t phys = (uint64_t)(pdpt_idx * ENTRIES_PER_TABLE + pd_idx) * HUGE_PAGE_SIZE;
                pd_id[pdpt_idx][pd_idx] = phys | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
            }
        }

        /* HHDM: те же 4 ГБ по базису от загрузчика. Важный момент — HHDM offset
           (обычно 0x4000000000) тоже попадает в PML4[0], поэтому его записи
           кладутся в ТОТ ЖЕ pdpt_low, а не отдельный: иначе перезапись pml4[0]
           снимала identity-отображение, стек (~0x1000000) становился немапленым,
           и первый же IRQ пушил в отсутствующую страницу → triple fault. */
        uint64_t pml4_idx = PML4_IDX(hhdm_offset);
        uint64_t pdpt_start = PDPT_IDX(hhdm_offset);
        if (pml4_idx != 0) {
            /* HHDM в другом PML4-слоте — отдельный PDPT. */
            if (pml4_idx >= ENTRIES_PER_TABLE) return;
            pml4[pml4_idx] = pt_phys(&pdpt_ext[0]) | PTE_PRESENT | PTE_WRITABLE;
            for (int pdpt_offset = 0; pdpt_offset < 4; ++pdpt_offset) {
                int pdpt_idx = (int)(pdpt_start + pdpt_offset);
                if (pdpt_idx < 0 || pdpt_idx >= ENTRIES_PER_TABLE) continue;
                pdpt_ext[pdpt_idx] = pt_phys(&pd_hhdm[pdpt_offset][0]) | PTE_PRESENT | PTE_WRITABLE;
                for (int pd_idx = 0; pd_idx < ENTRIES_PER_TABLE; ++pd_idx) {
                    uint64_t phys = (uint64_t)(pdpt_offset * ENTRIES_PER_TABLE + pd_idx) * HUGE_PAGE_SIZE;
                    pd_hhdm[pdpt_offset][pd_idx] = phys | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
                }
            }
        } else {
            /* HHDM и identity делят PML4[0] — дополняем pdpt_low. */
            for (int pdpt_offset = 0; pdpt_offset < 4; ++pdpt_offset) {
                int pdpt_idx = (int)(pdpt_start + pdpt_offset);
                if (pdpt_idx < 0 || pdpt_idx >= ENTRIES_PER_TABLE) continue;
                pdpt_low[pdpt_idx] = pt_phys(&pd_hhdm[pdpt_offset][0]) | PTE_PRESENT | PTE_WRITABLE;
                for (int pd_idx = 0; pd_idx < ENTRIES_PER_TABLE; ++pd_idx) {
                    uint64_t phys = (uint64_t)(pdpt_offset * ENTRIES_PER_TABLE + pd_idx) * HUGE_PAGE_SIZE;
                    pd_hhdm[pdpt_offset][pd_idx] = phys | PTE_PRESENT | PTE_WRITABLE | PTE_HUGE;
                }
            }
        }
    }

    /* Образ ядра: 4КБ-страницы, до 8 МБ от виртуального базиса.
       Базис 0xffffffff80000000 выровнен на 1 ГБ и лежит в начале своего
       PDPT-региона (k_pdpt), поэтому ядро занимает PD-записи 0..3 —
       индексировать нужно от нуля, а не от k_pdpt. */
    uint64_t k_pml4 = PML4_IDX(kernel_virt_base);
    uint64_t k_pdpt = PDPT_IDX(kernel_virt_base);
    if (k_pml4 >= ENTRIES_PER_TABLE || k_pdpt >= ENTRIES_PER_TABLE) return;
    pml4[k_pml4] = pt_phys(&pdpt_kern[0]) | PTE_PRESENT | PTE_WRITABLE;
    pdpt_kern[k_pdpt] = pt_phys(&pd_kern[0]) | PTE_PRESENT | PTE_WRITABLE;
    for (int pd = 0; pd < 4; ++pd) {
        pd_kern[pd] = pt_phys(&pt_kern[pd][0]) | PTE_PRESENT | PTE_WRITABLE;
        for (int i = 0; i < ENTRIES_PER_TABLE; ++i) {
            uint64_t off = ((uint64_t)pd * ENTRIES_PER_TABLE + i) * PAGE_SIZE;
            pt_kern[pd][i] = (kernel_phys_base + off) | PTE_PRESENT | PTE_WRITABLE;
        }
    }

    /* CR3 принимает только физический адрес. */
    uint64_t pml4_phys = pt_phys(&pml4[0]);
    __asm__ volatile("movq %0, %%cr3" : : "r"(pml4_phys) : "memory");
}
