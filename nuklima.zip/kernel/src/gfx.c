/* Программный 3D-рендерер NYKLIMA G1 + конвейер NGL (OpenGL-подобный API).
   Растеризация треугольников с Z-буфером, Gouraud-интерполяция цвета,
   матрицы modelview/projection, immediate mode nglBegin/nglEnd.
   Компилируется с SSE: FP-математика только здесь, ISR её не используют. */

#include <stdint.h>
#include <stddef.h>
#include <limine.h>
#include <mem.h>
#include <gfx.h>
#include <cpu.h>

#if !defined(_MSC_VER)

typedef struct { float x, y, z; } vec3;
typedef struct { float m[4][4]; } mat4;

static uint32_t *pix_buf = NULL;
static float *z_buf = NULL;
static size_t g_w = 0, g_h = 0;

/* Буферы окна куба (рендер внутри оконного менеджера). */
#define WIN_CUBE_W 240
#define WIN_CUBE_H 180
static uint32_t *win_pix = NULL;
static float *win_z = NULL;

/* --- freestanding-математика (libm нет) --- */
static float sqrtf_(float x) { return __builtin_sqrtf(x); }

#define PI_F 3.14159265f

static float sinf_(float x) {
    /* Быстрый wrap в [-PI, PI]: while-цикл после часа аптайма крутился
       десятки тысяч итераций на вызов и фризил анимацию. */
    const float INV_2PI = 0.5f / PI_F;
    x -= (float)(int)(x * INV_2PI) * 2 * PI_F;
    if (x > PI_F) x -= 2 * PI_F;
    else if (x < -PI_F) x += 2 * PI_F;
    float x2 = x * x;
    /* ряд Тейлора: x - x^3/6 + x^5/120 - x^7/5040 + x^9/362880 */
    return x * (1.0f - x2 / 6.0f
                + x2 * x2 / 120.0f
                - x2 * x2 * x2 / 5040.0f
                + x2 * x2 * x2 * x2 / 362880.0f);
}

static float cosf_(float x) { return sinf_(x + PI_F / 2); }

/* --- SSE: подстрахуемся CR0/CR4 --- */
static void sse_init(void) {
    uint64_t cr0, cr4;
    __asm__ volatile("movq %%cr0, %0" : "=r"(cr0));
    cr0 &= ~(1ULL << 2);  /* EM = 0: разрешить FPU */
    cr0 &= ~(1ULL << 3);  /* TS = 0: нет ловушки устройства недоступно */
    cr0 |=  (1ULL << 1);  /* MP = 1 */
    __asm__ volatile("movq %0, %%cr0" : : "r"(cr0) : "memory");
    __asm__ volatile("movq %%cr4, %0" : "=r"(cr4));
    cr4 |= (1ULL << 9) | (1ULL << 10); /* OSFXSR | OSXMMEXCPT */
    __asm__ volatile("movq %0, %%cr4" : : "r"(cr4) : "memory");
}

/* --- векторная математика --- */
static vec3 v3_sub(vec3 a, vec3 b) { return (vec3){a.x - b.x, a.y - b.y, a.z - b.z}; }
static vec3 v3_cross(vec3 a, vec3 b) {
    return (vec3){a.y * b.z - a.z * b.y, a.z * b.x - a.x * b.z, a.x * b.y - a.y * b.x};
}
static float v3_dot(vec3 a, vec3 b) { return a.x * b.x + a.y * b.y + a.z * b.z; }
static vec3 v3_norm(vec3 a) {
    float len = sqrtf_(v3_dot(a, a));
    if (len <= 1e-8f) return (vec3){0, 0, -1};
    return (vec3){a.x / len, a.y / len, a.z / len};
}

/* --- матрицы (row-major, column-вектор: X' = row0 . (x,y,z,1)) --- */
static mat4 mat4_mul(mat4 a, mat4 b) {
    mat4 r;
    for (int i = 0; i < 4; ++i)
        for (int j = 0; j < 4; ++j) {
            float s = 0;
            for (int k = 0; k < 4; ++k) s += a.m[i][k] * b.m[k][j];
            r.m[i][j] = s;
        }
    return r;
}

static mat4 mat4_identity(void) {
    return (mat4){.m = {
        {1, 0, 0, 0},
        {0, 1, 0, 0},
        {0, 0, 1, 0},
        {0, 0, 0, 1}}};
}

/* Вращение вокруг произвольной оси — формула Родригеса. */
static mat4 mat4_rotate(float rad, float ax, float ay, float az) {
    float len = sqrtf_(ax * ax + ay * ay + az * az);
    if (len < 1e-8f) return mat4_identity();
    ax /= len; ay /= len; az /= len;
    float c = cosf_(rad), s = sinf_(rad), t = 1.0f - c;
    return (mat4){.m = {
        {t * ax * ax + c,    t * ax * ay - s * az, t * ax * az + s * ay, 0},
        {t * ax * ay + s * az, t * ay * ay + c,    t * ay * az - s * ax, 0},
        {t * ax * az - s * ay, t * ay * az + s * ax, t * az * az + c,   0},
        {0, 0, 0, 1}}};
}

static mat4 mat4_translate(float x, float y, float z) {
    return (mat4){.m = {
        {1, 0, 0, x},
        {0, 1, 0, y},
        {0, 0, 1, z},
        {0, 0, 0, 1}}};
}

static mat4 mat4_perspective(float fov_y_deg, float aspect, float near, float far) {
    /* f = 1/tan(fov/2) = cos/sin — без tanf. */
    float half = fov_y_deg * PI_F / 180.0f * 0.5f;
    float s = sinf_(half), c = cosf_(half);
    float f = c / s;
    return (mat4){.m = {
        {f / aspect, 0, 0, 0},
        {0, f, 0, 0},
        {0, 0, (far + near) / (near - far), 2 * far * near / (near - far)},
        {0, 0, -1, 0}}};
}

/* Преобразовать вершину: возвращает xyz, w через указатель. */
static vec3 mat4_transform(mat4 m, vec3 v, float *w) {
    float x = m.m[0][0] * v.x + m.m[0][1] * v.y + m.m[0][2] * v.z + m.m[0][3];
    float y = m.m[1][0] * v.x + m.m[1][1] * v.y + m.m[1][2] * v.z + m.m[1][3];
    float z = m.m[2][0] * v.x + m.m[2][1] * v.y + m.m[2][2] * v.z + m.m[2][3];
    float ww = m.m[3][0] * v.x + m.m[3][1] * v.y + m.m[3][2] * v.z + m.m[3][3];
    if (w) *w = ww;
    return (vec3){x, y, z};
}

/* --- текущая цель растеризатора --- */
static uint32_t *cur_pix = NULL;
static float *cur_zb = NULL;
static size_t cur_w = 0, cur_h = 0;

/* --- NGL: состояние конвейера --- */
#define NGL_MAX_VERTS 256

struct ngl_vert {
    float sx, sy, sz;   /* экранные координаты, z в [0,1] */
    float r, g, b, a;
    float u, v;         /* текстурные координаты */
    float inv_w;        /* 1/w для перспективно-корректного UV */
    float fog;          /* фактор тумана: 1 = чистый цвет, 0 = туман */
};

static struct {
    mat4 proj, modelview;
    int matrix_mode;
    int vp_x, vp_y, vp_w, vp_h;
    float clear_r, clear_g, clear_b;
    float r, g, b, a;
    float cu, cv;       /* текущие текстурные координаты */
    int tex;            /* id активной текстуры, -1 = выключена */
    int blend, fog, depth_write;
    float fog_start, fog_end, fog_r, fog_g, fog_b;
    int drawing, mode, vcount, behind;
    struct ngl_vert verts[NGL_MAX_VERTS];
} ngl;

/* --- текстуры --- */
struct ngl_texture {
    int used;
    int w, h;
    uint8_t rgb[NGL_TEX_MAX * NGL_TEX_MAX * 3];
};
static struct ngl_texture ngl_tex_pool[NGL_MAX_TEX];

int ngl_texture(int w, int h, const uint8_t *rgb) {
    if (w <= 0 || h <= 0 || w > NGL_TEX_MAX || h > NGL_TEX_MAX || !rgb) return -1;
    for (int i = 0; i < NGL_MAX_TEX; ++i) {
        if (ngl_tex_pool[i].used) continue;
        ngl_tex_pool[i].used = 1;
        ngl_tex_pool[i].w = w;
        ngl_tex_pool[i].h = h;
        for (int j = 0; j < w * h * 3; ++j) ngl_tex_pool[i].rgb[j] = rgb[j];
        return i;
    }
    return -1;
}

void ngl_bind_texture(int id) {
    ngl.tex = (id >= 0 && id < NGL_MAX_TEX && ngl_tex_pool[id].used) ? id : -1;
}

void ngl_tex_coord2f(float u, float v) {
    ngl.cu = u;
    ngl.cv = v;
}

void ngl_bind_target(uint32_t *pix, float *zbuf, int w, int h) {
    cur_pix = pix;
    cur_zb = zbuf;
    cur_w = (size_t)(w > 0 ? w : 0);
    cur_h = (size_t)(h > 0 ? h : 0);
}

void ngl_viewport(int x, int y, int w, int h) {
    ngl.vp_x = x; ngl.vp_y = y; ngl.vp_w = w; ngl.vp_h = h;
}

void ngl_clear_color(float r, float g, float b) {
    ngl.clear_r = r; ngl.clear_g = g; ngl.clear_b = b;
}

void ngl_clear(void) {
    if (!cur_pix || !cur_zb) return;
    uint32_t cr = (uint32_t)(ngl.clear_r < 0 ? 0 : ngl.clear_r > 1 ? 255 : ngl.clear_r * 255.0f);
    uint32_t cg = (uint32_t)(ngl.clear_g < 0 ? 0 : ngl.clear_g > 1 ? 255 : ngl.clear_g * 255.0f);
    uint32_t cb = (uint32_t)(ngl.clear_b < 0 ? 0 : ngl.clear_b > 1 ? 255 : ngl.clear_b * 255.0f);
    uint32_t c = (cr << 16) | (cg << 8) | cb;
    size_t n = cur_w * cur_h;

    /* Не используем inline AVX здесь: clang может выбрать EVEX-кодировку
       vpbroadcastd (AVX-512), хотя условие разрешает только AVX2. Это
       приводит к #UD на процессорах без AVX-512. */
    for (size_t i = 0; i < n; ++i) cur_pix[i] = c;
    for (size_t i = 0; i < n; ++i) cur_zb[i] = 1e30f;
}

void ngl_matrix_mode(int mode) { ngl.matrix_mode = mode; }

void ngl_load_identity(void) {
    if (ngl.matrix_mode == NGL_PROJECTION) ngl.proj = mat4_identity();
    else ngl.modelview = mat4_identity();
}

void ngl_perspective(float fovy_deg, float aspect, float znear, float zfar) {
    if (ngl.matrix_mode != NGL_PROJECTION) return;
    ngl.proj = mat4_perspective(fovy_deg, aspect, znear, zfar);
}

void ngl_translatef(float x, float y, float z) {
    if (ngl.matrix_mode != NGL_MODELVIEW) return;
    /* Как в OpenGL: пост-умножение M <- M * T — трансляция применяется
       к вершине первой, уже существующая матрица после неё. */
    ngl.modelview = mat4_mul(ngl.modelview, mat4_translate(x, y, z));
}

void ngl_rotatef(float angle_deg, float ax, float ay, float az) {
    if (ngl.matrix_mode != NGL_MODELVIEW) return;
    float rad = angle_deg * PI_F / 180.0f;
    ngl.modelview = mat4_mul(ngl.modelview, mat4_rotate(rad, ax, ay, az));
}

void ngl_color3f(float r, float g, float b) {
    ngl.r = r; ngl.g = g; ngl.b = b; ngl.a = 1.0f;
}

void ngl_color4f(float r, float g, float b, float a) {
    ngl.r = r; ngl.g = g; ngl.b = b; ngl.a = a;
}

void ngl_enable(int cap) {
    if (cap == NGL_BLEND) ngl.blend = 1;
    else if (cap == NGL_FOG) ngl.fog = 1;
}

void ngl_disable(int cap) {
    if (cap == NGL_BLEND) ngl.blend = 0;
    else if (cap == NGL_FOG) ngl.fog = 0;
}

void ngl_depth_mask(int flag) { ngl.depth_write = flag ? 1 : 0; }

void ngl_fog_range(float start, float end) {
    ngl.fog_start = start;
    ngl.fog_end = end;
}

void ngl_fog_color(float r, float g, float b) {
    ngl.fog_r = r; ngl.fog_g = g; ngl.fog_b = b;
}

void ngl_begin(int mode) {
    ngl.drawing = 1;
    ngl.mode = mode;
    ngl.vcount = 0;
    ngl.behind = 0;
}

void ngl_vertex3f(float x, float y, float z) {
    if (!ngl.drawing || ngl.vcount >= NGL_MAX_VERTS) return;
    vec3 eye = mat4_transform(ngl.modelview, (vec3){x, y, z}, NULL);
    float w;
    vec3 clip = mat4_transform(ngl.proj, eye, &w);
    if (w <= 0.0f) { ngl.behind = 1; }
    float inv_w = 1.0f / w;
    struct ngl_vert *v = &ngl.verts[ngl.vcount++];
    v->sx = (clip.x * inv_w * 0.5f + 0.5f) * (float)ngl.vp_w + (float)ngl.vp_x;
    v->sy = (0.5f - clip.y * inv_w * 0.5f) * (float)ngl.vp_h + (float)ngl.vp_y;
    v->sz = clip.z * inv_w * 0.5f + 0.5f;
    v->r = ngl.r; v->g = ngl.g; v->b = ngl.b; v->a = ngl.a;
    v->u = ngl.cu; v->v = ngl.cv;
    v->inv_w = inv_w;
    /* Глаз смотрит вдоль -Z: дистанция до вершины = -eye.z. */
    float dist = -eye.z;
    if (dist < 0) dist = 0;
    float f = (ngl.fog_end - dist) / (ngl.fog_end - ngl.fog_start);
    if (f < 0) f = 0;
    if (f > 1) f = 1;
    v->fog = f;
}

/* Билинейный сэмпл текстуры с repeat wrap — порт sample() из renderer.py G1. */
static void tex_sample(const struct ngl_texture *t, float u, float v,
                       float *out_r, float *out_g, float *out_b) {
    u -= (float)(int)u; if (u < 0) u += 1.0f;
    v -= (float)(int)v; if (v < 0) v += 1.0f;
    float x = u * (t->w - 1);
    float y = (1.0f - v) * (t->h - 1);
    int x0 = (int)x, y0 = (int)y;
    if (x0 > t->w - 1) x0 = t->w - 1;
    if (y0 > t->h - 1) y0 = t->h - 1;
    int x1 = x0 + 1 < t->w ? x0 + 1 : t->w - 1;
    int y1 = y0 + 1 < t->h ? y0 + 1 : t->h - 1;
    float tx = x - x0, ty = y - y0;
    #define TEX_P(px, py, ch) t->rgb[((py) * (t->w) + (px)) * 3 + (ch)]
    for (int ch = 0; ch < 3; ++ch) {
        float c00 = TEX_P(x0, y0, ch), c10 = TEX_P(x1, y0, ch);
        float c01 = TEX_P(x0, y1, ch), c11 = TEX_P(x1, y1, ch);
        float c = (c00 * (1 - tx) + c10 * tx) * (1 - ty)
                + (c01 * (1 - tx) + c11 * tx) * ty;
        if (ch == 0) *out_r = c / 255.0f;
        else if (ch == 1) *out_g = c / 255.0f;
        else *out_b = c / 255.0f;
    }
    #undef TEX_P
}

/* Растеризация треугольника с Gouraud-интерполяцией цвета и Z-тестом. */
static void raster_tri(const struct ngl_vert *v0,
                       const struct ngl_vert *v1,
                       const struct ngl_vert *v2) {
    float x0 = v0->sx, y0 = v0->sy, z0 = v0->sz;
    float x1 = v1->sx, y1 = v1->sy, z1 = v1->sz;
    float x2 = v2->sx, y2 = v2->sy, z2 = v2->sz;

    float area = (x1 - x0) * (y2 - y0) - (x2 - x0) * (y1 - y0);
    if (area == 0.0f) return;
    float sign = area > 0 ? 1.0f : -1.0f;
    float inv_area = 1.0f / (area * sign); /* 1/|area| */

    int min_x = (int)(x0 < x1 ? (x0 < x2 ? x0 : x2) : (x1 < x2 ? x1 : x2));
    int min_y = (int)(y0 < y1 ? (y0 < y2 ? y0 : y2) : (y1 < y2 ? y1 : y2));
    int max_x = (int)(x0 > x1 ? (x0 > x2 ? x0 : x2) : (x1 > x2 ? x1 : x2));
    int max_y = (int)(y0 > y1 ? (y0 > y2 ? y0 : y2) : (y1 > y2 ? y1 : y2));
    if (min_x < 0) min_x = 0;
    if (min_y < 0) min_y = 0;
    if (max_x > (int)cur_w - 1) max_x = (int)cur_w - 1;
    if (max_y > (int)cur_h - 1) max_y = (int)cur_h - 1;
    if (min_x > max_x || min_y > max_y) return;

    for (int py = min_y; py <= max_y; ++py) {
        for (int px = min_x; px <= max_x; ++px) {
            float fx = (float)px + 0.5f, fy = (float)py + 0.5f;
            float e0 = (x1 - x0) * (fy - y0) - (y1 - y0) * (fx - x0);
            float e1 = (x2 - x1) * (fy - y1) - (y2 - y1) * (fx - x1);
            float e2 = (x0 - x2) * (fy - y2) - (y0 - y2) * (fx - x2);
            if (e0 * sign < 0 || e1 * sign < 0 || e2 * sign < 0) continue;
            float w0 = e0 * sign * inv_area;
            float w1 = e1 * sign * inv_area;
            float w2 = e2 * sign * inv_area;
            float z = w0 * z0 + w1 * z1 + w2 * z2;
            size_t idx = (size_t)py * cur_w + px;
            if (z < cur_zb[idx]) {
                float r = w0 * v0->r + w1 * v1->r + w2 * v2->r;
                float g = w0 * v0->g + w1 * v1->g + w2 * v2->g;
                float b = w0 * v0->b + w1 * v1->b + w2 * v2->b;
                if (ngl.tex >= 0) {
                    /* Перспективно-корректный UV: интерполируем u/w и 1/w,
                       затем делим — как делает настоящий OpenGL. */
                    const struct ngl_texture *t = &ngl_tex_pool[ngl.tex];
                    float iw = w0 * v0->inv_w + w1 * v1->inv_w + w2 * v2->inv_w;
                    if (iw > 1e-8f) {
                        float u = (w0 * v0->u * v0->inv_w + w1 * v1->u * v1->inv_w + w2 * v2->u * v2->inv_w) / iw;
                        float v = (w0 * v0->v * v0->inv_w + w1 * v1->v * v1->inv_w + w2 * v2->v * v2->inv_w) / iw;
                        float tr, tg, tb;
                        tex_sample(t, u, v, &tr, &tg, &tb);
                        r *= tr; g *= tg; b *= tb; /* GL_MODULATE */
                    }
                }
                /* Линейный туман по интерполированному фактору. */
                if (ngl.fog) {
                    float f = w0 * v0->fog + w1 * v1->fog + w2 * v2->fog;
                    r = r * f + ngl.fog_r * (1 - f);
                    g = g * f + ngl.fog_g * (1 - f);
                    b = b * f + ngl.fog_b * (1 - f);
                }
                if (r < 0) r = 0; if (r > 1) r = 1;
                if (g < 0) g = 0; if (g > 1) g = 1;
                if (b < 0) b = 0; if (b > 1) b = 1;
                uint32_t dst = cur_pix[idx];
                if (ngl.blend) {
                    /* dst = src * a + dst * (1-a), a из вершин (Gouraud). */
                    float a = w0 * v0->a + w1 * v1->a + w2 * v2->a;
                    if (a < 0) a = 0; if (a > 1) a = 1;
                    if (a < 1.0f) {
                        float dr = (float)((dst >> 16) & 0xff) / 255.0f;
                        float dg = (float)((dst >> 8) & 0xff) / 255.0f;
                        float db = (float)(dst & 0xff) / 255.0f;
                        r = r * a + dr * (1 - a);
                        g = g * a + dg * (1 - a);
                        b = b * a + db * (1 - a);
                    }
                }
                cur_pix[idx] = ((uint32_t)(r * 255.0f) << 16)
                             | ((uint32_t)(g * 255.0f) << 8)
                             | (uint32_t)(b * 255.0f);
                if (ngl.depth_write) cur_zb[idx] = z;
            }
        }
    }
}

static void ngl_emit_tri(int a, int b, int c) {
    if (ngl.behind) return;
    if (a >= ngl.vcount || b >= ngl.vcount || c >= ngl.vcount) return;
    raster_tri(&ngl.verts[a], &ngl.verts[b], &ngl.verts[c]);
}

void ngl_end(void) {
    ngl.drawing = 0;
    if (ngl.mode == NGL_QUADS) {
        for (int q = 0; q + 3 < ngl.vcount; q += 4) {
            ngl_emit_tri(q, q + 1, q + 2);
            ngl_emit_tri(q, q + 2, q + 3);
        }
    } else { /* NGL_TRIANGLES */
        for (int t = 0; t + 2 < ngl.vcount; t += 3)
            ngl_emit_tri(t, t + 1, t + 2);
    }
}

/* --- демо-сцена: куб через NGL + фоновый кадр от G1/3050 --- */
static int ngl_frame_tex = -1; /* текстура кадра NYKLIMA G1 (мост хост→ОС) */

void gfx_set_frame_texture(int id) { ngl_frame_tex = id; }

static void scene_cube(uint32_t time_ticks) {
    float time = (float)time_ticks * 0.01f;

    ngl_clear_color(0.03f, 0.05f, 0.09f);
    ngl_clear();

    /* Фоновый квад: кадр, отрендеренный G1 на 3050 (через FAT16-мост).
       Projection = identity, вершины в NDC; z = 1.0 (дальняя плоскость) и
       без записи в Z-буфер — иначе квад глубиной 0.75 перекрывал куб. */
    if (ngl_frame_tex >= 0) {
        ngl_depth_mask(0);
        ngl_matrix_mode(NGL_PROJECTION);
        ngl_load_identity();
        ngl_matrix_mode(NGL_MODELVIEW);
        ngl_load_identity();
        ngl_bind_texture(ngl_frame_tex);
        ngl_begin(NGL_QUADS);
        ngl_color4f(0.8f, 0.85f, 1.0f, 1.0f);
        ngl_tex_coord2f(0, 1); ngl_vertex3f(-1, -1, 1.0f);
        ngl_tex_coord2f(1, 1); ngl_vertex3f( 1, -1, 1.0f);
        ngl_tex_coord2f(1, 0); ngl_vertex3f( 1,  1, 1.0f);
        ngl_tex_coord2f(0, 0); ngl_vertex3f(-1,  1, 1.0f);
        ngl_end();
        ngl_bind_texture(-1);
        ngl_depth_mask(1);
    }

    ngl_matrix_mode(NGL_PROJECTION);
    ngl_load_identity();
    ngl_perspective(60.0f, (float)ngl.vp_w / (float)ngl.vp_h, 0.1f, 100.0f);

    ngl_matrix_mode(NGL_MODELVIEW);
    ngl_load_identity();
    ngl_translatef(0, 0, -3.5f);
    float a = time * 0.7f;
    ngl_rotatef(a * 0.7f * 57.2957795f, 1, 0, 0);
    ngl_rotatef(a * 57.2957795f, 0, 1, 0);

    static const float cube_v[8][3] = {
        {-1, -1,  1}, { 1, -1,  1}, { 1,  1,  1}, {-1,  1,  1},
        {-1, -1, -1}, { 1, -1, -1}, { 1,  1, -1}, {-1,  1, -1}
    };
    static const int cube_f[6][4] = {
        {0, 1, 2, 3}, {5, 4, 7, 6}, {1, 5, 6, 2},
        {4, 0, 3, 7}, {3, 2, 6, 7}, {4, 5, 1, 0}
    };
    /* вариация яркости по вершинам — виден Gouraud-градиент на грани */
    static const float shade[4] = {1.0f, 0.85f, 0.70f, 0.92f};

    vec3 light = v3_norm((vec3){0.45f, 0.65f, -0.61f});

    /* Процедурная шахматная текстура 16x16, генерируется один раз. */
    static int checker_id = -2;
    if (checker_id == -2) {
        static uint8_t checker[16 * 16 * 3];
        for (int ty = 0; ty < 16; ++ty)
            for (int tx = 0; tx < 16; ++tx) {
                int cell = ((tx / 4) + (ty / 4)) & 1;
                int border = (tx % 8 == 0) || (ty % 8 == 0);
                uint8_t *p = &checker[(ty * 16 + tx) * 3];
                if (cell) { p[0] = 20; p[1] = 60; p[2] = 90; }
                else      { p[0] = 70; p[1] = 215; p[2] = 255; }
                if (border) { p[0] = 10; p[1] = 25; p[2] = 45; }
            }
        checker_id = ngl_texture(16, 16, checker);
    }
    ngl_bind_texture(checker_id);

    static const float quad_uv[4][2] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};

    /* Непрозрачный куб: туман слегка красит дальние грани. */
    ngl_enable(NGL_FOG);
    ngl_fog_range(3.0f, 8.0f);
    ngl_fog_color(0.03f, 0.05f, 0.09f);

    for (int f = 0; f < 6; ++f) {
        vec3 world[4];
        for (int i = 0; i < 4; ++i)
            world[i] = mat4_transform(ngl.modelview, (vec3){
                cube_v[cube_f[f][i]][0], cube_v[cube_f[f][i]][1], cube_v[cube_f[f][i]][2]}, NULL);
        vec3 n = v3_norm(v3_cross(v3_sub(world[1], world[0]), v3_sub(world[2], world[0])));
        if (v3_dot(n, world[0]) >= 0) continue; /* задняя грань */

        float lam = v3_dot(n, light);
        if (lam < 0) lam = 0;
        float intensity = 0.40f + 0.60f * lam;

        ngl_begin(NGL_QUADS);
        for (int i = 0; i < 4; ++i) {
            float s = intensity * shade[i];
            ngl_color4f(s, s, s, 1.0f);
            ngl_tex_coord2f(quad_uv[i][0], quad_uv[i][1]);
            ngl_vertex3f(cube_v[cube_f[f][i]][0], cube_v[cube_f[f][i]][1], cube_v[cube_f[f][i]][2]);
        }
        ngl_end();
    }

    /* Полупрозрачная оболочка: больше куба, своя скорость вращения,
       рисуется после непрозрачной геометрии без записи в Z-буфер. */
    ngl_enable(NGL_BLEND);
    ngl_depth_mask(0);
    ngl_rotatef(-time * 45.0f, 0.3f, 0.9f, 0.2f);
    for (int f = 0; f < 6; ++f) {
        vec3 world[4];
        for (int i = 0; i < 4; ++i)
            world[i] = mat4_transform(ngl.modelview, (vec3){
                cube_v[cube_f[f][i]][0], cube_v[cube_f[f][i]][1], cube_v[cube_f[f][i]][2]}, NULL);
        vec3 n = v3_norm(v3_cross(v3_sub(world[1], world[0]), v3_sub(world[2], world[0])));
        if (v3_dot(n, world[0]) >= 0) continue;

        ngl_begin(NGL_QUADS);
        for (int i = 0; i < 4; ++i) {
            ngl_color4f(0.25f, 0.85f, 1.00f, 0.25f);
            ngl_vertex3f(cube_v[cube_f[f][i]][0] * 1.7f,
                         cube_v[cube_f[f][i]][1] * 1.7f,
                         cube_v[cube_f[f][i]][2] * 1.7f);
        }
        ngl_end();
    }
    ngl_depth_mask(1);
    ngl_disable(NGL_BLEND);
    ngl_disable(NGL_FOG);
    ngl_bind_texture(-1);
}

void gfx_init(size_t width, size_t height) {
    sse_init();
    ngl.tex = -1;
    ngl.depth_write = 1;
    ngl.fog_start = 1.0f;
    ngl.fog_end = 100.0f;
    g_w = width;
    g_h = height;
    size_t pixels = width * height;
    uint64_t pages = (pixels * 4 + 4095) / 4096;
    pix_buf = (uint32_t *)pmm_alloc_contig(pages);
    z_buf = (float *)pmm_alloc_contig(pages);
    win_pix = (uint32_t *)pmm_alloc_contig((WIN_CUBE_W * WIN_CUBE_H * 4 + 4095) / 4096);
    win_z = (float *)pmm_alloc_contig((WIN_CUBE_W * WIN_CUBE_H * 4 + 4095) / 4096);
}

int gfx_ready(void) {
    return pix_buf && z_buf && g_w && g_h;
}

/* Блит прямоугольника цели в кадровый буфер. */
static void blit_to_fb(struct limine_framebuffer *fb, int x, int y,
                       const uint32_t *src, int w, int h) {
    for (int yy = 0; yy < h; ++yy) {
        int sy = y + yy;
        if (sy < 0 || sy >= (int)fb->height) continue;
        const uint32_t *srow = src + (size_t)yy * (size_t)w;
        uint32_t *dst = (uint32_t *)((uint8_t *)fb->address + (size_t)sy * fb->pitch);
        for (int xx = 0; xx < w; ++xx) {
            int sx = x + xx;
            if (sx < 0 || sx >= (int)fb->width) continue;
            dst[sx] = srow[xx];
        }
    }
}

int gfx_render_frame(struct limine_framebuffer *fb, uint32_t time_ticks) {
    if (!gfx_ready() || !fb || !fb->address) return 0;
    ngl_bind_target(pix_buf, z_buf, (int)g_w, (int)g_h);
    ngl_viewport(0, 0, (int)g_w, (int)g_h);
    scene_cube(time_ticks);
    blit_to_fb(fb, 0, 0, pix_buf, (int)g_w, (int)g_h);
    return 1;
}

int gfx_render_cube_fb(struct limine_framebuffer *fb, int x, int y, uint32_t time_ticks) {
    if (!win_pix || !win_z || !fb || !fb->address) return 0;
    ngl_bind_target(win_pix, win_z, WIN_CUBE_W, WIN_CUBE_H);
    ngl_viewport(0, 0, WIN_CUBE_W, WIN_CUBE_H);
    scene_cube(time_ticks);
    blit_to_fb(fb, x, y, win_pix, WIN_CUBE_W, WIN_CUBE_H);
    return 1;
}

void gfx_blit_texture(struct limine_framebuffer *fb, int id, int x, int y, int w, int h) {
    if (id < 0 || id >= NGL_MAX_TEX || !ngl_tex_pool[id].used) return;
    if (!fb || !fb->address || w <= 0 || h <= 0) return;
    const struct ngl_texture *t = &ngl_tex_pool[id];
    for (int row = 0; row < h; ++row) {
        int sy = y + row;
        if (sy < 0 || sy >= (int)fb->height) continue;
        float v = ((float)row + 0.5f) / (float)h;
        uint32_t *dst = (uint32_t *)((uint8_t *)fb->address + (size_t)sy * fb->pitch);
        for (int col = 0; col < w; ++col) {
            int sx = x + col;
            if (sx < 0 || sx >= (int)fb->width) continue;
            float u = ((float)col + 0.5f) / (float)w;
            float r, g, b;
            tex_sample(t, u, v, &r, &g, &b);
            dst[sx] = ((uint32_t)(r * 255.0f) << 16)
                    | ((uint32_t)(g * 255.0f) << 8)
                    | (uint32_t)(b * 255.0f);
        }
    }
}

#else /* _MSC_VER: заглушки */

void gfx_init(size_t width, size_t height) { (void)width; (void)height; }
int gfx_ready(void) { return 0; }
int gfx_render_frame(struct limine_framebuffer *fb, uint32_t time_ticks) {
    (void)fb; (void)time_ticks;
    return 0;
}
int gfx_render_cube_fb(struct limine_framebuffer *fb, int x, int y, uint32_t time_ticks) {
    (void)fb; (void)x; (void)y; (void)time_ticks;
    return 0;
}
void ngl_bind_target(uint32_t *pix, float *zbuf, int w, int h) { (void)pix; (void)zbuf; (void)w; (void)h; }
void ngl_viewport(int x, int y, int w, int h) { (void)x; (void)y; (void)w; (void)h; }
void ngl_clear_color(float r, float g, float b) { (void)r; (void)g; (void)b; }
void ngl_clear(void) { }
void ngl_matrix_mode(int mode) { (void)mode; }
void ngl_load_identity(void) { }
void ngl_perspective(float a, float b, float c, float d) { (void)a; (void)b; (void)c; (void)d; }
void ngl_translatef(float x, float y, float z) { (void)x; (void)y; (void)z; }
void ngl_rotatef(float d, float x, float y, float z) { (void)d; (void)x; (void)y; (void)z; }
void ngl_color3f(float r, float g, float b) { (void)r; (void)g; (void)b; }
void ngl_begin(int mode) { (void)mode; }
void ngl_vertex3f(float x, float y, float z) { (void)x; (void)y; (void)z; }
void ngl_end(void) { }
int ngl_texture(int w, int h, const uint8_t *rgb) { (void)w; (void)h; (void)rgb; return -1; }
void ngl_bind_texture(int id) { (void)id; }
void ngl_tex_coord2f(float u, float v) { (void)u; (void)v; }
void ngl_enable(int cap) { (void)cap; }
void ngl_disable(int cap) { (void)cap; }
void ngl_color4f(float r, float g, float b, float a) { (void)r; (void)g; (void)b; (void)a; }
void ngl_depth_mask(int flag) { (void)flag; }
void ngl_fog_range(float start, float end) { (void)start; (void)end; }
void ngl_fog_color(float r, float g, float b) { (void)r; (void)g; (void)b; }
void gfx_blit_texture(struct limine_framebuffer *fb, int id, int x, int y, int w, int h) {
    (void)fb; (void)id; (void)x; (void)y; (void)w; (void)h;
}

#endif
