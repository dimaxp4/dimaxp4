#include <fs.h>
#include <disk.h>

#define SECTOR_SIZE 512
#define ROOT_ENTRIES 512
#define FAT_COUNT 2
#define FAT16_EOC 0xffff
#define ATTR_LONG_NAME 0x0f
#define ATTR_DIRECTORY 0x10

static struct fs_file files[FS_MAX_FILES];
static uint8_t sector[SECTOR_SIZE];
static uint16_t bytes_per_sector, sectors_per_cluster, reserved_sectors, sectors_per_fat, root_sectors;
static uint32_t fat_start, root_start, data_start;
static uint32_t disk_total_sectors = 0;
static int disk_ready;

static uint16_t u16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t u32(const uint8_t *p) { return (uint32_t)u16(p) | ((uint32_t)u16(p + 2) << 16); }
static void put16(uint8_t *p, uint16_t v) { p[0] = (uint8_t)v; p[1] = (uint8_t)(v >> 8); }
static void put32(uint8_t *p, uint32_t v) { put16(p, (uint16_t)v); put16(p + 2, (uint16_t)(v >> 16)); }
static size_t name_len(const char *s) { size_t n = 0; while (s && s[n] && n < FS_NAME_MAX - 1) ++n; return n; }
static int same(const char *a, const char *b) { size_t i = 0; if (!a || !b) return 0; while (i < FS_NAME_MAX && a[i] && b[i]) { if (a[i] != b[i]) return 0; ++i; } return i < FS_NAME_MAX && a[i] == b[i]; }
static int find(const char *name) { for (size_t i = 0; i < FS_MAX_FILES; ++i) if (files[i].used && same(files[i].name, name)) return (int)i; return -1; }

static void disk_name(char out[FS_NAME_MAX], const uint8_t *entry) {
    size_t n = 0;
    for (size_t i = 0; i < 8 && entry[i] != ' '; ++i) out[n++] = (char)entry[i];
    if (entry[8] != ' ') { out[n++] = '.'; for (size_t i = 8; i < 11 && entry[i] != ' '; ++i) out[n++] = (char)entry[i]; }
    out[n] = 0;
}

static void disk_name83(uint8_t out[11], const char *name) {
    for (size_t i = 0; i < 11; ++i) out[i] = ' ';
    size_t i = 0, p = 0;
    while (name[i] && name[i] != '.' && p < 8) { out[p++] = name[i++]; }
    if (name[i] == '.') { ++i; p = 8; while (name[i] && p < 11) out[p++] = name[i++]; }
}

static uint32_t cluster_sector(uint16_t cluster) { return data_start + ((uint32_t)cluster - 2) * sectors_per_cluster; }

static uint32_t cluster_limit(void) {
    return (uint32_t)sectors_per_fat * SECTOR_SIZE / 2;
}

static int valid_cluster(uint16_t cluster) {
    return cluster >= 2 && (uint32_t)cluster < cluster_limit();
}

static int fat_value(uint16_t cluster, uint16_t *value) {
    if (!value || !valid_cluster(cluster)) return -1;
    uint32_t lba = fat_start + ((uint32_t)cluster * 2) / SECTOR_SIZE;
    if (disk_read(lba, sector) < 0) return -1;
    *value = u16(sector + ((cluster * 2) % SECTOR_SIZE));
    return 0;
}

static int set_fat(uint16_t cluster, uint16_t value) {
    if (!valid_cluster(cluster)) return -1;
    for (uint16_t copy = 0; copy < FAT_COUNT; ++copy) {
        uint32_t lba = fat_start + copy * sectors_per_fat + ((uint32_t)cluster * 2) / SECTOR_SIZE;
        if (disk_read(lba, sector) < 0) return -1;
        put16(sector + ((cluster * 2) % SECTOR_SIZE), value);
        if (disk_write(lba, sector) < 0) return -1;
    }
    return 0;
}

static int allocate_cluster(uint16_t *result) {
    uint32_t max = (uint32_t)sectors_per_fat * SECTOR_SIZE / 2;
    for (uint16_t c = 2; c < max; ++c) {
        uint16_t value;
        if (fat_value(c, &value) < 0) return -1;
        if (value == 0) {
            if (set_fat(c, FAT16_EOC) < 0) return -1;
            *result = c;
            return 0;
        }
    }
    return -1;
}

static int free_chain(uint16_t start) {
    uint16_t cluster = start;
    uint32_t steps = 0;
    while (cluster != FAT16_EOC && cluster != 0) {
        if (!valid_cluster(cluster) || ++steps > cluster_limit()) return -1;
        uint16_t next;
        if (fat_value(cluster, &next) < 0) return -1;
        if (set_fat(cluster, 0) < 0) return -1;
        cluster = next;
    }
    return 0;
}

static int load_disk(void) {
    if (disk_read(0, sector) < 0 || u16(sector + 510) != 0xaa55) return -1;
    /* Диск с MBR: LBA0 — не BPB (в байтах 11-12 нули, но 0xaa55 на месте,
       что даёт деление на ноль ниже). Ищем FAT-раздел и перечитываем его
       загрузочный сектор; все старты дальше считаем от начала раздела. */
    uint32_t volume = 0;
    if (u16(sector + 11) != SECTOR_SIZE) {
        int part = -1;
        for (int i = 0; i < 4; ++i) {
            uint8_t type = sector[446 + i * 16 + 4];
            if (type == 0x01 || type == 0x04 || type == 0x06 ||
                type == 0x0b || type == 0x0c || type == 0x0e ||
                type == 0x1b || type == 0x1c) { part = i; break; }
        }
        if (part < 0) return -1;
        volume = u32(sector + 446 + part * 16 + 8);
        if (disk_read(volume, sector) < 0 || u16(sector + 510) != 0xaa55) return -1;
    }
    bytes_per_sector = u16(sector + 11);
    sectors_per_cluster = sector[13];
    reserved_sectors = u16(sector + 14);
    sectors_per_fat = u16(sector + 22);
    uint16_t root_entries = u16(sector + 17);
    root_sectors = (uint16_t)(((uint32_t)root_entries * 32 + bytes_per_sector - 1) / bytes_per_sector);
    if (bytes_per_sector != SECTOR_SIZE || sectors_per_cluster != 1 || !sectors_per_fat || root_entries != ROOT_ENTRIES) return -1;
    disk_total_sectors = u16(sector + 19);
    if (!disk_total_sectors) disk_total_sectors = u32(sector + 32);
    fat_start = volume + reserved_sectors;
    root_start = fat_start + FAT_COUNT * sectors_per_fat;
    data_start = root_start + root_sectors;
    return 0;
}

static void read_lfn_chars(uint8_t *entry, char *buf, size_t *len) {
    size_t pos = *len;
    int16_t w;
    for (int off = 1; off < 11; off += 2) {
        w = (int16_t)(entry[off] | ((uint16_t)entry[off + 1] << 8));
        if (w == 0) { *len = pos; return; }
        if (w == (int16_t)0xffff) continue;
        if (pos < FS_NAME_MAX - 1) buf[pos++] = (char)w;
    }
    for (int off = 14; off < 26; off += 2) {
        w = (int16_t)(entry[off] | ((uint16_t)entry[off + 1] << 8));
        if (w == 0) { *len = pos; return; }
        if (w == (int16_t)0xffff) continue;
        if (pos < FS_NAME_MAX - 1) buf[pos++] = (char)w;
    }
    for (int off = 28; off < 32; off += 2) {
        w = (int16_t)(entry[off] | ((uint16_t)entry[off + 1] << 8));
        if (w == 0) { *len = pos; return; }
        if (w == (int16_t)0xffff) continue;
        if (pos < FS_NAME_MAX - 1) buf[pos++] = (char)w;
    }
    *len = pos;
}

static void read_lfn_entry(uint8_t *entry, char *out, size_t *out_len) {
    // Cheap multi-entry LFN: FAT LFN entries are stored last-to-first (the entry
    // nearest the 8.3 slot is the first chunk of the name). Inserting each chunk
    // at 0 reconstructs the name in the right order for names > 13 chars while
    // remaining correct for single-entry names.
    char chunk[13];
    size_t chunk_len = 0;
    read_lfn_chars(entry, chunk, &chunk_len);
    if (!chunk_len) return;
    if (*out_len + chunk_len >= FS_NAME_MAX) chunk_len = FS_NAME_MAX - 1 - *out_len;
    for (size_t i = *out_len; i > 0; --i) out[i + chunk_len - 1] = out[i - 1];
    for (size_t i = 0; i < chunk_len; ++i) out[i] = chunk[i];
    *out_len += chunk_len;
}

static uint8_t lfn_checksum(const uint8_t short_name[11]);

void fs_init(void) {
    for (size_t i = 0; i < FS_MAX_FILES; ++i) { files[i].used = 0; files[i].size = 0; }
    disk_ready = load_disk() == 0;
    if (!disk_ready) {
        fs_create("README.TXT");
        const uint8_t msg[] = "NYKLIMA OS RAM FILESYSTEM\n";
        fs_write("README.TXT", msg, sizeof(msg) - 1);
        return;
    }
    char lfn_buffer[FS_NAME_MAX];
    size_t lfn_len = 0;
    int lfn_active = 0;
    uint8_t lfn_sum = 0;
    for (uint16_t s = 0; s < root_sectors; ++s) {
        /* Локальный буфер: fat_value() при чтении цепочки кластеров пишет в
           общий sector, и сканирование каталога не должно его затирать. */
        uint8_t root_buf[SECTOR_SIZE];
        if (disk_read(root_start + s, root_buf) < 0) { disk_ready = 0; return; }
        for (uint16_t off = 0; off < SECTOR_SIZE; off += 32) {
            uint8_t *entry = root_buf + off;
            if (entry[0] == 0) return;
            if (entry[0] == 0xe5) { lfn_active = 0; lfn_len = 0; continue; }
            if (entry[11] == ATTR_LONG_NAME) {
                if (!lfn_active) { lfn_len = 0; lfn_active = 1; lfn_sum = entry[13]; }
                read_lfn_entry(entry, lfn_buffer, &lfn_len);
                continue;
            }
            if (entry[11] & ATTR_DIRECTORY) { lfn_active = 0; lfn_len = 0; continue; }
            /* Осиротевшая LFN-цепочка (checksum не сходится с коротким именем)
               чужая — её текст нельзя присваивать этому файлу. */
            int lfn_valid = lfn_active && lfn_len > 0 && lfn_sum == lfn_checksum(entry);
            size_t slot = 0;
            while (slot < FS_MAX_FILES && files[slot].used) ++slot;
            if (slot == FS_MAX_FILES) continue;
            if (lfn_valid) {
                for (size_t j = 0; j < lfn_len && j < FS_NAME_MAX; ++j) files[slot].name[j] = lfn_buffer[j];
                files[slot].name[lfn_len < FS_NAME_MAX ? lfn_len : FS_NAME_MAX - 1] = 0;
            } else {
                disk_name(files[slot].name, entry);
            }
            files[slot].size = u32(entry + 28);
            files[slot].disk_size = u32(entry + 28);
            files[slot].first_cluster = u16(entry + 26);
            files[slot].dir_sector = root_start + s;
            files[slot].dir_offset = off;
            files[slot].used = 1;
            lfn_active = 0;
            lfn_len = 0;
            if (files[slot].size > FS_DATA_MAX) files[slot].size = FS_DATA_MAX;
            if (files[slot].first_cluster && files[slot].size) {
                size_t total_read = 0;
                uint16_t cluster = files[slot].first_cluster;
                uint32_t steps = 0;
                uint8_t tmp[SECTOR_SIZE];
                while (cluster != FAT16_EOC && cluster != 0 && total_read < FS_DATA_MAX) {
                    if (!valid_cluster(cluster) || ++steps > cluster_limit()) break;
                    uint32_t lba = cluster_sector(cluster);
                    size_t to_read = SECTOR_SIZE;
                    if (total_read + to_read > FS_DATA_MAX) to_read = FS_DATA_MAX - total_read;
                    if (disk_read(lba, tmp) < 0) break;
                    for (size_t j = 0; j < to_read; ++j) files[slot].data[total_read + j] = tmp[j];
                    total_read += to_read;
                    uint16_t next;
                    if (fat_value(cluster, &next) < 0) break;
                    cluster = next;
                }
            }
        }
    }
    fs_mark_dirty();
}

static int short_name_exists(const uint8_t short_name[11]) {
    for (uint16_t s = 0; s < root_sectors; ++s) {
        if (disk_read(root_start + s, sector) < 0) return -1;
        for (uint16_t off = 0; off < SECTOR_SIZE; off += 32) {
            if (sector[off] == 0) return 0;
            if (sector[off] == 0xe5) continue;
            int match = 1;
            for (int j = 0; j < 11; ++j) if (sector[off + j] != short_name[j]) { match = 0; break; }
            if (match) return 1;
        }
    }
    return 0;
}

static int generate_unique_short_name(uint8_t out[11], const char *name) {
    uint8_t base[11];
    disk_name83(base, name);
    for (int suffix = 1; suffix <= 999999; ++suffix) {
        for (int j = 0; j < 11; ++j) out[j] = base[j];
        if (suffix > 1) {
            char dec[7];
            int dec_len = 0, v = suffix;
            while (v > 0) { dec[dec_len++] = (char)('0' + (v % 10)); v /= 10; }
            for (int l = 0, r = dec_len - 1; l < r; ++l, --r) { char t = dec[l]; dec[l] = dec[r]; dec[r] = t; }
            int keep = 8 - (1 + dec_len);
            if (keep < 1) keep = 1;
            if (keep > 8) keep = 8;
            for (int j = 0; j < keep; ++j) out[j] = base[j];
            out[keep] = (uint8_t)'~';
            for (int j = 0; j < dec_len && keep + 1 + j < 8; ++j) out[keep + 1 + j] = (uint8_t)dec[j];
            for (int j = keep + 1 + dec_len; j < 8; ++j) out[j] = (uint8_t)' ';
        }
        int exists = short_name_exists(out);
        if (exists < 0) return -1;
        if (!exists) return 0;
    }
    return -1;
}

static uint8_t lfn_checksum(const uint8_t short_name[11]) {
    uint8_t sum = 0;
    for (size_t i = 0; i < 11; ++i)
        sum = (uint8_t)((((sum & 1) << 7) | (sum >> 1)) + short_name[i]);
    return sum;
}

static void write_lfn_entry(uint8_t *entry, const char *name, size_t start, size_t length,
                            uint8_t sequence, uint8_t checksum) {
    static const uint8_t offsets[] = {1, 3, 5, 7, 9, 14, 16, 18, 20, 22, 24, 28, 30};
    for (size_t i = 0; i < 32; ++i) entry[i] = 0xff;
    entry[0] = sequence;
    entry[11] = ATTR_LONG_NAME;
    entry[12] = 0;
    entry[13] = checksum;
    entry[26] = 0;
    entry[27] = 0;
    for (size_t i = 0; i < 13; ++i) {
        size_t pos = start + i;
        uint16_t value = 0xffff;
        if (pos < length) value = (uint8_t)name[pos];
        else if (pos == length) value = 0;
        put16(entry + offsets[i], value);
    }
}

static void write_dir_entries(uint8_t *buf, size_t off, const char *name, size_t length, const uint8_t short_name[11]) {
    size_t lfn_count = (length + 12) / 13;
    uint8_t checksum = lfn_checksum(short_name);
    for (size_t n = 0; n < lfn_count; ++n) {
        size_t chunk = lfn_count - 1 - n;
        uint8_t sequence = (uint8_t)(chunk + 1);
        if (chunk == lfn_count - 1) sequence |= 0x40;
        write_lfn_entry(buf + off + n * 32, name, chunk * 13, length, sequence, checksum);
    }
    uint16_t short_offset = (uint16_t)(off + lfn_count * 32);
    for (size_t j = 0; j < 11; ++j) buf[short_offset + j] = short_name[j];
    buf[short_offset + 11] = 0x20;
    put16(buf + short_offset + 26, 0);
    put32(buf + short_offset + 28, 0);
}

int fs_create(const char *name) {
    if (!name || !name[0] || name_len(name) >= FS_NAME_MAX || find(name) >= 0) return -1;
    size_t slot = 0;
    while (slot < FS_MAX_FILES && files[slot].used) ++slot;
    if (slot == FS_MAX_FILES) return -1;
    files[slot].used = 1;
    files[slot].size = 0;
    files[slot].disk_size = 0;
    files[slot].first_cluster = 0;
    files[slot].dir_sector = 0;
    for (size_t j = 0; j < FS_NAME_MAX; ++j) files[slot].name[j] = 0;
    for (size_t j = 0; j < name_len(name); ++j) files[slot].name[j] = name[j];
    fs_mark_dirty();
    if (!disk_ready) return 0;
    uint8_t short_name[11];
    if (generate_unique_short_name(short_name, name) < 0) { files[slot].used = 0; return -1; }
    size_t length = name_len(name);
    size_t lfn_count = (length + 12) / 13;
    size_t needed = lfn_count + 1;
    for (uint16_t s = 0; s < root_sectors; ++s) {
        if (disk_read(root_start + s, sector) < 0) { files[slot].used = 0; return -1; }
        for (uint16_t off = 0; off < SECTOR_SIZE; off += 32) {
            if (sector[off] != 0 && sector[off] != 0xe5) continue;
            size_t available = 0;
            while (off + (available + 1) * 32 <= SECTOR_SIZE &&
                   off + available * 32 < SECTOR_SIZE &&
                   (sector[off + available * 32] == 0 || sector[off + available * 32] == 0xe5))
                ++available;
            if (available >= needed) {
                write_dir_entries(sector, off, name, length, short_name);
                if (disk_write(root_start + s, sector) < 0) { files[slot].used = 0; return -1; }
                files[slot].dir_sector = root_start + s;
                files[slot].dir_offset = (uint16_t)(off + lfn_count * 32);
                return 0;
            }
            if (s + 1 >= root_sectors) continue;
            size_t need_here = (SECTOR_SIZE - off) / 32;
            if (need_here >= needed) continue;
            size_t need_next = needed - need_here;
            size_t avail_here = 0;
            while (off + avail_here * 32 < SECTOR_SIZE &&
                   (sector[off + avail_here * 32] == 0 || sector[off + avail_here * 32] == 0xe5))
                ++avail_here;
            if (avail_here < need_here) continue;
            uint8_t sector2[SECTOR_SIZE];
            if (disk_read(root_start + s + 1, sector2) < 0) continue;
            size_t avail_next = 0;
            while (avail_next < need_next &&
                   (sector2[avail_next * 32] == 0 || sector2[avail_next * 32] == 0xe5))
                ++avail_next;
            if (avail_next < need_next) continue;
            uint8_t combined[SECTOR_SIZE * 2];
            for (size_t i = 0; i < SECTOR_SIZE; ++i) combined[i] = sector[i];
            for (size_t i = 0; i < SECTOR_SIZE; ++i) combined[SECTOR_SIZE + i] = sector2[i];
            write_dir_entries(combined, off, name, length, short_name);
            for (size_t i = 0; i < SECTOR_SIZE; ++i) sector[i] = combined[i];
            for (size_t i = 0; i < SECTOR_SIZE; ++i) sector2[i] = combined[SECTOR_SIZE + i];
            if (disk_write(root_start + s, sector) < 0) { files[slot].used = 0; return -1; }
            if (disk_write(root_start + s + 1, sector2) < 0) { files[slot].used = 0; return -1; }
            uint16_t short_offset = (uint16_t)(off + lfn_count * 32);
            files[slot].dir_sector = root_start + s + (short_offset >= SECTOR_SIZE ? 1 : 0);
            files[slot].dir_offset = short_offset % SECTOR_SIZE;
            return 0;
        }
    }
    files[slot].used = 0;
    return -1;
}

int fs_write(const char *name, const uint8_t *data, size_t size) {
    int i = find(name);
    if (i < 0 || !data || size > FS_DATA_MAX) return -1;
    for (size_t j = 0; j < size; ++j) files[i].data[j] = data[j];
    files[i].size = size;
    files[i].disk_size = (uint32_t)size;
    fs_mark_dirty();
    if (!disk_ready) return 0;
    if (files[i].first_cluster) {
        if (free_chain(files[i].first_cluster) < 0) return -1;
        files[i].first_cluster = 0;
    }
    size_t remaining = size;
    uint16_t prev_cluster = 0;
    uint16_t first_cluster = 0;
    size_t offset = 0;
    while (remaining > 0) {
        uint16_t cluster;
        if (allocate_cluster(&cluster) < 0) {
            if (first_cluster) free_chain(first_cluster);
            return -1;
        }
        if (!first_cluster) first_cluster = cluster;
        if (prev_cluster) {
            if (set_fat(prev_cluster, cluster) < 0) {
                free_chain(first_cluster);
                return -1;
            }
        }
        size_t to_write = remaining > SECTOR_SIZE ? SECTOR_SIZE : remaining;
        uint8_t block[SECTOR_SIZE];
        for (size_t j = 0; j < SECTOR_SIZE; ++j) block[j] = 0;
        for (size_t j = 0; j < to_write; ++j) block[j] = data[offset + j];
        if (disk_write(cluster_sector(cluster), block) < 0) {
            free_chain(first_cluster);
            return -1;
        }
        remaining -= to_write;
        offset += to_write;
        prev_cluster = cluster;
    }
    if (prev_cluster) {
        if (set_fat(prev_cluster, FAT16_EOC) < 0) {
            free_chain(first_cluster);
            return -1;
        }
    }
    files[i].first_cluster = first_cluster;
    if (disk_read(files[i].dir_sector, sector) < 0) {
        free_chain(first_cluster);
        files[i].first_cluster = 0;
        return -1;
    }
    put16(sector + files[i].dir_offset + 26, files[i].first_cluster);
    put32(sector + files[i].dir_offset + 28, (uint32_t)size);
    if (disk_write(files[i].dir_sector, sector) < 0) {
        free_chain(first_cluster);
        files[i].first_cluster = 0;
        return -1;
    }
    return 0;
}

int fs_read(const char *name, uint8_t *out, size_t cap, size_t *written) {
    int i = find(name);
    if (written) *written = 0;
    if (i < 0 || !out || cap < files[i].size) return -1;
    if (!disk_ready || !files[i].first_cluster) {
        for (size_t j = 0; j < files[i].size; ++j) out[j] = files[i].data[j];
        if (written) *written = files[i].size;
        return 0;
    }
    size_t total_read = 0;
    uint16_t cluster = files[i].first_cluster;
    uint8_t tmp[SECTOR_SIZE];
    uint32_t steps = 0;
    while (cluster != FAT16_EOC && cluster != 0 && total_read < files[i].size) {
        if (!valid_cluster(cluster) || ++steps > cluster_limit()) return -1;
        uint32_t lba = cluster_sector(cluster);
        size_t to_read = SECTOR_SIZE;
        if (total_read + to_read > files[i].size) to_read = files[i].size - total_read;
        if (disk_read(lba, tmp) < 0) return -1;
        for (size_t j = 0; j < to_read; ++j) out[total_read + j] = tmp[j];
        total_read += to_read;
        uint16_t next;
        if (fat_value(cluster, &next) < 0) return -1;
        cluster = next;
    }
    if (written) *written = total_read;
    return 0;
}

/* Отсортированный кэш имён: пересобирается только после изменения FS
   (счётчик поколений), поэтому повторные вызовы почти бесплатны. */
static char list_cache[FS_MAX_FILES][FS_NAME_MAX];
static size_t list_cache_count = 0;
/* Начинается с 1: cached_generation в fs_list стартует с 0, поэтому первый
   fs_list всегда строит кэш, даже если fs_init вышел по раннему return. */
static uint32_t fs_generation = 1;

void fs_mark_dirty(void) {
    ++fs_generation;
}

static void cache_rebuild(void) {
    size_t count = 0;
    for (size_t i = 0; i < FS_MAX_FILES; ++i) {
        if (!files[i].used) continue;
        for (size_t j = 0; j < FS_NAME_MAX; ++j) list_cache[count][j] = files[i].name[j];
        list_cache[count][FS_NAME_MAX - 1] = 0;
        ++count;
    }
    /* Сортировка вставками по имени — массив до 32 элементов, O(n^2) здесь быстрее O(n log n). */
    for (size_t i = 1; i < count; ++i) {
        char key[FS_NAME_MAX];
        for (size_t j = 0; j < FS_NAME_MAX; ++j) key[j] = list_cache[i][j];
        size_t j = i;
        while (j > 0) {
            int cmp = 0;
            for (size_t k = 0; k < FS_NAME_MAX; ++k) {
                char a = list_cache[j - 1][k], b = key[k];
                if (a != b) { cmp = (unsigned char)a < (unsigned char)b ? -1 : 1; break; }
                if (!a) break;
            }
            if (cmp <= 0) break;
            for (size_t k = 0; k < FS_NAME_MAX; ++k) list_cache[j][k] = list_cache[j - 1][k];
            --j;
        }
        for (size_t k = 0; k < FS_NAME_MAX; ++k) list_cache[j][k] = key[k];
    }
    list_cache_count = count;
}

size_t fs_list(char names[][FS_NAME_MAX], size_t cap) {
    static uint32_t cached_generation = 0;
    if (cached_generation != fs_generation) {
        cache_rebuild();
        cached_generation = fs_generation;
    }
    if (names) {
        size_t n = list_cache_count < cap ? list_cache_count : cap;
        for (size_t i = 0; i < n; ++i)
            for (size_t j = 0; j < FS_NAME_MAX; ++j) names[i][j] = list_cache[i][j];
    }
    return list_cache_count;
}

int fs_is_ram(void) {
    return !disk_ready;
}

int fs_delete(const char *name) {
    int i = find(name);
    if (i < 0) return -1;
    if (!disk_ready) {
        files[i].used = 0;
        return 0;
    }
    if (files[i].first_cluster) {
        if (free_chain(files[i].first_cluster) < 0) return -1;
    }
    size_t name_len_value = name_len(files[i].name);
    size_t lfn_count = (name_len_value + 12) / 13;
    int32_t first_offset = (int32_t)files[i].dir_offset - (int32_t)(lfn_count * 32);
    uint32_t start_sector = files[i].dir_sector;
    while (first_offset < 0 && start_sector > root_start) {
        first_offset += SECTOR_SIZE;
        start_sector -= 1;
    }
    if (first_offset < 0) first_offset = 0;
    if (start_sector < root_start) start_sector = root_start;
    uint8_t buf[SECTOR_SIZE];
    int32_t off = first_offset;
    uint32_t cur = start_sector;
    while (cur <= files[i].dir_sector && cur >= root_start && cur < root_start + root_sectors) {
        if (disk_read(cur, buf) < 0) return -1;
        while (off >= 0 && off < SECTOR_SIZE && (cur < files[i].dir_sector || off <= (int32_t)files[i].dir_offset)) {
            uint8_t attr = buf[off + 11];
            if (attr == ATTR_LONG_NAME || off == (int32_t)files[i].dir_offset) {
                buf[off] = 0xe5;
            }
            off += 32;
        }
        if (disk_write(cur, buf) < 0) return -1;
        if (cur == files[i].dir_sector) break;
        cur += 1;
        off = 0;
    }
    files[i].used = 0;
    fs_mark_dirty();
    return 0;
}

uint32_t fs_disk_kb(void) {
    if (!disk_ready || !disk_total_sectors) return 0;
    return disk_total_sectors * SECTOR_SIZE / 1024;
}

uint32_t fs_disk_size(const char *name) {
    int i = find(name);
    if (i < 0) return 0;
    return files[i].disk_size;
}

int fs_read_direct(const char *name, uint8_t *out, uint32_t cap, uint32_t *written) {
    int i = find(name);
    if (written) *written = 0;
    if (i < 0 || !out || !cap) return -1;
    if (!disk_ready || !files[i].first_cluster) return -1;
    uint32_t want = files[i].disk_size;
    if (want > cap) want = cap;
    if (!want) return -1;
    size_t total = 0;
    uint16_t cluster = files[i].first_cluster;
    uint32_t steps = 0;
    uint8_t tmp[SECTOR_SIZE];
    while (total < want) {
        if (!valid_cluster(cluster) || ++steps > cluster_limit()) return -1;
        /* Длина последовательного пробега цепочки — чтобы читать
           мульти-секторными командами, а не по одному сектору. */
        uint16_t run = 1, c = cluster, next = 0;
        for (;;) {
            if (fat_value(c, &next) < 0) return -1;
            if (next != (uint16_t)(c + 1) || next == FAT16_EOC || next == 0) break;
            c = next;
            ++run;
            if (run >= 256) break;
        }
        uint32_t remain = want - (uint32_t)total;
        uint32_t want_sectors = (remain + SECTOR_SIZE - 1) / SECTOR_SIZE;
        uint32_t chunk = run < want_sectors ? run : want_sectors;
        if (chunk > 256) chunk = 256;
        uint32_t full = remain / SECTOR_SIZE;
        if (full > chunk) full = chunk;
        if (full > 0) {
            /* Полные секторы — мульти-чтением прямо в буфер назначения. */
            if (disk_read_multi(cluster_sector(cluster), out + total, (uint16_t)full) < 0) return -1;
            total += full * SECTOR_SIZE;
            cluster = (full == run) ? next : (uint16_t)(cluster + full);
        } else {
            /* Хвост размером меньше сектора. */
            if (disk_read(cluster_sector(cluster), tmp) < 0) return -1;
            uint32_t part = remain;
            if (part > SECTOR_SIZE) part = SECTOR_SIZE;
            for (uint32_t j = 0; j < part; ++j) out[total + j] = tmp[j];
            total += part;
            cluster = next;
        }
    }
    if (written) *written = (uint32_t)total;
    return 0;
}
