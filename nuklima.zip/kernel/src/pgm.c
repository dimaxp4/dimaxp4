/* Загрузчик пользовательских программ: ELF64 (PIE) из FAT16.
   Копирует PT_LOAD-сегменты в непрерывный блок, применяет
   R_X86_64_RELATIVE релокации и вызывает точку входа с API-структурой.
   Программы работают в кольце 0 без изоляции — это осознанный упрощённый
   первый шаг к многозадачности. */

#include <stdint.h>
#include <stddef.h>
#include <fs.h>
#include <mem.h>
#include <pgm.h>

#define PT_LOAD 1
#define PT_DYNAMIC 2
#define DT_NULL 0
#define DT_RELA 7
#define DT_RELASZ 8
#define R_X86_64_RELATIVE 8

static uint16_t elf_u16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t elf_u32(const uint8_t *p) { return (uint32_t)elf_u16(p) | ((uint32_t)elf_u16(p + 2) << 16); }
static uint64_t elf_u64(const uint8_t *p) {
    return (uint64_t)elf_u32(p) | ((uint64_t)elf_u32(p + 4) << 32);
}

int pgm_run(const char *name, struct pgm_api *api) {
    uint32_t size = fs_disk_size(name);
    if (size < 64 || size > 4u * 1024 * 1024) return -1;
    /* Файл читается во временный буфер: образ программы может занимать
       больше файла (bss в последнем сегменте PIE lld лежит на vaddr выше
       файлового содержимого), размер аллокации считается по p_vaddr+p_memsz. */
    uint64_t file_pages = (size + 4095) / 4096;
    uint8_t *file = (uint8_t *)pmm_alloc_contig(file_pages);
    if (!file) return -2;
    uint32_t got = 0;
    if (fs_read_direct(name, file, size, &got) < 0 || got != size) {
        pmm_free_contig(file, file_pages);
        return -3;
    }

    /* ELF64 little-endian? */
    if (file[0] != 0x7f || file[1] != 'E' || file[2] != 'L' || file[3] != 'F') {
        pmm_free_contig(file, file_pages);
        return -4;
    }
    if (file[4] != 2 || file[5] != 1) {
        pmm_free_contig(file, file_pages);
        return -4;
    }
    uint16_t e_type = elf_u16(file + 16);
    uint16_t e_machine = elf_u16(file + 18);
    if (e_machine != 0x3e) {
        pmm_free_contig(file, file_pages);
        return -4;
    } /* x86-64 */
    if (e_type != 2 && e_type != 3) {
        pmm_free_contig(file, file_pages);
        return -4;
    }
    uint64_t e_entry = elf_u64(file + 24);
    uint64_t e_phoff = elf_u64(file + 32);
    uint16_t e_phentsize = elf_u16(file + 54);
    uint16_t e_phnum = elf_u16(file + 56);
    if (e_phnum > 32 || e_phentsize < 56 || e_phoff > size ||
        (uint64_t)e_phnum * e_phentsize > size - e_phoff) {
        pmm_free_contig(file, file_pages);
        return -4;
    }

    /* Первый проход: размер образа по сегментам (все границы — от файла). */
    uint64_t image_end = 0;
    for (int i = 0; i < e_phnum; ++i) {
        const uint8_t *ph = file + e_phoff + (uint32_t)i * e_phentsize;
        uint32_t p_type = elf_u32(ph + 0);
        uint64_t p_offset = elf_u64(ph + 8);
        uint64_t p_vaddr = elf_u64(ph + 16);
        uint64_t p_filesz = elf_u64(ph + 32);
        uint64_t p_memsz = elf_u64(ph + 40);
        if (p_type != PT_LOAD || !p_memsz) continue;
        if (p_offset > size || p_filesz > size - p_offset || p_filesz > p_memsz) {
            pmm_free_contig(file, file_pages);
            return -4;
        }
        uint64_t end = p_vaddr + p_memsz;
        if (end > image_end) image_end = end;
    }
    if (!image_end || image_end > 8u * 1024 * 1024) {
        pmm_free_contig(file, file_pages);
        return -4;
    }
    uint64_t image_pages = (image_end + 4095) / 4096;
    uint8_t *base = (uint8_t *)pmm_alloc_contig(image_pages);
    if (!base) {
        pmm_free_contig(file, file_pages);
        return -2;
    }
    uint64_t alloc_bytes = image_pages * 4096;

    /* Второй проход: копирование сегментов (границы — от образа). */
    for (int i = 0; i < e_phnum; ++i) {
        const uint8_t *ph = file + e_phoff + (uint32_t)i * e_phentsize;
        uint32_t p_type = elf_u32(ph + 0);
        uint64_t p_offset = elf_u64(ph + 8);
        uint64_t p_vaddr = elf_u64(ph + 16);
        uint64_t p_filesz = elf_u64(ph + 32);
        uint64_t p_memsz = elf_u64(ph + 40);
        if (p_type != PT_LOAD || !p_memsz) continue;
        if (p_vaddr > alloc_bytes || p_memsz > alloc_bytes - p_vaddr) {
            goto bad;
        }
        for (uint64_t j = 0; j < p_filesz; ++j) base[p_vaddr + j] = file[p_offset + j];
        for (uint64_t j = p_filesz; j < p_memsz; ++j) base[p_vaddr + j] = 0;
    }

    {
        uint64_t reladdr = 0, relsz = 0;
        int has_dyn = 0;
        for (int i = 0; i < e_phnum; ++i) {
            const uint8_t *ph = file + e_phoff + (uint32_t)i * e_phentsize;
            uint32_t p_type = elf_u32(ph + 0);
            uint64_t p_offset = elf_u64(ph + 8);
            uint64_t p_vaddr = elf_u64(ph + 16);
            uint64_t p_filesz = elf_u64(ph + 32);
            if (p_type != PT_DYNAMIC) continue;
            if (p_offset > size || p_filesz > size - p_offset ||
                p_vaddr > alloc_bytes || p_filesz > alloc_bytes - p_vaddr) {
                goto bad;
            }
            has_dyn = 1;
            for (uint64_t off = 0; off + 16 <= p_filesz; off += 16) {
                int64_t tag = (int64_t)elf_u64(base + p_vaddr + off);
                uint64_t val = elf_u64(base + p_vaddr + off + 8);
                if (tag == DT_NULL) break;
                if (tag == DT_RELA) reladdr = val;
                else if (tag == DT_RELASZ) relsz = val;
            }
        }

        if (has_dyn && reladdr && relsz) {
            /* Таблица релокаций и каждая цель — внутри образа. */
            if (reladdr > alloc_bytes || relsz > alloc_bytes - reladdr) goto bad;
            for (uint64_t off = 0; off + 24 <= relsz; off += 24) {
                const uint8_t *r = base + reladdr + off;
                uint64_t r_offset = elf_u64(r);
                uint64_t info = elf_u64(r + 8);
                int64_t addend = (int64_t)elf_u64(r + 16);
                if ((info & 0xffffffffu) == R_X86_64_RELATIVE) {
                    if (r_offset > alloc_bytes || 8 > alloc_bytes - r_offset) goto bad;
                    *(uint64_t *)(base + r_offset) = (uint64_t)base + (uint64_t)addend;
                }
            }
        }
    }

    if (e_entry >= alloc_bytes) goto bad;
    {
        void (*entry)(struct pgm_api *) = (void (*)(struct pgm_api *))(base + e_entry);
        entry(api);
    }
    pmm_free_contig(base, image_pages);
    pmm_free_contig(file, file_pages);
    return 0;

bad:
    pmm_free_contig(base, image_pages);
    pmm_free_contig(file, file_pages);
    return -4;
}