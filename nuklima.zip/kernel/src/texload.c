/* Мост хост→ОС: BMP-файлы, отрендеренные NYKLIMA G1 (в т.ч. на RTX 3050
   через CUDA), кладутся в FAT16-образ скриптом сборки и загружаются здесь
   как текстуры NGL. */

#include <stdint.h>
#include <stddef.h>
#include <fs.h>
#include <mem.h>
#include <gfx.h>
#include <texload.h>

#define TEXLOAD_MAX_DIM 128

static uint16_t tl_u16(const uint8_t *p) { return (uint16_t)p[0] | ((uint16_t)p[1] << 8); }
static uint32_t tl_u32(const uint8_t *p) { return (uint32_t)tl_u16(p) | ((uint32_t)tl_u16(p + 2) << 16); }

int texload_bmp(const char *name) {
    uint32_t size = fs_disk_size(name);
    if (!size || size < 54) return -1;
    /* Кадр может быть большим (1920x1080x3 ≈ 6 МБ) — буфер вне кучи. */
    uint64_t pages = (size + 4095) / 4096;
    uint8_t *data = (uint8_t *)pmm_alloc_contig(pages);
    if (!data) return -2;
    uint32_t got = 0;
    if (fs_read_direct(name, data, size, &got) < 0 || got != size) {
        pmm_free_contig(data, pages);
        return -3;
    }

    if (data[0] != 'B' || data[1] != 'M') {
        pmm_free_contig(data, pages);
        return -4;
    }
    uint32_t offset = tl_u32(data + 10);
    int32_t w = (int32_t)tl_u32(data + 18);
    int32_t h = (int32_t)tl_u32(data + 22);
    uint16_t bpp = tl_u16(data + 28);
    uint32_t compression = tl_u32(data + 30);
    if (bpp != 24 || compression != 0 || w <= 0 || h == 0) {
        pmm_free_contig(data, pages);
        return -4;
    }
    int topdown = h < 0;
    if (topdown) h = -h;
    if (w > 8192 || h > 8192) {
        pmm_free_contig(data, pages);
        return -5;
    }

    uint32_t row_size = ((uint32_t)w * 3 + 3) & ~3u;
    if (offset > size || row_size * (uint32_t)h > size - offset) {
        pmm_free_contig(data, pages);
        return -4;
    }

    /* Даунскейл до TEXLOAD_MAX_DIM (nearest) и BGR → RGB. */
    int tw = w, th = h;
    while (tw > TEXLOAD_MAX_DIM || th > TEXLOAD_MAX_DIM) {
        tw = (tw + 1) / 2;
        th = (th + 1) / 2;
    }
    static uint8_t rgb[TEXLOAD_MAX_DIM * TEXLOAD_MAX_DIM * 3];
    for (int ty = 0; ty < th; ++ty) {
        int sy = (int)((float)ty * h / th);
        if (sy >= h) sy = h - 1;
        if (!topdown) sy = h - 1 - sy; /* BMP хранит строки снизу вверх */
        const uint8_t *src_row = data + offset + (uint32_t)sy * row_size;
        uint8_t *dst_row = &rgb[(size_t)ty * tw * 3];
        for (int tx = 0; tx < tw; ++tx) {
            int sx = (int)((float)tx * w / tw);
            if (sx >= w) sx = w - 1;
            const uint8_t *p = src_row + (size_t)sx * 3;
            dst_row[tx * 3 + 0] = p[2];
            dst_row[tx * 3 + 1] = p[1];
            dst_row[tx * 3 + 2] = p[0];
        }
    }
    int id = ngl_texture(tw, th, rgb);
    pmm_free_contig(data, pages);
    return id;
}