/* SNAKE — первая программа для NYKLIMA OS.
   Управление: WASD, Esc — выход, Enter — заново после проигрыша.
   Графика: спрайты отрендерены RTX 3050 (CUDA) на хосте, загружены
   из FAT16 как текстуры NGL. Компилируется как PIE, запускается pgm_run(). */

#include <stdint.h>
#include <stddef.h>
#include <limine.h>
#include <pgm.h>

#if !defined(_MSC_VER)

#define CELL 16
#define GRID_W 64
#define GRID_H 28
#define FIELD_Y 96
#define MAX_LEN 512
#define MOVE_TICKS 8

/* палитра */
#define C_BG 0x0a0f18
#define C_FIELD 0x101828
#define C_SNAKE 0x54e38e
#define C_HEAD 0x40d9ff
#define C_FOOD 0xff6f7c
#define C_TEXT 0xd6e4f0
#define C_MUTED 0x8aa4bd

void nyklima_main(struct pgm_api *api);

void nyklima_main(struct pgm_api *api) {
    struct limine_framebuffer *fb = api->fb;

    /* Спрайты, отрендеренные на 3050 (упадём на плоские цвета, если их нет). */
    int tex_food = api->texload ? api->texload("FOOD.BMP") : -1;
    int tex_body = api->texload ? api->texload("BODY.BMP") : -1;
    int tex_head = api->texload ? api->texload("HEAD.BMP") : -1;

    int snake_x[MAX_LEN], snake_y[MAX_LEN];
    int len = 4, head = 0;
    int dx = 1, dy = 0, ndx = 1, ndy = 0;
    int food_x = 40, food_y = 14;
    int score = 0, dead = 0, grew = 0, last_score = -1, last_dead_drawn = 0;
    int tail_x = -1, tail_y = -1; /* последняя освобождённая клетка */
    uint32_t rng = 0x1234567;
    uint32_t last_move = 0;

    snake_x[0] = 20; snake_y[0] = 14;
    snake_x[1] = 19; snake_y[1] = 14;
    snake_x[2] = 18; snake_y[2] = 14;
    snake_x[3] = 17; snake_y[3] = 14;

    /* --- статичная сцена: фон, поле, сетка, заголовок (один раз) --- */
    api->fill(fb, 0, 0, fb->width, fb->height, C_BG);
    api->text(fb, 24, 24, "SNAKE  WASD MOVE  ESC EXIT", C_MUTED, 1);
    api->text(fb, 380, 24, "SCORE", C_MUTED, 1);
    api->text_uint(fb, 428, 24, 0, C_TEXT, 1);
    api->text(fb, 700, 24, "GFX BY RTX 3050", C_MUTED, 1);
    api->fill(fb, 0, FIELD_Y, GRID_W * CELL, GRID_H * CELL, C_FIELD);
    for (int gy = 0; gy < GRID_H; ++gy)
        for (int gx = 0; gx < GRID_W; gx += 4)
            api->fill(fb, (size_t)gx * CELL, (size_t)FIELD_Y + (size_t)gy * CELL, 2, 2, 0x162238);

    /* еда + змейка на старте */
    if (tex_food >= 0) api->sprite(fb, tex_food, food_x * CELL, FIELD_Y + food_y * CELL, CELL, CELL);
    else api->fill(fb, (size_t)food_x * CELL, (size_t)FIELD_Y + (size_t)food_y * CELL, CELL - 2, CELL - 2, C_FOOD);
    for (int i = 0; i < len; ++i) {
        int idx = (head - i + MAX_LEN) % MAX_LEN;
        if (i == 0 && tex_head >= 0) api->sprite(fb, tex_head, snake_x[idx] * CELL, FIELD_Y + snake_y[idx] * CELL, CELL, CELL);
        else if (tex_body >= 0) api->sprite(fb, tex_body, snake_x[idx] * CELL, FIELD_Y + snake_y[idx] * CELL, CELL, CELL);
        else api->fill(fb, (size_t)snake_x[idx] * CELL, (size_t)FIELD_Y + (size_t)snake_y[idx] * CELL, CELL - 2, CELL - 2, i == 0 ? C_HEAD : C_SNAKE);
    }

    for (;;) {
        uint8_t sc;
        while (api->kbd_pop(&sc)) {
            if (sc == 0x01) return; /* Esc */
            if (dead && sc == 0x1c) {
                len = 4; head = 0; dx = 1; dy = 0; ndx = 1; ndy = 0;
                score = 0; dead = 0; grew = 0; last_score = -1; last_dead_drawn = 0;
                snake_x[0] = 20; snake_y[0] = 14;
                snake_x[1] = 19; snake_y[1] = 14;
                snake_x[2] = 18; snake_y[2] = 14;
                snake_x[3] = 17; snake_y[3] = 14;
            }
            if (!dead) {
                if (sc == 0x11 && dy == 0) { ndx = 0; ndy = -1; }
                if (sc == 0x1f && dy == 0) { ndx = 0; ndy = 1; }
                if (sc == 0x1e && dx == 0) { ndx = -1; ndy = 0; }
                if (sc == 0x20 && dx == 0) { ndx = 1; ndy = 0; }
            }
        }

        if (dead || (*api->ticks - last_move) < MOVE_TICKS) continue;
        last_move = *api->ticks;
        dx = ndx; dy = ndy;
        int nx = snake_x[head] + dx;
        int ny = snake_y[head] + dy;

        if (nx < 0 || ny < 0 || nx >= GRID_W || ny >= GRID_H) dead = 1;
        else {
            for (int i = 0; i < len; ++i) {
                int idx = (head - i + MAX_LEN) % MAX_LEN;
                if (snake_x[idx] == nx && snake_y[idx] == ny && !(i == len - 1 && !grew)) dead = 1;
            }
        }

        if (dead) {
            if (!last_dead_drawn) {
                api->fill(fb, 320, 320, 384, 96, 0x162238);
                api->rect(fb, 320, 320, 384, 96, 0x315176);
                api->text(fb, 384, 344, "GAME OVER", C_TEXT, 2);
                api->text(fb, 366, 384, "ENTER RESTART  ESC EXIT", C_MUTED, 1);
                last_dead_drawn = 1;
            }
            continue;
        }

        /* стереть хвост (если не растём) */
        tail_x = snake_x[(head - len + 1 + MAX_LEN) % MAX_LEN];
        tail_y = snake_y[(head - len + 1 + MAX_LEN) % MAX_LEN];
        if (!grew) {
            api->fill(fb, (size_t)tail_x * CELL, (size_t)FIELD_Y + (size_t)tail_y * CELL, CELL - 2, CELL - 2, C_FIELD);
            api->fill(fb, (size_t)tail_x * CELL + 1, (size_t)FIELD_Y + (size_t)tail_y * CELL + 1, 2, 2, 0x162238);
        } else { grew--; len++; }

        head = (head + 1) % MAX_LEN;
        snake_x[head] = nx;
        snake_y[head] = ny;

        /* старая голова становится телом */
        if (tex_body >= 0) api->sprite(fb, tex_body, snake_x[(head - 1 + MAX_LEN) % MAX_LEN] * CELL, FIELD_Y + snake_y[(head - 1 + MAX_LEN) % MAX_LEN] * CELL, CELL, CELL);
        else api->fill(fb, (size_t)snake_x[(head - 1 + MAX_LEN) % MAX_LEN] * CELL, (size_t)FIELD_Y + (size_t)snake_y[(head - 1 + MAX_LEN) % MAX_LEN] * CELL, CELL - 2, CELL - 2, C_SNAKE);

        /* новая голова */
        if (tex_head >= 0) api->sprite(fb, tex_head, nx * CELL, FIELD_Y + ny * CELL, CELL, CELL);
        else api->fill(fb, (size_t)nx * CELL, (size_t)FIELD_Y + (size_t)ny * CELL, CELL - 2, CELL - 2, C_HEAD);

        if (nx == food_x && ny == food_y) {
            score += 10;
            grew += 4;
            for (;;) {
                rng ^= rng << 13; rng ^= rng >> 17; rng ^= rng << 5;
                food_x = (int)(rng % GRID_W);
                food_y = (int)((rng / GRID_W) % GRID_H);
                int on_snake = 0;
                for (int i = 0; i < len; ++i) {
                    int idx = (head - i + MAX_LEN) % MAX_LEN;
                    if (snake_x[idx] == food_x && snake_y[idx] == food_y) { on_snake = 1; break; }
                }
                if (!on_snake) break;
            }
            if (tex_food >= 0) api->sprite(fb, tex_food, food_x * CELL, FIELD_Y + food_y * CELL, CELL, CELL);
            else api->fill(fb, (size_t)food_x * CELL, (size_t)FIELD_Y + (size_t)food_y * CELL, CELL - 2, CELL - 2, C_FOOD);
        }

        if (score != last_score) {
            api->fill(fb, 428, 24, 60, 8, C_BG);
            api->text_uint(fb, 428, 24, (uint32_t)score, C_TEXT, 1);
            last_score = score;
        }
    }
}

#else

void nyklima_main(struct pgm_api *api) { (void)api; }

#endif
