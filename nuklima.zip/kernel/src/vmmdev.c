/* VMMDev VirtualBox: обмен запросами через порт 0x5108 (физический адрес
   буфера), включение абсолютной мыши. Кнопки остаются на PS/2 (IRQ12),
   позиция приходит отсюда — синхронно с курсором хоста. */

#include <stdint.h>
#include <mem.h>
#include <vmmdev.h>

#if !defined(_MSC_VER)

#define VMMDEV_PORT        0x5108
#define VMMDEV_VERSION     0x10001
#define VMMDEV_REQ_REPORT_GUEST_INFO 50
#define VMMDEV_REQ_GET_MOUSE_STATUS  51
#define VMMDEV_REQ_SET_MOUSE_STATUS  52
#define VMMDEV_MOUSE_GUEST_CAN_ABSOLUTE 0x1
#define VMMDEV_MOUSE_HOST_HAS_ABSOLUTE  0x2

static void outl(uint16_t port, uint32_t v) { __asm__ volatile("outl %0, %1" : : "a"(v), "Nd"(port)); }
static uint8_t inb_(uint16_t port) { uint8_t v; __asm__ volatile("inb %1, %0" : "=a"(v) : "Nd"(port)); return v; }

static void dbg(const char *s) {
    for (; *s; ++s) {
        for (;;) { if (inb_(0x3fd) & 0x20) break; }
        __asm__ volatile("outb %0, %1" : : "a"((uint8_t)*s), "Nd"((uint16_t)0x3f8));
    }
}
static void dbg_hex(uint32_t v) {
    for (int i = 28; i >= 0; i -= 4) {
        uint8_t n = (v >> i) & 0xf;
        for (;;) { if (inb_(0x3fd) & 0x20) break; }
        __asm__ volatile("outb %0, %1" : : "a"("0123456789abcdef"[n]), "Nd"((uint16_t)0x3f8));
    }
}

/* Заголовок запроса + payload, всё в одной странице (хост читает по phys). */
static volatile uint32_t *req = NULL;
static uint64_t req_phys = 0;
static int vmm_ok = 0;

static int vmmdev_request(uint32_t type, uint32_t size) {
    req[0] = size;
    req[1] = VMMDEV_VERSION;
    req[2] = type;
    req[3] = 0xfffffffeu; /* rc: маркер «в обработке» */
    req[4] = 0;
    req[5] = 0;
    outl(VMMDEV_PORT, (uint32_t)req_phys);
    for (uint32_t i = 0; i < 20000000u; ++i)
        if (req[3] != 0xfffffffeu) return 1;
    return -1;
}

int vmmdev_init(void) {
    req = (volatile uint32_t *)pmm_alloc_contig(1);
    if (!req) return 0;
    req_phys = (uint64_t)req - mem_hhdm();
    dbg("VMM: phys="); dbg_hex((uint32_t)req_phys); dbg("\n");

    /* ReportGuestInfo: additions 1.0 — без этого VBox игнорирует запросы. */
    req[6] = 1; /* major */
    req[7] = 0; /* minor */
    int r1 = vmmdev_request(VMMDEV_REQ_REPORT_GUEST_INFO, 24 + 8);
    dbg("VMM: info rc="); dbg_hex((uint32_t)req[3]); dbg(" r="); dbg_hex((uint32_t)r1); dbg("\n");
    if (r1 < 0) return 0;

    /* Включить абсолютную мышь. */
    req[6] = VMMDEV_MOUSE_GUEST_CAN_ABSOLUTE;
    req[7] = 0;
    req[8] = 0;
    int r2 = vmmdev_request(VMMDEV_REQ_SET_MOUSE_STATUS, 24 + 12);
    dbg("VMM: setmouse rc="); dbg_hex((uint32_t)req[3]); dbg(" r="); dbg_hex((uint32_t)r2); dbg("\n");
    if (r2 < 0) return 0;

    int r3 = vmmdev_request(VMMDEV_REQ_GET_MOUSE_STATUS, 24 + 12);
    dbg("VMM: getmouse rc="); dbg_hex((uint32_t)req[3]);
    dbg(" feat="); dbg_hex(req[6]);
    dbg(" x="); dbg_hex(req[7]);
    dbg(" y="); dbg_hex(req[8]);
    dbg("\n");
    if (r3 < 0) return 0;
    vmm_ok = 1;
    return 1;
}

int vmmdev_mouse(int *x, int *y) {
    if (!vmm_ok) return 0;
    if (vmmdev_request(VMMDEV_REQ_GET_MOUSE_STATUS, 24 + 12) < 0) return 0;
    if (!(req[6] & VMMDEV_MOUSE_HOST_HAS_ABSOLUTE)) return 0;
    int px = (int)(int32_t)req[7];
    int py = (int)(int32_t)req[8];
    if (px < 0 || py < 0) return 0;
    *x = px;
    *y = py;
    return 1;
}

#else

int vmmdev_init(void) { return 0; }
int vmmdev_mouse(int *x, int *y) { (void)x; (void)y; return 0; }

#endif
