/* Детекция и включение расширенных инструкций CPU.
   CPUID: лист 1 (ECX/EDX — базовые флаги), лист 7 (AVX2/AVX-512/BMI).
   AVX требует, чтобы ОС управляла расширенным состоянием:
   CR4.OSXSAVE = 1, затем XSETBV включает биты XCR0 (x87/SSE/AVX).
   Без этого первая же ymm-инструкция даёт #UD. */

#include <stdint.h>
#include <cpu.h>

static struct {
    int sse2, sse3, ssse3, sse41, sse42;
    int avx, avx2, avx512f;
    int bmi1, bmi2, fma;
    int avx2_usable;      /* CPUID сказал «есть» И XCR0-состояние реально включилось */
    uint64_t xcr0;
} cpu;

static void dbg(const char *s) {
    for (; *s; ++s) {
        uint8_t lsr;
        do { __asm__ volatile("inb %1, %0" : "=a"(lsr) : "Nd"((uint16_t)0x3fd)); } while (!(lsr & 0x20));
        __asm__ volatile("outb %0, %1" : : "a"((uint8_t)*s), "Nd"((uint16_t)0x3f8));
    }
}

static void cpu_dbg_hex(uint64_t v) {
    int started = 0;
    for (int i = 60; i >= 0; i -= 4) {
        uint8_t n = (v >> i) & 0xf;
        if (!started && i > 0 && n == 0) continue;
        started = 1;
        uint8_t lsr;
        do { __asm__ volatile("inb %1, %0" : "=a"(lsr) : "Nd"((uint16_t)0x3fd)); } while (!(lsr & 0x20));
        __asm__ volatile("outb %0, %1" : : "a"("0123456789abcdef"[n]), "Nd"((uint16_t)0x3f8));
    }
    if (!started) {
        uint8_t lsr;
        do { __asm__ volatile("inb %1, %0" : "=a"(lsr) : "Nd"((uint16_t)0x3fd)); } while (!(lsr & 0x20));
        __asm__ volatile("outb %0, %1" : : "a"((uint8_t)'0'), "Nd"((uint16_t)0x3f8));
    }
}

static void cpu_cpuid(uint32_t leaf, uint32_t sub, uint32_t *a, uint32_t *b,
                      uint32_t *c, uint32_t *d) {
    __asm__ volatile("cpuid"
                     : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d)
                     : "a"(leaf), "c"(sub));
}

void cpu_init(void) {
    uint32_t a, b, c, d;
    
    /* Включить CR4.OSXSAVE ДО чтения CPUID — иначе бит OSXSAVE в CPUID = 0. */
    uint64_t cr4;
    __asm__ volatile("movq %%cr4, %0" : "=r"(cr4));
    cr4 |= (1ULL << 9) | (1ULL << 10) | (1ULL << 18); /* OSFXSR | OSXMMEXCPT | OSXSAVE */
    __asm__ volatile("movq %0, %%cr4" : : "r"(cr4) : "memory");
    
    cpu_cpuid(1, 0, &a, &b, &c, &d);
    cpu.sse2   = (d >> 26) & 1;
    cpu.sse3   = (c >> 0) & 1;
    cpu.ssse3  = (c >> 9) & 1;
    cpu.sse41  = (c >> 19) & 1;
    cpu.sse42  = (c >> 20) & 1;
    int xsave  = (c >> 26) & 1;
    cpu.avx    = (c >> 28) & 1;
    cpu.fma    = (c >> 12) & 1;

    cpu_cpuid(7, 0, &a, &b, &c, &d);
    cpu.bmi1   = (b >> 3) & 1;
    cpu.avx2   = cpu.avx && ((b >> 5) & 1);
    cpu.bmi2   = (b >> 8) & 1;
    cpu.avx512f = cpu.avx && ((b >> 16) & 1);

    if (xsave) {
        uint32_t lo, hi;
        __asm__ volatile("xgetbv" : "=a"(lo), "=d"(hi) : "c"(0));
        uint64_t xcr0 = ((uint64_t)hi << 32) | lo;
        xcr0 |= 0x7; /* x87 | SSE | AVX */
        if (cpu.avx512f) xcr0 |= (7ULL << 5); /* opmask | ZMM_Hi256 | Hi16_ZMM */
        __asm__ volatile("xsetbv" : : "c"(0), "a"((uint32_t)xcr0), "d"((uint32_t)(xcr0 >> 32)) : "memory");
        /* Верификация: перечитываем XCR0. AVX2-код включаем только если
           бит AVX-состояния реально встал — иначе vmovdqu даёт #UD. */
        __asm__ volatile("xgetbv" : "=a"(lo), "=d"(hi) : "c"(0));
        cpu.xcr0 = ((uint64_t)hi << 32) | lo;
        cpu.avx2_usable = cpu.avx2 && ((cpu.xcr0 >> 2) & 1);
    }
    /* COM1 выводит только BSP: одновременная запись AP смешивает байты лога. */
    cpu_cpuid(1, 0, &a, &b, &c, &d);
    if (((b >> 24) & 0xff) == 0) {
        dbg("NYKLIMA OS: cpu avx2_cpuid=");
        cpu_dbg_hex((uint64_t)cpu.avx2);
        dbg(" avx2_usable=");
        cpu_dbg_hex((uint64_t)cpu.avx2_usable);
        dbg(" xcr0=");
        cpu_dbg_hex(cpu.xcr0);
        dbg("\n");
    }
}

int cpu_has_avx(void)      { return cpu.avx; }
int cpu_has_avx2(void)     { return cpu.avx2_usable; }
int cpu_has_avx512f(void)  { return cpu.avx512f; }
int cpu_has_sse42(void)    { return cpu.sse42; }
int cpu_has_bmi2(void)     { return cpu.bmi2; }
uint64_t cpu_xcr0(void)    { return cpu.xcr0; }
