#include <disk.h>

#define ATA_PRIMARY_IO 0x1f0
#define ATA_PRIMARY_CTRL 0x3f6
#define ATA_STATUS 7
#define ATA_COMMAND 7
#define ATA_DATA 0
#define ATA_SECTOR_COUNT 2
#define ATA_LBA_LOW 3
#define ATA_LBA_MID 4
#define ATA_LBA_HIGH 5
#define ATA_DRIVE 6
#define ATA_CMD_READ 0x20
#define ATA_CMD_WRITE 0x30
#define ATA_CMD_READ_EXT 0x24
#define ATA_CMD_WRITE_EXT 0x34
#define ATA_CMD_CACHE_FLUSH 0xe7
#define ATA_CMD_CACHE_FLUSH_EXT 0xea
#define ATA_CMD_IDENTIFY 0xec
#define ATA_DEV_MASTER 0xa0
#define ATA_DEV_LBA 0x40

static int ata_detected = 0;
static int ata_lba48 = 0;
static uint64_t ata_max_lba28 = 0;
static uint64_t ata_max_lba48 = 0;

static void outb(uint16_t port, uint8_t value) { __asm__ volatile("outb %0, %1" : : "a"(value), "Nd"(port)); }
static uint8_t inb(uint16_t port) { uint8_t value; __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port)); return value; }
static uint16_t inw(uint16_t port) { uint16_t value; __asm__ volatile("inw %1, %0" : "=a"(value) : "Nd"(port)); return value; }
static void io_wait(void) { (void)inb(ATA_PRIMARY_CTRL); }

static int wait_ready(int want_drq) {
    uint8_t status;
    for (uint32_t i = 0; i < 10000000; ++i) {
        status = inb(ATA_PRIMARY_IO + ATA_STATUS);
        if (status & 1) return -1;
        if (!(status & 0x80) && ((status & 8) != 0) == want_drq) return 0;
        io_wait();
    }
    return -1;
}

static int ata_identify(void) {
    if (wait_ready(0) < 0) return -1;
    outb(ATA_PRIMARY_IO + ATA_DRIVE, ATA_DEV_MASTER);
    io_wait();
    outb(ATA_PRIMARY_IO + ATA_SECTOR_COUNT, 0);
    outb(ATA_PRIMARY_IO + ATA_LBA_LOW, 0);
    outb(ATA_PRIMARY_IO + ATA_LBA_MID, 0);
    outb(ATA_PRIMARY_IO + ATA_LBA_HIGH, 0);
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_IDENTIFY);
    uint8_t status = inb(ATA_PRIMARY_IO + ATA_STATUS);
    if (status == 0) return -1;
    if (wait_ready(1) < 0) return -1;
    uint16_t ident[256];
    for (int i = 0; i < 256; ++i) ident[i] = inw(ATA_PRIMARY_IO + ATA_DATA);
    if (ident[60] == 0 && ident[61] == 0) return -1;
    /* Слова 60-61 — 28-битный max LBA; слова 100-103 — 48-битный
       (действительны только при установленном бите 10 слова 83).
       Слова 62-63 описывают DMA и к размеру диска отношения не имеют. */
    ata_max_lba28 = (uint64_t)ident[60] | ((uint64_t)ident[61] << 16);
    if (ident[83] & (1 << 10)) {
        ata_lba48 = 1;
        ata_max_lba48 = (uint64_t)ident[100] | ((uint64_t)ident[101] << 16)
                      | ((uint64_t)ident[102] << 32) | ((uint64_t)ident[103] << 48);
    }
    ata_detected = 1;
    return 0;
}

static int lba_valid(uint64_t lba, uint64_t count) {
    uint64_t max = (ata_lba48 && lba >= 0x10000000u) ? ata_max_lba48 : ata_max_lba28;
    return max && lba + count <= max;
}

static int select_lba28(uint32_t lba, uint16_t count) {
    if (lba >= 0x10000000u) return -1;
    if (!count || count > 256) return -1;
    if ((uint64_t)lba + count > 0x10000000ull) return -1;
    outb(ATA_PRIMARY_IO + ATA_DRIVE, (uint8_t)(0xe0 | ((lba >> 24) & 0x0f)));
    io_wait();
    outb(ATA_PRIMARY_IO + ATA_SECTOR_COUNT, count == 256 ? 0 : (uint8_t)count);
    outb(ATA_PRIMARY_IO + ATA_LBA_LOW, (uint8_t)lba);
    outb(ATA_PRIMARY_IO + ATA_LBA_MID, (uint8_t)(lba >> 8));
    outb(ATA_PRIMARY_IO + ATA_LBA_HIGH, (uint8_t)(lba >> 16));
    return 0;
}

static int select_lba48(uint64_t lba, uint16_t count) {
    if (lba >= ((uint64_t)1 << 48)) return -1;
    outb(ATA_PRIMARY_IO + ATA_DRIVE, 0x40);
    io_wait();
    outb(ATA_PRIMARY_IO + ATA_SECTOR_COUNT, (uint8_t)(count >> 8));
    outb(ATA_PRIMARY_IO + ATA_LBA_LOW, (uint8_t)(lba >> 24));
    outb(ATA_PRIMARY_IO + ATA_LBA_MID, (uint8_t)(lba >> 32));
    outb(ATA_PRIMARY_IO + ATA_LBA_HIGH, (uint8_t)(lba >> 40));
    outb(ATA_PRIMARY_IO + ATA_SECTOR_COUNT, (uint8_t)count);
    outb(ATA_PRIMARY_IO + ATA_LBA_LOW, (uint8_t)lba);
    outb(ATA_PRIMARY_IO + ATA_LBA_MID, (uint8_t)(lba >> 8));
    outb(ATA_PRIMARY_IO + ATA_LBA_HIGH, (uint8_t)(lba >> 16));
    return 0;
}

static int read_sectors_lba28(uint32_t lba, uint8_t *buffer, uint16_t count) {
    if (!buffer || select_lba28(lba, count) < 0) return -1;
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_READ);
    for (uint16_t s = 0; s < count; ++s) {
        if (wait_ready(1) < 0) return -1;
        for (uint32_t i = 0; i < 256; ++i) {
            uint16_t word = inw(ATA_PRIMARY_IO + ATA_DATA);
            buffer[s * 512 + i * 2] = (uint8_t)word;
            buffer[s * 512 + i * 2 + 1] = (uint8_t)(word >> 8);
        }
    }
    return 0;
}

static int read_sectors_lba48(uint64_t lba, uint8_t *buffer, uint16_t count) {
    if (!buffer || select_lba48(lba, count) < 0) return -1;
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_READ_EXT);
    for (uint16_t s = 0; s < count; ++s) {
        if (wait_ready(1) < 0) return -1;
        for (uint32_t i = 0; i < 256; ++i) {
            uint16_t word = inw(ATA_PRIMARY_IO + ATA_DATA);
            buffer[s * 512 + i * 2] = (uint8_t)word;
            buffer[s * 512 + i * 2 + 1] = (uint8_t)(word >> 8);
        }
    }
    return 0;
}

static int write_sectors_lba28(uint32_t lba, const uint8_t *buffer, uint16_t count) {
    if (!buffer || select_lba28(lba, count) < 0) return -1;
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_WRITE);
    for (uint16_t s = 0; s < count; ++s) {
        if (wait_ready(1) < 0) return -1;
        for (uint32_t i = 0; i < 256; ++i) {
            __asm__ volatile("outw %0, %1" : : "a"((uint16_t)(buffer[s * 512 + i * 2] | ((uint16_t)buffer[s * 512 + i * 2 + 1] << 8))), "Nd"((uint16_t)(ATA_PRIMARY_IO + ATA_DATA)));
        }
    }
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_CACHE_FLUSH);
    return wait_ready(0);
}

static int write_sectors_lba48(uint64_t lba, const uint8_t *buffer, uint16_t count) {
    if (!buffer || select_lba48(lba, count) < 0) return -1;
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_WRITE_EXT);
    for (uint16_t s = 0; s < count; ++s) {
        if (wait_ready(1) < 0) return -1;
        for (uint32_t i = 0; i < 256; ++i) {
            __asm__ volatile("outw %0, %1" : : "a"((uint16_t)(buffer[s * 512 + i * 2] | ((uint16_t)buffer[s * 512 + i * 2 + 1] << 8))), "Nd"((uint16_t)(ATA_PRIMARY_IO + ATA_DATA)));
        }
    }
    outb(ATA_PRIMARY_IO + ATA_COMMAND, ATA_CMD_CACHE_FLUSH_EXT);
    return wait_ready(0);
}

int disk_read(uint32_t lba, uint8_t *buffer) {
    if (!ata_detected && ata_identify() < 0) return -1;
    if (ata_lba48 && lba >= 0x10000000u) {
        if (!lba_valid(lba, 1)) return -1;
        return read_sectors_lba48(lba, buffer, 1);
    }
    if (!lba_valid(lba, 1)) return -1;
    return read_sectors_lba28(lba, buffer, 1);
}

int disk_write(uint32_t lba, const uint8_t *buffer) {
    if (!ata_detected && ata_identify() < 0) return -1;
    if (ata_lba48 && lba >= 0x10000000u) {
        if (!lba_valid(lba, 1)) return -1;
        return write_sectors_lba48(lba, buffer, 1);
    }
    if (!lba_valid(lba, 1)) return -1;
    return write_sectors_lba28(lba, buffer, 1);
}

int disk_read_multi(uint32_t lba, uint8_t *buffer, uint16_t count) {
    if (!ata_detected && ata_identify() < 0) return -1;
    if (!buffer || !count) return -1;
    while (count) {
        uint16_t chunk = count > 256 ? 256 : count;
        if (!lba_valid(lba, chunk)) return -1;
        int result = ata_lba48 && lba >= 0x10000000u
            ? read_sectors_lba48(lba, buffer, chunk)
            : read_sectors_lba28(lba, buffer, chunk);
        if (result < 0) return -1;
        lba += chunk;
        buffer += (uint32_t)chunk * 512;
        count = (uint16_t)(count - chunk);
    }
    return 0;
}

int disk_write_multi(uint32_t lba, const uint8_t *buffer, uint16_t count) {
    if (!ata_detected && ata_identify() < 0) return -1;
    if (!buffer || !count) return -1;
    while (count) {
        uint16_t chunk = count > 256 ? 256 : count;
        if (!lba_valid(lba, chunk)) return -1;
        int result = ata_lba48 && lba >= 0x10000000u
            ? write_sectors_lba48(lba, buffer, chunk)
            : write_sectors_lba28(lba, buffer, chunk);
        if (result < 0) return -1;
        lba += chunk;
        buffer += (uint32_t)chunk * 512;
        count = (uint16_t)(count - chunk);
    }
    return 0;
}