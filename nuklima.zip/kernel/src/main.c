﻿#include <stdint.h>
#include <stddef.h>
#include <stdarg.h>
#include <limine.h>
#include <fs.h>
#include <paging.h>
#include <mem.h>
#include <gfx.h>
#include <fbdraw.h>
#include <wm.h>
#include <texload.h>
#include <pgm.h>
#include <cpu.h>
#include <sched.h>
#include <smp.h>

#if defined(_MSC_VER)
#pragma section(".limine_requests_start_marker", read)
#pragma section(".limine_requests", read, write)
#pragma section(".limine_requests_end_marker", read)
#pragma intrinsic(__outbyte)
#pragma intrinsic(__inbyte)
void __outbyte(unsigned short port, unsigned char value);
unsigned char __inbyte(unsigned short port);
#define LIMINE_SECTION(name) __declspec(allocate(name))
#define LIMINE_USED
#else
#define LIMINE_SECTION(name) __attribute__((used, section(name)))
#define LIMINE_USED
#endif

LIMINE_SECTION(".limine_requests_start_marker") LIMINE_USED
static volatile uint64_t requests_start[] = LIMINE_REQUESTS_START_MARKER;
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile uint64_t base_revision[] = LIMINE_BASE_REVISION(6);
void kmain(void);
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_entry_point_request entry_request = {
    .id = LIMINE_ENTRY_POINT_REQUEST_ID, .revision = 0, .response = NULL, .entry = kmain
};
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_framebuffer_request framebuffer_request = {
    .id = LIMINE_FRAMEBUFFER_REQUEST_ID, .revision = 0, .response = NULL
};
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_hhdm_request hhdm_request = {
    .id = LIMINE_HHDM_REQUEST_ID, .revision = 0, .response = NULL
};
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_memmap_request memmap_request = {
    .id = LIMINE_MEMMAP_REQUEST_ID, .revision = 0, .response = NULL
};
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_executable_address_request executable_address_request = {
    .id = LIMINE_EXECUTABLE_ADDRESS_REQUEST_ID, .revision = 0, .response = NULL
};
LIMINE_SECTION(".limine_requests") LIMINE_USED
static volatile struct limine_rsdp_request rsdp_request = {
    .id = LIMINE_RSDP_REQUEST_ID, .revision = 0, .response = NULL
};
LIMINE_SECTION(".limine_requests_end_marker") LIMINE_USED
static volatile uint64_t requests_end[] = LIMINE_REQUESTS_END_MARKER;

extern char bss_start[], bss_end[];

static void zero_bss(void) {
    for (char *p = bss_start; p < bss_end; ++p) *p = 0;
}

static uint64_t hhdm_offset(void) {
    if (!hhdm_request.response) return 0;
    return hhdm_request.response->offset;
}

static uint64_t g_hhdm_offset = 0;

static uint8_t inb(uint16_t port);

static void serial_char(char c) {
    /* Виртуальный UART VirtualBox темперирует передачу по baud rate:
       байт, записанный в THR до освобождения, теряется. Ждём THRE. */
#if !defined(_MSC_VER)
    while (!(inb(0x3fd) & 0x20)) { }
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)c), "Nd"((uint16_t)0x3f8));
#else
    while (!(__inbyte(0x3fd) & 0x20)) { }
    __outbyte(0x3f8, (unsigned char)c);
#endif
}

static void serial_init(void) {
#if !defined(_MSC_VER)
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x00), "Nd"((uint16_t)0x3f9));
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x80), "Nd"((uint16_t)0x3fb));
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x01), "Nd"((uint16_t)0x3f8));
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x00), "Nd"((uint16_t)0x3f9));
    __asm__ volatile("outb %0, %1" : : "a"((uint8_t)0x03), "Nd"((uint16_t)0x3fb));
#endif
}

static void serial(const char *s) {
    while (*s) serial_char(*s++);
}

static void serial_hex(uint64_t v) {
    serial("0x");
    int started = 0;
    for (int i = 60; i >= 0; i -= 4) {
        int n = (int)((v >> i) & 0xf);
        if (!started && i > 0 && n == 0) continue;
        started = 1;
        serial_char((char)(n < 10 ? '0' + n : 'a' + n - 10));
    }
    if (!started) serial_char('0');
}

static void serial_dec(uint64_t v) {
    char buf[24];
    int i = 0;
    do { buf[i++] = (char)('0' + (v % 10)); v /= 10; } while (v);
    while (i > 0) serial_char(buf[--i]);
}

static void serial_printf(const char *fmt, ...) {
    va_list ap;
    va_start(ap, fmt);
    for (const char *p = fmt; *p; ++p) {
        if (*p != '%' || !p[1]) { serial_char(*p); continue; }
        ++p;
        switch (*p) {
            case 's': serial(va_arg(ap, const char *)); break;
            case 'd': {
                int v = va_arg(ap, int);
                if (v < 0) { serial_char('-'); serial_dec((uint64_t)(-(int64_t)v)); }
                else serial_dec((uint64_t)v);
                break;
            }
            case 'u': serial_dec(va_arg(ap, unsigned int)); break;
            case 'x': serial_hex(va_arg(ap, uint64_t)); break;
            case 'p': serial_hex((uint64_t)va_arg(ap, void *)); break;
            case 'c': serial_char((char)va_arg(ap, int)); break;
            case '%': serial_char('%'); break;
            default: serial_char('%'); serial_char(*p); break;
        }
    }
    va_end(ap);
}

static uint8_t inb(uint16_t port) {
#if !defined(_MSC_VER)
    uint8_t value; __asm__ volatile("inb %1, %0" : "=a"(value) : "Nd"(port)); return value;
#else
    return __inbyte(port);
#endif
}
static void halt_forever(void) {
#if !defined(_MSC_VER)
    for (;;) __asm__ volatile("hlt");
#else
    for (;;) { }
#endif
}

#if !defined(_MSC_VER)
static void outb(uint16_t port, uint8_t value) { __asm__ volatile("outb %0, %1" : : "a"(value), "Nd"(port)); }
static void io_wait(void) { (void)inb(0x80); }

static void pic_init(void) {
    /* ICW1: начать инициализацию, нужны ICW4 */
    outb(0x20, 0x11); io_wait();
    outb(0xa0, 0x11); io_wait();
    /* ICW2: базовые векторы (0x20 мастер, 0x28 слейв) */
    outb(0x21, 0x20); io_wait();
    outb(0xa1, 0x28); io_wait();
    /* ICW3: каскадирование (мастер IRQ2, слейв ID 2) */
    outb(0x21, 0x04); io_wait();
    outb(0xa1, 0x02); io_wait();
    /* ICW4: 8086 режим */
    outb(0x21, 0x01); io_wait();
    outb(0xa1, 0x01); io_wait();
    /* Замаскировать все IRQ — пока обработчиков нет */
    outb(0x21, 0xff);
    outb(0xa1, 0xff);
}
#endif

#if !defined(_MSC_VER)
struct idt_entry {
    uint16_t offset_low;
    uint16_t selector;
    uint8_t ist;
    uint8_t type_attr;
    uint16_t offset_mid;
    uint32_t offset_high;
    uint32_t zero;
} __attribute__((packed));

struct idt_ptr {
    uint16_t limit;
    uint64_t base;
} __attribute__((packed));

static struct idt_entry idt_entries[32 + 16]; /* исключения + IRQ0..15 */
static struct idt_ptr idtp;
static uint16_t idt_code_selector;

struct idt_frame {
    uint64_t rip, cs, rflags, rsp, ss;
};

static void isr_report(int vector, uint64_t error_code, int has_error, void *frame) {
    struct idt_frame *f = (struct idt_frame *)frame;
    if (has_error && vector == 14) {
        uint64_t cr2;
        __asm__ volatile("movq %%cr2, %0" : "=r"(cr2));
        serial_printf("NYKLIMA OS: #PF error=%x cr2=%p\n", error_code, (void *)cr2);
    } else if (has_error) {
        serial_printf("NYKLIMA OS: CPU exception vector %d error=%x\n", vector, error_code);
    } else {
        serial_printf("NYKLIMA OS: CPU exception vector %d\n", vector);
    }
    serial_printf("NYKLIMA OS:  fault rip=%p cs=%x rflags=%x\n",
                  (void *)f->rip, (unsigned)f->cs, (unsigned)f->rflags);
    halt_forever();
}

#define ISR_NOERR(n) \
    __attribute__((interrupt)) static void isr_##n(void *frame) { \
        isr_report(n, 0, 0, frame); \
    }

#define ISR_ERR(n) \
    __attribute__((interrupt)) static void isr_##n(void *frame, unsigned long error_code) { \
        isr_report(n, (uint64_t)error_code, 1, frame); \
    }

ISR_NOERR(0)
ISR_NOERR(1)
ISR_NOERR(2)
ISR_NOERR(3)
ISR_NOERR(4)
ISR_NOERR(5)
ISR_NOERR(6)
ISR_NOERR(7)
ISR_ERR(8)
ISR_NOERR(9)
ISR_ERR(10)
ISR_ERR(11)
ISR_ERR(12)
ISR_ERR(13)
ISR_ERR(14)
ISR_NOERR(15)
ISR_NOERR(16)
ISR_ERR(17)
ISR_NOERR(18)
ISR_NOERR(19)
ISR_NOERR(20)
ISR_ERR(21)
ISR_NOERR(22)
ISR_NOERR(23)
ISR_NOERR(24)
ISR_NOERR(25)
ISR_NOERR(26)
ISR_NOERR(27)
ISR_NOERR(28)
ISR_ERR(29)
ISR_ERR(30)
ISR_NOERR(31)

static void set_idt_gate(int vector, uint64_t handler) {
    idt_entries[vector].offset_low = (uint16_t)handler;
    idt_entries[vector].selector = idt_code_selector;
    idt_entries[vector].ist = 0;
    idt_entries[vector].type_attr = 0x8e;
    idt_entries[vector].offset_mid = (uint16_t)(handler >> 16);
    idt_entries[vector].offset_high = (uint32_t)(handler >> 32);
    idt_entries[vector].zero = 0;
}

static void idt_install(void);
#if !defined(_MSC_VER)
__attribute__((interrupt)) static void irq_pit(void *frame);
__attribute__((interrupt)) static void irq_kbd(void *frame);
__attribute__((interrupt)) static void irq_mouse(void *frame);
#endif

static void idt_install(void) {
    /* Limine не обязан использовать селектор 0x08. В VirtualBox текущий
       64-битный код ядра находится в CS=0x28, а 0x08 является 16-битным
       сегментом. Ворота IDT должны ссылаться на фактический текущий CS. */
    __asm__ volatile("movw %%cs, %0" : "=r"(idt_code_selector));
    set_idt_gate(0, (uint64_t)isr_0);
    set_idt_gate(1, (uint64_t)isr_1);
    set_idt_gate(2, (uint64_t)isr_2);
    set_idt_gate(3, (uint64_t)isr_3);
    set_idt_gate(4, (uint64_t)isr_4);
    set_idt_gate(5, (uint64_t)isr_5);
    set_idt_gate(6, (uint64_t)isr_6);
    set_idt_gate(7, (uint64_t)isr_7);
    set_idt_gate(8, (uint64_t)isr_8);
    set_idt_gate(9, (uint64_t)isr_9);
    set_idt_gate(10, (uint64_t)isr_10);
    set_idt_gate(11, (uint64_t)isr_11);
    set_idt_gate(12, (uint64_t)isr_12);
    set_idt_gate(13, (uint64_t)isr_13);
    set_idt_gate(14, (uint64_t)isr_14);
    set_idt_gate(15, (uint64_t)isr_15);
    set_idt_gate(16, (uint64_t)isr_16);
    set_idt_gate(17, (uint64_t)isr_17);
    set_idt_gate(18, (uint64_t)isr_18);
    set_idt_gate(19, (uint64_t)isr_19);
    set_idt_gate(20, (uint64_t)isr_20);
    set_idt_gate(21, (uint64_t)isr_21);
    set_idt_gate(22, (uint64_t)isr_22);
    set_idt_gate(23, (uint64_t)isr_23);
    set_idt_gate(24, (uint64_t)isr_24);
    set_idt_gate(25, (uint64_t)isr_25);
    set_idt_gate(26, (uint64_t)isr_26);
    set_idt_gate(27, (uint64_t)isr_27);
    set_idt_gate(28, (uint64_t)isr_28);
    set_idt_gate(29, (uint64_t)isr_29);
    set_idt_gate(30, (uint64_t)isr_30);
    set_idt_gate(31, (uint64_t)isr_31);
    /* IRQ: после ремапа PIC векторы 32..47 (32+IRQ0..IRQ15). */
    set_idt_gate(32, (uint64_t)irq_pit);       /* IRQ0: PIT */
    set_idt_gate(33, (uint64_t)irq_kbd);       /* IRQ1: клавиатура */
    set_idt_gate(44, (uint64_t)irq_mouse);     /* IRQ12: PS/2 мышь */
    idtp.limit = (uint16_t)(sizeof(idt_entries) - 1);
    idtp.base = (uint64_t)&idt_entries[0];
    __asm__ volatile("lidt %0" : : "m"(idtp));
}

/* --- Таймер, клавиатурный буфер, мышь --- */

#define KBD_BUF_SIZE 128

volatile uint32_t pit_ticks = 0; /* используется и планировщиком */
static volatile uint8_t kbd_buf[KBD_BUF_SIZE];
static volatile uint32_t kbd_head = 0, kbd_tail = 0;
static volatile int mouse_x = 320, mouse_y = 240;
static volatile int mouse_max_x = 639, mouse_max_y = 479;
static volatile uint8_t mouse_buttons = 0;
static volatile uint8_t mouse_pkt[3];
static volatile int mouse_pkt_idx = 0;
static volatile int mouse_ready = 0;
static volatile uint32_t mouse_packets = 0;

static void irq_eoi(int slave) {
    if (smp_ioapic_ready()) {
        smp_irq_eoi();
    } else {
        if (slave) outb(0xa0, 0x20);
        outb(0x20, 0x20);
    }
}

__attribute__((interrupt)) static void irq_pit(void *frame) {
    (void)frame;
    ++pit_ticks;
    irq_eoi(0);
}

__attribute__((interrupt)) static void irq_kbd(void *frame) {
    (void)frame;
    uint8_t sc = inb(0x60);
    uint32_t next = (kbd_head + 1) & (KBD_BUF_SIZE - 1);
    if (next != kbd_tail) { kbd_buf[kbd_head] = sc; kbd_head = next; }
    irq_eoi(0);
}

__attribute__((interrupt)) static void irq_mouse(void *frame) {
    (void)frame;
    uint8_t data = inb(0x60);
    int idx = mouse_pkt_idx;
    /* Первый байт пакета всегда имеет установленный бит 3 — синхронизация. */
    if (idx == 0 && !(data & 0x08)) { irq_eoi(1); return; }
    mouse_pkt[idx] = data;
    if (++idx >= 3) {
        idx = 0;
        uint8_t flags = mouse_pkt[0];
        if (!(flags & 0xc0)) { /* без переполнения */
            /* int8_t уже выполняет знаковое расширение. Повторное вычитание
               256 по битам 4/5 превращало -1 в -257 и бросало курсор к краю. */
            int dx = (int)(int8_t)mouse_pkt[1];
            int dy = (int)(int8_t)mouse_pkt[2];
            int nx = mouse_x + dx, ny = mouse_y - dy; /* ось Y мыши инвертирована */
            if (nx < 0) nx = 0;
            if (ny < 0) ny = 0;
            if (nx > mouse_max_x) nx = mouse_max_x;
            if (ny > mouse_max_y) ny = mouse_max_y;
            mouse_x = nx;
            mouse_y = ny;
            mouse_buttons = (uint8_t)(flags & 0x07);
            mouse_ready = 1;
        }
        ++mouse_packets;
    }
    mouse_pkt_idx = idx;
    irq_eoi(1);
}

static void ps2_wait_write(void) { for (uint32_t i = 0; i < 100000 && (inb(0x64) & 0x02); ++i) { } }
static void ps2_wait_read(void) { for (uint32_t i = 0; i < 100000 && !(inb(0x64) & 0x01); ++i) { } }

static int mouse_write_cmd(uint8_t b) {
    ps2_wait_write(); outb(0x64, 0xd4);
    ps2_wait_write(); outb(0x60, b);
    for (uint32_t i = 0; i < 10000; ++i) { /* ждём ACK 0xfa (0xfe = повторить) */
        ps2_wait_read();
        uint8_t r = inb(0x60);
        if (r == 0xfa) return 1;
        if (r == 0xfe) { i = 0; continue; }
    }
    return 0;
}

static int keyboard_write_cmd(uint8_t b) {
    ps2_wait_write(); outb(0x60, b);
    for (uint32_t i = 0; i < 10000; ++i) {
        ps2_wait_read();
        uint8_t r = inb(0x60);
        if (r == 0xfa) return 1;
        if (r == 0xfe) { ps2_wait_write(); outb(0x60, b); }
    }
    return 0;
}

static void keyboard_init(void) {
    ps2_wait_write(); outb(0x64, 0xae);   /* включить первый PS/2-порт */
    ps2_wait_write(); outb(0x64, 0x20);   /* прочитать конфигурацию */
    ps2_wait_read();
    uint8_t cfg = inb(0x60);
    cfg |= 0x01 | 0x40;                   /* IRQ1 + перевод set 2 -> set 1 */
    cfg &= (uint8_t)~0x10;                /* включить тактирование клавиатуры */
    ps2_wait_write(); outb(0x64, 0x60);
    ps2_wait_write(); outb(0x60, cfg);
    int reset_defaults = keyboard_write_cmd(0xf6);
    int scanning = keyboard_write_cmd(0xf4);
    serial_printf("NYKLIMA OS: keyboard init cfg=%x ack_f6=%d ack_f4=%d\n",
                  cfg, reset_defaults, scanning);
}

static void mouse_init(void) {
    ps2_wait_write(); outb(0x64, 0xa8);   /* включить вспомогательное устройство */
    ps2_wait_write(); outb(0x64, 0x20);   /* прочитать байт конфигурации */
    ps2_wait_read();
    uint8_t cfg = inb(0x60);
    cfg |= 0x02;                          /* разрешить IRQ12 */
    cfg &= (uint8_t)~0x20;                /* включить тактирование мыши */
    ps2_wait_write(); outb(0x64, 0x60);
    ps2_wait_write(); outb(0x60, cfg);
    int a1 = mouse_write_cmd(0xf6);       /* настройки по умолчанию */
    int a2 = mouse_write_cmd(0xf4);       /* включить передачу данных */
    serial_printf("NYKLIMA OS: mouse init cfg=%x ack_f6=%d ack_f4=%d\n", cfg, a1, a2);
}

static void pit_init(void) {
    outb(0x43, 0x36);                     /* канал 0, режим 3, lobyte+hibyte */
    outb(0x40, 11932 & 0xff);             /* 1193182 Гц / 11932 ≈ 100 Гц */
    outb(0x40, 11932 >> 8);
}

/* Разрешить IRQ0, IRQ1, IRQ2 (каскад) и IRQ12 — после инициализации мыши. */
static void irq_unmask_input(void) {
    outb(0x21, 0xf8);
    outb(0xa1, 0xef);
}
#endif

static inline void irq_disable(void) {
#if !defined(_MSC_VER)
    __asm__ volatile("cli");
#endif
}
static inline void irq_enable(void) {
#if !defined(_MSC_VER)
    __asm__ volatile("sti");
#endif
}

#if !defined(_MSC_VER)
static int kbd_pop(uint8_t *out) {
    irq_disable();
    int have = kbd_head != kbd_tail;
    if (have) { *out = kbd_buf[kbd_tail]; kbd_tail = (kbd_tail + 1) & (KBD_BUF_SIZE - 1); }
    irq_enable();
    return have;
}
#else
static int kbd_pop(uint8_t *out) { (void)out; return 0; }
#endif

/* VirtualBox обычно отдаёт переведённый set 1. Таблица ниже также принимает
   make-коды set 2, чтобы ввод не зависел от состояния бита translation 8042. */
static uint8_t keyboard_normalize(uint8_t sc) {
    switch (sc) {
        case 0x2b: return 0x21; /* set 2 F */
        case 0x43: return 0x17; /* set 2 I */
        case 0x34: return 0x22; /* set 2 G */
        case 0x76: return 0x01; /* set 2 Escape */
        case 0x5a: return 0x1c; /* set 2 Enter */
        default: return sc;
    }
}

/* Курсор мыши: сохранение/восстановление фона под стрелкой. */
#define CURSOR_W 16
#define CURSOR_H 16
static uint32_t cursor_save[CURSOR_W * CURSOR_H];
static int cursor_drawn = 0, cursor_last_x = 0, cursor_last_y = 0;
static const uint16_t cursor_spr[CURSOR_H] = {
    0x8000, 0xC000, 0xE000, 0xF000, 0xF800, 0xFC00, 0xFE00, 0xFF00,
    0xFF80, 0xFFC0, 0xFE00, 0xEE00, 0x8700, 0x0300, 0x0000, 0x0000
};

/* Убрать курсор до полной перерисовки сцены. Иначе cursor_update после
   wm_draw восстанавливает старый фон поверх уже нового кадра и оставляет
   прямоугольные артефакты от закрытых/перемещённых окон. */
static void cursor_hide(struct limine_framebuffer *fb) {
    if (!fb || !fb->address || fb->bpp != 32) return;
    if (cursor_drawn) {
        for (int row = 0; row < CURSOR_H; ++row)
            for (int col = 0; col < CURSOR_W; ++col) {
                size_t px = (size_t)cursor_last_x + col, py = (size_t)cursor_last_y + row;
                if (px < fb->width && py < fb->height)
                    *(uint32_t *)((uint64_t)fb->address + py * fb->pitch + px * 4) =
                        cursor_save[row * CURSOR_W + col];
            }
        cursor_drawn = 0;
    }
}

static void cursor_update(struct limine_framebuffer *fb) {
    if (!fb || !fb->address || fb->bpp != 32) return;
    cursor_hide(fb);
    int x = mouse_x, y = mouse_y;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x > (int)fb->width - CURSOR_W) x = (int)fb->width - CURSOR_W;
    if (y > (int)fb->height - CURSOR_H) y = (int)fb->height - CURSOR_H;
    for (int row = 0; row < CURSOR_H; ++row)
        for (int col = 0; col < CURSOR_W; ++col) {
            size_t px = (size_t)x + col, py = (size_t)y + row;
            if (px >= fb->width || py >= fb->height) continue;
            uint32_t *dst = (uint32_t *)((uint64_t)fb->address + py * fb->pitch + px * 4);
            cursor_save[row * CURSOR_W + col] = *dst;
            if (cursor_spr[row] & (0x8000 >> col)) *dst = FB_CYAN;
        }
    cursor_drawn = 1;
    cursor_last_x = x;
    cursor_last_y = y;
}

static void desktop_redraw(struct limine_framebuffer *fb, uint32_t ticks) {
    cursor_hide(fb);
    wm_draw(fb, ticks);
    cursor_update(fb);
}

static int api_kbd_pop(uint8_t *sc) { thread_yield(); return kbd_pop(sc); }

/* --- Демо многопоточности: два фоновых потока со сном --- */
volatile uint32_t demo_t1 = 0, demo_t2 = 0;
static void demo_thread1(void *arg) {
    (void)arg;
    for (;;) {
        demo_t1++;
        if ((demo_t1 % 5) == 0)
            serial_printf("NYKLIMA OS: [thread1 cpu=%d] tick %u\n", smp_self_index(), (unsigned)demo_t1);
        thread_sleep(50);
    }
}
static void demo_thread2(void *arg) {
    (void)arg;
    for (;;) {
        demo_t2++;
        if ((demo_t2 % 3) == 0)
            serial_printf("NYKLIMA OS: [thread2 cpu=%d] tick %u\n", smp_self_index(), (unsigned)demo_t2);
        thread_sleep(100);
    }
}

void kmain(void) {
#if !defined(_MSC_VER)
    serial_init();
#endif
    serial("NYKLIMA OS: kernel entered\n");
    zero_bss();
    serial("NYKLIMA OS: bss zeroed\n");
#if !defined(_MSC_VER)
    idt_install();
    pic_init();
#endif
    serial("NYKLIMA OS: idt installed\n");
#if !defined(_MSC_VER)
    pit_init();        /* таймер 100 Гц — до размаскирования IRQ */
    keyboard_init();   /* явно включить PS/2 keyboard и IRQ1 */
    mouse_init();      /* PS/2 мышь — IRQ12 пока замаскирован, ACK читаем напрямую */
    irq_unmask_input();/* теперь открыть IRQ0/1/2/12 */
#endif
    cpu_init();        /* детекция и включение AVX/AVX2/OSXSAVE */
    sched_init();      /* планировщик потоков */
    g_hhdm_offset = hhdm_offset();
    if (!g_hhdm_offset) {
        serial("NYKLIMA OS: warning: HHDM unavailable\n");
    }
    uint64_t kernel_phys_base = 0, kernel_virt_base = 0;
    if (executable_address_request.response) {
        kernel_phys_base = executable_address_request.response->physical_base;
        kernel_virt_base = executable_address_request.response->virtual_base;
    }
    paging_init(g_hhdm_offset, kernel_phys_base, kernel_virt_base,
                memmap_request.response);
    serial("NYKLIMA OS: paging initialized\n");
    pmm_init(g_hhdm_offset, memmap_request.response, kernel_phys_base,
             kernel_phys_base ? kernel_phys_base + ((uint64_t)bss_end - kernel_virt_base) : 0);
    /* Куча: первая свободная страница после bitmap-карты PMM. */
    {
        void *heap_page = pmm_alloc_contig(16);
        if (heap_page) heap_attach(heap_page, 64 * 1024);
        serial_printf("NYKLIMA OS: memory manager initialized (free pages %u)\n",
                      (unsigned)pmm_free_pages());
    }
    if (thread_create("demo1", demo_thread1, NULL) == 0 &&
        thread_create("demo2", demo_thread2, NULL) == 0)
        serial("NYKLIMA OS: 2 worker threads created (cooperative MT)\n");
    {   /* SMP: запуск AP-ядер через ACPI MADT + INIT/SIPI */
        uint64_t pml4_phys = 0;
        extern uint64_t paging_pml4_phys(void);
        pml4_phys = paging_pml4_phys();
        int aps = smp_init(rsdp_request.response, memmap_request.response, pml4_phys);
        serial_printf("NYKLIMA OS: SMP %s (%d AP online)\n",
                      aps > 0 ? "active" : "unavailable", aps > 0 ? aps : 0);
    }
    fs_init();
    serial("NYKLIMA OS: persistent FAT16 filesystem ready\n");
    if (!framebuffer_request.response || !framebuffer_request.response->framebuffer_count || !framebuffer_request.response->framebuffers) {
        serial("NYKLIMA OS: framebuffer unavailable\n"); halt_forever();
    }
    struct limine_framebuffer *fb = framebuffer_request.response->framebuffers[0];
    if (!fb || !fb->address || fb->bpp != 32 || fb->width < 640 || fb->height < 480 || fb->pitch < fb->width * 4) {
        serial("NYKLIMA OS: unsupported framebuffer format\n"); halt_forever();
    }
    mouse_max_x = (int)fb->width - 1;
    mouse_max_y = (int)fb->height - 1;
    int ram_fs = fs_is_ram();
    gfx_init(fb->width, fb->height);
    serial_printf("NYKLIMA OS: 3D renderer %s (%ux%u buffers)\n",
                  gfx_ready() ? "ready" : "unavailable", (unsigned)fb->width, (unsigned)fb->height);
    {   /* Мост 3050→FAT16→NGL: кадр, отрендеренный G1 на хосте. */
        int g1size = (int)fs_disk_size("G1FRAME.BMP");
        int g1tex = texload_bmp("G1FRAME.BMP");
        gfx_set_frame_texture(g1tex);
        serial_printf("NYKLIMA OS: G1 host frame size=%d tex=%d\n", g1size, g1tex);
    }
    /* Рабочий стол: окна SYSINFO и FILES открыты при загрузке. */
    wm_init((int)fb->width, (int)fb->height);
    wm_open(WM_CONTENT_INFO, "SYSINFO", 660, 90, 280, 220);
    wm_open(WM_CONTENT_FILES, "FILES", 70, 80, 300, 250);
    serial(ram_fs ? "NYKLIMA OS: RAM filesystem active\n" : "NYKLIMA OS: persistent FAT16 filesystem ready\n");
    serial_printf("NYKLIMA OS: desktop ready (F files, I sysinfo, G cube, S settings, Esc close, Enter focus)\n");
#if !defined(_MSC_VER)
    __asm__ volatile("sti");
    serial("NYKLIMA OS: interrupts enabled (IF=1)\n");
#endif
    desktop_redraw(fb, 0);
    uint8_t last_scancode = 0;
    uint8_t set2_break = 0;
    uint32_t repeat_guard = 0;
    uint32_t last_tick_draw = 0;
    for (;;) {
        uint8_t scancode;
        if (!kbd_pop(&scancode)) {
#if !defined(_MSC_VER)
            thread_yield(); /* даём шанс фоновым потокам */
            struct wm_window *cube_win = wm_cube_window();
            if (cube_win && pit_ticks - last_tick_draw >= 2) {
                last_tick_draw = pit_ticks;
                /* Только окно куба (~50К пикселей) вместо всего стола (786К) — плавно. */
                wm_repaint_window(fb, cube_win, pit_ticks);
                cursor_update(fb);
            }
            if (mouse_ready) {
                mouse_ready = 0;
                if (wm_mouse(mouse_x, mouse_y, mouse_buttons)) {
                    desktop_redraw(fb, pit_ticks);
                } else {
                    cursor_update(fb);
                }
            }
            __asm__ volatile("hlt");
#endif
            continue;
        }
        if (scancode == 0xe0) continue; /* расширенный префикс не используется */
        if (scancode == 0xf0) { set2_break = 1; continue; }
        if (set2_break) { set2_break = 0; last_scancode = 0; repeat_guard = 0; continue; }
        if (scancode & 0x80) { last_scancode = 0; repeat_guard = 0; continue; }
        scancode = keyboard_normalize(scancode);
        if (scancode == last_scancode && repeat_guard < 5) { ++repeat_guard; continue; }
        last_scancode = scancode;
        repeat_guard = 0;
        if (scancode == 0x02) { /* 1: SNAKE */
            static struct pgm_api api;
            api.version = 1;
            api.fb = fb;
            api.ticks = &pit_ticks;
            api.kbd_pop = api_kbd_pop;
            api.fill = fb_fill;
            api.rect = fb_rect;
            api.text = fb_text;
            api.text_uint = fb_text_uint;
            api.texload = texload_bmp;
            api.sprite = gfx_blit_texture;
            serial("NYKLIMA OS: launching SNAKE\n");
            cursor_hide(fb);
            int rc = pgm_run("SNAKE.ELF", &api);
            serial_printf("NYKLIMA OS: SNAKE exit rc=%d\n", rc);
            desktop_redraw(fb, pit_ticks);
            continue;
        }
        if (wm_key(scancode, pit_ticks)) {
            desktop_redraw(fb, pit_ticks);
        }
        thread_yield();
    }
}
