/* Оконный менеджер NYKLIMA OS: окна с заголовками, z-order,
   перетаскивание мышью, кнопки закрытия, taskbar, обои. */

#include <stdint.h>
#include <stddef.h>
#include <limine.h>
#include <fbdraw.h>
#include <fs.h>
#include <mem.h>
#include <gfx.h>
#include <paging.h>
#include <cpu.h>
#include <sched.h>
#include <wm.h>

extern volatile uint32_t demo_t1, demo_t2;

static struct wm_window wins[WM_MAX_WINDOWS];
static int next_z = 1;
static int drag_idx = -1, drag_dx = 0, drag_dy = 0;
static int prev_left = 0;
static int cur_mx = 0, cur_my = 0;
static int scr_w = 0, scr_h = 0;
static uint32_t *desktop_backbuffer = NULL;
static size_t backbuffer_pixels = 0;
static uint32_t *wallpaper_buf = NULL;

void wm_init(int screen_w, int screen_h) {
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) wins[i].used = 0;
    next_z = 1;
    drag_idx = -1;
    prev_left = 0;
    scr_w = screen_w;
    scr_h = screen_h;
    backbuffer_pixels = (size_t)screen_w * (size_t)screen_h;
    desktop_backbuffer = (uint32_t *)pmm_alloc_contig((backbuffer_pixels * 4 + 4095) / 4096);
    wallpaper_buf = (uint32_t *)pmm_alloc_contig((backbuffer_pixels * 4 + 4095) / 4096);

    /* Обои статичны — рендерим один раз в кэш, дальше только блит. */
    if (wallpaper_buf) {
        struct limine_framebuffer wfb = {0};
        wfb.address = wallpaper_buf;
        wfb.width = (uint64_t)screen_w;
        wfb.height = (uint64_t)screen_h;
        wfb.pitch = (uint64_t)screen_w * 4;
        wfb.bpp = 32;
        wfb.memory_model = 1;

        for (int y = 0; y < screen_h; ++y) {
            uint32_t r = 0x10 + ((uint32_t)y * 0x14) / (uint32_t)screen_h;
            uint32_t g = 0x16 + ((uint32_t)y * 0x0e) / (uint32_t)screen_h;
            uint32_t b = 0x26 + ((uint32_t)y * 0x22) / (uint32_t)screen_h;
            uint32_t c = (r << 16) | (g << 8) | b;
            uint32_t *row = wallpaper_buf + (size_t)y * (size_t)screen_w;
            for (int x = 0; x < screen_w; ++x) row[x] = c;
        }
        for (int y = 24; y < screen_h - WM_TASKBAR_H; y += 32)
            for (int x = 24; x < screen_w; x += 32)
                fb_fill(&wfb, (size_t)x, (size_t)y, 2, 2, FB_PANEL);

        fb_text(&wfb, 36, 28, "NYKLIMA OS", FB_CYAN, 3);
        fb_text(&wfb, 36, 62, "G1 DESKTOP  F FILES  I SYSINFO  G CUBE  S SETTINGS  ESC CLOSE  ENTER FOCUS", FB_MUTED, 1);
    }
}

struct wm_window *wm_open(int content, const char *title, int x, int y, int w, int h) {
    int slot = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (!wins[i].used) { slot = i; break; }
    if (slot < 0) return NULL;
    struct wm_window *win = &wins[slot];
    win->used = 1;
    win->content = content;
    win->selected = 0;
    win->scroll = 0;
    win->detail_size = 0;
    win->detail_name[0] = 0;
    int i = 0;
    for (; i < 13 && title && title[i]; ++i) win->title[i] = title[i];
    win->title[i] = 0;
    if (x + w > scr_w) x = scr_w - w;
    if (y + h > scr_h - WM_TASKBAR_H) y = scr_h - WM_TASKBAR_H - h;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    win->x = x;
    win->y = y;
    win->w = w;
    win->h = h;
    win->z = ++next_z;
    return win;
}

void wm_close(struct wm_window *win) {
    if (!win || !win->used) return;
    int idx = (int)(win - wins);
    win->used = 0;
    if (drag_idx == idx) drag_idx = -1;
}

void wm_toggle(int content, const char *title, int x, int y, int w, int h) {
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (wins[i].used && wins[i].content == content) {
            wm_close(&wins[i]);
            return;
        }
    wm_open(content, title, x, y, w, h);
}

struct wm_window *wm_focused(void) {
    struct wm_window *best = NULL;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (wins[i].used && (!best || wins[i].z > best->z)) best = &wins[i];
    return best;
}

int wm_has_cube(void) {
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (wins[i].used && wins[i].content == WM_CONTENT_CUBE) return 1;
    return 0;
}

struct wm_window *wm_cube_window(void) {
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (wins[i].used && wins[i].content == WM_CONTENT_CUBE) return &wins[i];
    return NULL;
}

static void draw_window(struct limine_framebuffer *fb, struct wm_window *w, uint32_t ticks);

void wm_repaint_window(struct limine_framebuffer *fb, struct wm_window *win, uint32_t ticks) {
    if (!fb || !fb->address || !win || !win->used) return;
    struct limine_framebuffer *real_fb = fb;
    struct limine_framebuffer back_fb;
    if (desktop_backbuffer && backbuffer_pixels >= fb->width * fb->height) {
        back_fb = *fb;
        back_fb.address = desktop_backbuffer;
        back_fb.pitch = fb->width * 4;
        fb = &back_fb;
    } else {
        wm_draw(real_fb, ticks); /* нет backbuffer — только полный кадр */
        return;
    }

    /* Само окно в backbuffer (его тело непрозрачно и перекрывает свой rect). */
    draw_window(fb, win, ticks);
    /* Окна с более высоким z, пересекающие наш rect, — восстановить поверх. */
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (!wins[i].used || &wins[i] == win) continue;
        if (wins[i].z <= win->z) continue;
        if (wins[i].x >= win->x + win->w + 4 || wins[i].y >= win->y + win->h + 4) continue;
        if (wins[i].x + wins[i].w <= win->x || wins[i].y + wins[i].h <= win->y) continue;
        draw_window(fb, &wins[i], ticks);
    }

    /* Блит только прямоугольника окна (с тенью 4px) в реальный framebuffer. */
    int x = win->x, y = win->y;
    int w = win->w + 4, h = win->h + 4;
    if (x < 0) x = 0;
    if (y < 0) y = 0;
    if (x + w > (int)fb->width) w = (int)fb->width - x;
    if (y + h > (int)fb->height) h = (int)fb->height - y;
    for (int row = 0; row < h; ++row) {
        uint32_t *src = desktop_backbuffer + (size_t)(y + row) * fb->width + x;
        uint32_t *dst = (uint32_t *)((uint8_t *)real_fb->address + (size_t)(y + row) * real_fb->pitch + (size_t)x * 4);
        for (int col = 0; col < w; ++col) dst[col] = src[col];
    }
}

static void raise(struct wm_window *win) { win->z = ++next_z; }

/* Индекс верхнего окна, в котором точка (mx,my), либо -1. */
static int hit_test(int mx, int my) {
    int best = -1;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (!wins[i].used) continue;
        if (mx < wins[i].x || my < wins[i].y) continue;
        if (mx >= wins[i].x + wins[i].w || my >= wins[i].y + wins[i].h) continue;
        if (best < 0 || wins[i].z > wins[best].z) best = i;
    }
    return best;
}

static void open_detail(int abs_index) {
    char names[FS_MAX_FILES][FS_NAME_MAX];
    size_t count = fs_list(names, FS_MAX_FILES);
    if (abs_index < 0 || abs_index >= (int)count) return;
    struct wm_window *w = wm_open(WM_CONTENT_DETAIL, names[abs_index],
                                  cur_mx + 10, cur_my + 10, 340, 240);
    if (!w) return;
    int j = 0;
    for (; j < 13 && names[abs_index][j]; ++j) w->detail_name[j] = names[abs_index][j];
    w->detail_name[j] = 0;
    fs_read(names[abs_index], w->detail_data, FS_DATA_MAX, &w->detail_size);
}

int wm_mouse(int mx, int my, int buttons) {
    cur_mx = mx;
    cur_my = my;
    int dirty = 0;
    int pressed = buttons & 1;
    int was = prev_left;
    prev_left = pressed;

    if (pressed && !was) {
        if (my >= scr_h - WM_TASKBAR_H) {
            /* Клик по кнопке taskbar: поднять окно из слота. */
            int slot = (mx - 8) / 132;
            int k = 0;
            for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
                if (!wins[i].used) continue;
                if (k == slot) { raise(&wins[i]); dirty = 1; break; }
                ++k;
            }
        } else {
            int idx = hit_test(mx, my);
            if (idx >= 0) {
                struct wm_window *w = &wins[idx];
                raise(w);
                dirty = 1;
                if (mx >= w->x + w->w - 17 && mx <= w->x + w->w - 4 &&
                    my >= w->y + 4 && my <= w->y + 17) {
                    wm_close(w);
                } else if (my <= w->y + 20) {
                    drag_idx = idx;
                    drag_dx = mx - w->x;
                    drag_dy = my - w->y;
                } else if (w->content == WM_CONTENT_FILES) {
                    int row = (my - (w->y + 42)) / 16;
                    if (row >= 0) {
                        size_t count = fs_list(NULL, 0);
                        int abs = row + w->scroll;
                        if (abs < (int)count) {
                            if (w->selected == abs) open_detail(abs);
                            else w->selected = abs;
                        }
                    }
                }
            }
        }
    } else if (!pressed && was) {
        drag_idx = -1;
    }

    if (drag_idx >= 0 && pressed && wins[drag_idx].used) {
        struct wm_window *w = &wins[drag_idx];
        int nx = mx - drag_dx, ny = my - drag_dy;
        if (nx < 0) nx = 0;
        if (ny < 0) ny = 0;
        if (nx > scr_w - w->w) nx = scr_w - w->w;
        if (ny > scr_h - WM_TASKBAR_H - w->h) ny = scr_h - WM_TASKBAR_H - w->h;
        if (nx != w->x || ny != w->y) { w->x = nx; w->y = ny; dirty = 1; }
    }
    return dirty;
}

int wm_key(uint8_t scancode, uint32_t ticks) {
    (void)ticks;
    switch (scancode) {
        case 0x21: /* F: файлы */
            wm_toggle(WM_CONTENT_FILES, "FILES", 70, 70, 300, 250);
            return 1;
        case 0x17: /* I: система */
            wm_toggle(WM_CONTENT_INFO, "SYSINFO", 640, 90, 280, 220);
            return 1;
        case 0x22: /* G: куб */
            wm_toggle(WM_CONTENT_CUBE, "CUBE G1", 420, 120, 246, 208);
            return 1;
        case 0x01: { /* Esc: закрыть активное окно */
            struct wm_window *f = wm_focused();
            if (f) { wm_close(f); return 1; }
            return 0;
        }
        case 0x1c: { /* Enter: цикл фокуса */
            struct wm_window *low = NULL;
            for (int i = 0; i < WM_MAX_WINDOWS; ++i)
                if (wins[i].used && (!low || wins[i].z < low->z)) low = &wins[i];
            if (low) { raise(low); return 1; }
            return 0;
        }
        case 0x1f: /* S: настройки системы */
            wm_toggle(WM_CONTENT_SETTINGS, "SETTINGS", 300, 70, 470, 560);
            return 1;
    }
    return 0;
}

/* --- отрисовка --- */

static void cpuid(uint32_t leaf, uint32_t *a, uint32_t *b, uint32_t *c, uint32_t *d) {
    __asm__ volatile("cpuid" : "=a"(*a), "=b"(*b), "=c"(*c), "=d"(*d) : "a"(leaf), "c"(0));
}

static void cpu_vendor(char out[13]) {
    uint32_t a, b, c, d;
    cpuid(0, &a, &b, &c, &d);
    uint32_t regs[3] = {b, d, c};
    int p = 0;
    for (int i = 0; i < 3; ++i)
        for (int sh = 0; sh < 32; sh += 8) out[p++] = (char)((regs[i] >> sh) & 0xff);
    out[12] = 0;
}

static void cpu_brand(char out[49]) {
    uint32_t a, b, c, d;
    cpuid(0x80000000, &a, &b, &c, &d);
    if (a < 0x80000004) {
        const char fb_[] = "X86-64 COMPATIBLE CPU";
        int i = 0;
        for (; fb_[i]; ++i) out[i] = fb_[i];
        out[i] = 0;
        return;
    }
    int p = 0;
    for (uint32_t leaf = 0x80000002; leaf <= 0x80000004; ++leaf) {
        cpuid(leaf, &a, &b, &c, &d);
        uint32_t regs[4] = {a, b, c, d};
        for (int i = 0; i < 4; ++i)
            for (int sh = 0; sh < 32; sh += 8)
                if (p < 48) out[p++] = (char)((regs[i] >> sh) & 0xff);
    }
    out[p] = 0;
    int start = 0;
    while (out[start] == ' ') ++start;
    if (start) {
        int q = 0;
        for (int i = start; out[i]; ++i) out[q++] = out[i];
        out[q] = 0;
    }
}

static void text_hex(struct limine_framebuffer *fb, size_t x, size_t y, uint64_t v, uint32_t color) {
    char buf[20];
    int i = 0;
    buf[i++] = '0';
    buf[i++] = 'x';
    int started = 0;
    for (int sh = 60; sh >= 0; sh -= 4) {
        uint8_t n = (uint8_t)((v >> sh) & 0xf);
        if (!started && sh > 0 && n == 0) continue;
        started = 1;
        buf[i++] = (char)(n < 10 ? '0' + n : 'a' + n - 10);
    }
    if (!started) buf[i++] = '0';
    buf[i] = 0;
    fb_text(fb, x, y, buf, color, 1);
}

static void text_kbmb(struct limine_framebuffer *fb, size_t x, size_t y, uint64_t kb, uint32_t color) {
    uint64_t mb = kb / 1024;
    if (mb) {
        fb_text_uint(fb, x, y, (uint32_t)mb, color, 1);
        fb_text(fb, x + 6 * 4, y, " MB", color, 1);
    } else {
        fb_text_uint(fb, x, y, (uint32_t)kb, color, 1);
        fb_text(fb, x + 6 * 4, y, " KB", color, 1);
    }
}

static void draw_settings(struct limine_framebuffer *fb, struct wm_window *w, uint32_t ticks) {
    int cx = w->x + 2, cy = w->y + 21;
    int cw = w->w - 4, ch = w->h - 23;
    fb_fill(fb, (size_t)cx, (size_t)cy, (size_t)cw, (size_t)ch, FB_DARK);

    const int lx = cx + 8;   /* колонка меток */
    const int vx = cx + 116; /* колонка значений */
    int y = cy + 6;
    char buf[52];

    fb_text(fb, (size_t)lx, (size_t)y, "SYSTEM", FB_CYAN, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "OS", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "NYKLIMA OS G1", FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "BUILD", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "001 DESKTOP", FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "BOOT", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "OWN UEFI LOADER", FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "UPTIME", FB_MUTED, 1);
    fb_text_uint(fb, (size_t)vx, (size_t)y, ticks / 100, FB_TEXT, 1);
    fb_text(fb, (size_t)vx + 6 * 4, (size_t)y, " S", FB_TEXT, 1);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "CPU", FB_CYAN, 1);
    y += 15;
    cpu_vendor(buf);
    fb_text(fb, (size_t)lx, (size_t)y, "VENDOR", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, buf, FB_TEXT, 1);
    y += 15;
    cpu_brand(buf);
    fb_text(fb, (size_t)lx, (size_t)y, "MODEL", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, buf, FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "CORES", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "1 VCPU", FB_TEXT, 1);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "MEMORY", FB_CYAN, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "RAM", FB_MUTED, 1);
    text_kbmb(fb, (size_t)vx, (size_t)y, pmm_total_pages() * 4, FB_TEXT);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "FREE", FB_MUTED, 1);
    text_kbmb(fb, (size_t)vx, (size_t)y, pmm_free_pages() * 4, FB_TEXT);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "HEAP", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "64 KB FREE-LIST", FB_TEXT, 1);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "STORAGE", FB_CYAN, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "DISK", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, fs_is_ram() ? "RAM FS" : "FAT16 ATA PIO", FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "SIZE", FB_MUTED, 1);
    if (fs_is_ram()) fb_text(fb, (size_t)vx, (size_t)y, "N/A", FB_TEXT, 1);
    else text_kbmb(fb, (size_t)vx, (size_t)y, fs_disk_kb(), FB_TEXT);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "FILES", FB_MUTED, 1);
    fb_text_uint(fb, (size_t)vx, (size_t)y, (uint32_t)fs_list(NULL, 0), FB_TEXT, 1);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "VIDEO", FB_CYAN, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "MODE", FB_MUTED, 1);
    fb_text_uint(fb, (size_t)vx, (size_t)y, (uint32_t)scr_w, FB_TEXT, 1);
    fb_text(fb, (size_t)vx + 6 * 4, (size_t)y, "x", FB_MUTED, 1);
    fb_text_uint(fb, (size_t)vx + 6 * 5, (size_t)y, (uint32_t)scr_h, FB_TEXT, 1);
    fb_text(fb, (size_t)vx + 6 * 9, (size_t)y, " 32BPP", FB_TEXT, 1);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "RENDER", FB_MUTED, 1);
    fb_text(fb, (size_t)vx, (size_t)y, "SOFTWARE 3D G1", FB_TEXT, 1);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "MEMORY MAP", FB_CYAN, 1);
    y += 15;
    uint64_t kphys = 0, kvirt = 0;
    paging_get_bases(&kphys, &kvirt);
    fb_text(fb, (size_t)lx, (size_t)y, "HHDM", FB_MUTED, 1);
    text_hex(fb, (size_t)vx, (size_t)y, mem_hhdm(), FB_TEXT);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "KPHYS", FB_MUTED, 1);
    text_hex(fb, (size_t)vx, (size_t)y, kphys, FB_TEXT);
    y += 15;
    fb_text(fb, (size_t)lx, (size_t)y, "KVIRT", FB_MUTED, 1);
    text_hex(fb, (size_t)vx, (size_t)y, kvirt, FB_TEXT);
    y += 20;

    fb_text(fb, (size_t)lx, (size_t)y, "CPU FEATURES", FB_CYAN, 1);
    y += 15;
    /* Компактно: имя + OK/- в три колонки. */
    static const char *names[9] = {"SSE2", "SSE4.2", "AVX", "AVX2", "FMA", "BMI2", "AVX-512", "XCR0", "FPU"};
    for (int row = 0; row < 3; ++row) {
        for (int colI = 0; colI < 3; ++colI) {
            int idx = row * 3 + colI;
            int has = 0;
            switch (idx) {
                case 0: has = 1; break;
                case 1: has = cpu_has_sse42(); break;
                case 2: has = cpu_has_avx(); break;
                case 3: has = cpu_has_avx2(); break;
                case 4: has = 0; break;
                case 5: has = cpu_has_bmi2(); break;
                case 6: has = cpu_has_avx512f(); break;
                case 7: has = (cpu_xcr0() & 7) == 7; break;
                case 8: has = 1; break;
            }
            int colx = lx + colI * 108;
            fb_text(fb, (size_t)colx, (size_t)y + row * 15, names[idx], FB_MUTED, 1);
            fb_text(fb, (size_t)colx + 48, (size_t)y + row * 15, has ? "+OK" : "--", has ? FB_GREEN : FB_MUTED, 1);
        }
    }
    y += 50;
    fb_text(fb, (size_t)lx, (size_t)y, "XCR0", FB_MUTED, 1);
    text_hex(fb, (size_t)vx, (size_t)y, cpu_xcr0(), FB_TEXT);
}

static void draw_window(struct limine_framebuffer *fb, struct wm_window *w, uint32_t ticks) {
    /* тень */
    fb_fill(fb, (size_t)w->x + 4, (size_t)w->y + 4, (size_t)w->w, (size_t)w->h, FB_DARK);
    /* корпус */
    fb_fill(fb, (size_t)w->x, (size_t)w->y, (size_t)w->w, (size_t)w->h, FB_PANEL);
    fb_rect(fb, (size_t)w->x, (size_t)w->y, (size_t)w->w, (size_t)w->h, FB_BORDER);
    /* заголовок */
    fb_fill(fb, (size_t)w->x + 2, (size_t)w->y + 2, (size_t)w->w - 4, 18, FB_BORDER);
    fb_text(fb, (size_t)w->x + 8, (size_t)w->y + 6, w->title, FB_TEXT, 1);
    /* кнопка закрытия */
    fb_fill(fb, (size_t)w->x + w->w - 17, (size_t)w->y + 4, 13, 13, FB_RED);
    fb_text(fb, (size_t)w->x + w->w - 14, (size_t)w->y + 6, "X", FB_DARK, 1);

    int cx = w->x + 2, cy = w->y + 21;
    int cw = w->w - 4, ch = w->h - 23;

    if (w->content == WM_CONTENT_FILES) {
        fb_fill(fb, (size_t)cx, (size_t)cy, (size_t)cw, (size_t)ch, FB_DARK);
        char names[FS_MAX_FILES][FS_NAME_MAX];
        size_t count = fs_list(names, FS_MAX_FILES);
        fb_text(fb, (size_t)cx + 6, (size_t)cy + 4, "NAME", FB_MUTED, 1);
        int visible = (ch - 26) / 16;
        if (visible < 1) visible = 1;
        if (visible > 10) visible = 10;
        if (w->selected < w->scroll) w->scroll = w->selected;
        if (w->selected >= w->scroll + visible) w->scroll = w->selected - visible + 1;
        if (w->scroll < 0) w->scroll = 0;
        for (int i = 0; i < visible; ++i) {
            int idx = w->scroll + i;
            if (idx >= (int)count) break;
            int ry = cy + 20 + i * 16;
            if (idx == w->selected)
                fb_fill(fb, (size_t)cx + 2, (size_t)ry - 2, (size_t)cw - 4, 14, FB_BORDER);
            fb_text(fb, (size_t)cx + 6, (size_t)ry, names[idx],
                    idx == w->selected ? FB_CYAN : FB_TEXT, 1);
        }
        fb_text(fb, (size_t)cx + 6, (size_t)cy + ch - 12, "CLICK SELECT CLICK2 OPEN", FB_MUTED, 1);
    } else if (w->content == WM_CONTENT_INFO) {
        fb_fill(fb, (size_t)cx, (size_t)cy, (size_t)cw, (size_t)ch, FB_DARK);
        int ly = cy + 8;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "NYKLIMA OS DESKTOP", FB_CYAN, 1);
        ly += 18;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "UPTIME", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, ticks / 100, FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "FREE PAGES", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, (uint32_t)pmm_free_pages(), FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "FILES", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, (uint32_t)fs_list(NULL, 0), FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "DISK", FB_MUTED, 1);
        fb_text(fb, (size_t)cx + 90, (size_t)ly, fs_is_ram() ? "RAM FS" : "FAT16", FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "MOUSE", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, (uint32_t)cur_mx, FB_TEXT, 1);
        fb_text(fb, (size_t)cx + 122, (size_t)ly, ":", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 130, (size_t)ly, (uint32_t)cur_my, FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "THREADS", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, (uint32_t)sched_thread_count(), FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "MT T1/T2", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, demo_t1, FB_TEXT, 1);
        fb_text(fb, (size_t)cx + 122, (size_t)ly, "/", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 130, (size_t)ly, demo_t2, FB_TEXT, 1);
        ly += 16;
        fb_text(fb, (size_t)cx + 8, (size_t)ly, "RES", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 90, (size_t)ly, (uint32_t)scr_w, FB_TEXT, 1);
        fb_text(fb, (size_t)cx + 122, (size_t)ly, "x", FB_MUTED, 1);
        fb_text_uint(fb, (size_t)cx + 130, (size_t)ly, (uint32_t)scr_h, FB_TEXT, 1);
    } else if (w->content == WM_CONTENT_CUBE) {
        fb_fill(fb, (size_t)cx, (size_t)cy, (size_t)cw, (size_t)ch, FB_DARK);
        gfx_render_cube_fb(fb, cx, cy, ticks);
    } else if (w->content == WM_CONTENT_SETTINGS) {
        draw_settings(fb, w, ticks);
    } else if (w->content == WM_CONTENT_DETAIL) {
        fb_fill(fb, (size_t)cx, (size_t)cy, (size_t)cw, (size_t)ch, FB_DARK);
        if (w->detail_size == 0) {
            fb_text(fb, (size_t)cx + 8, (size_t)cy + 8, "EMPTY FILE", FB_MUTED, 1);
        } else {
            int chars = (cw - 16) / 6;
            if (chars < 1) chars = 1;
            if (chars > 120) chars = 120;
            int ly = cy + 8;
            for (size_t pos = 0; pos < w->detail_size && ly < cy + ch - 12; pos += (size_t)chars) {
                size_t len = w->detail_size - pos;
                if (len > (size_t)chars) len = (size_t)chars;
                char line[121];
                for (size_t i = 0; i < len; ++i) line[i] = (char)w->detail_data[pos + i];
                line[len] = 0;
                fb_text(fb, (size_t)cx + 8, (size_t)ly, line, FB_TEXT, 1);
                ly += 10;
            }
        }
    }
}

void wm_draw(struct limine_framebuffer *fb, uint32_t ticks) {
    if (!fb || !fb->address) return;
    struct limine_framebuffer *real_fb = fb;
    struct limine_framebuffer back_fb;
    if (desktop_backbuffer && backbuffer_pixels >= fb->width * fb->height) {
        back_fb = *fb;
        back_fb.address = desktop_backbuffer;
        back_fb.pitch = fb->width * 4;
        fb = &back_fb;
    }
    if (scr_w != (int)fb->width || scr_h != (int)fb->height) {
        scr_w = (int)fb->width;
        scr_h = (int)fb->height;
    }

    /* Обои: блит из кэша (рендерились один раз в wm_init). */
    if (wallpaper_buf) {
        for (size_t y = 0; y < fb->height; ++y) {
            uint32_t *src = wallpaper_buf + y * fb->width;
            uint32_t *dst = (uint32_t *)((uint8_t *)fb->address + y * fb->pitch);
            for (size_t x = 0; x < fb->width; ++x) dst[x] = src[x];
        }
    } else {
        for (size_t y = 0; y < fb->height; ++y) {
            uint32_t r = 0x10 + (y * 0x14) / fb->height;
            uint32_t g = 0x16 + (y * 0x0e) / fb->height;
            uint32_t b = 0x26 + (y * 0x22) / fb->height;
            uint32_t c = (r << 16) | (g << 8) | b;
            uint32_t *row = (uint32_t *)((uint8_t *)fb->address + y * fb->pitch);
            for (size_t x = 0; x < fb->width; ++x) row[x] = c;
        }
        for (size_t y = 24; y < fb->height - WM_TASKBAR_H; y += 32)
            for (size_t x = 24; x < fb->width; x += 32)
                fb_fill(fb, x, y, 2, 2, FB_PANEL);

        fb_text(fb, 36, 28, "NYKLIMA OS", FB_CYAN, 3);
        fb_text(fb, 36, 62, "G1 DESKTOP  F FILES  I SYSINFO  G CUBE  S SETTINGS  ESC CLOSE  ENTER FOCUS", FB_MUTED, 1);
    }

    /* Окна по возрастанию z. */
    int order[WM_MAX_WINDOWS];
    int n = 0;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i)
        if (wins[i].used) order[n++] = i;
    for (int i = 0; i < n; ++i)
        for (int j = i + 1; j < n; ++j)
            if (wins[order[j]].z < wins[order[i]].z) {
                int t = order[i]; order[i] = order[j]; order[j] = t;
            }
    struct wm_window *focus = wm_focused();
    for (int i = 0; i < n; ++i)
        draw_window(fb, &wins[order[i]], ticks);

    /* Taskbar. */
    size_t ty = fb->height - WM_TASKBAR_H;
    fb_fill(fb, 0, ty, fb->width, WM_TASKBAR_H, FB_PANEL);
    fb_rect(fb, 0, ty, fb->width, WM_TASKBAR_H, FB_BORDER);
    int sx = 8;
    for (int i = 0; i < WM_MAX_WINDOWS; ++i) {
        if (!wins[i].used) continue;
        int focused = &wins[i] == focus;
        fb_fill(fb, (size_t)sx, ty + 4, 124, 20, focused ? FB_BORDER : FB_DARK);
        fb_text(fb, (size_t)sx + 4, ty + 9, wins[i].title, focused ? FB_CYAN : FB_MUTED, 1);
        sx += 132;
    }
    fb_text(fb, (size_t)fb->width - 120, ty + 9, "UP", FB_MUTED, 1);
    fb_text_uint(fb, (size_t)fb->width - 104, ty + 9, ticks / 100, FB_TEXT, 1);

    /* Один последовательный blit готового кадра уменьшает tearing и не
       показывает пользователю промежуточную очистку/отрисовку окон. */
    if (fb != real_fb) {
        for (size_t y = 0; y < real_fb->height; ++y) {
            uint32_t *src = desktop_backbuffer + y * real_fb->width;
            uint32_t *dst = (uint32_t *)((uint8_t *)real_fb->address + y * real_fb->pitch);
            for (size_t x = 0; x < real_fb->width; ++x) dst[x] = src[x];
        }
    }
}
