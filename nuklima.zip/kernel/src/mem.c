#include <mem.h>

#define PAGE_SIZE 4096

static uint64_t g_hhdm = 0;

/* Bitmap PMM: 1 бит на страницу 4 КБ. Бит=1 — страница занята.
   Карта живёт в начале первого usable-региона. */
static uint8_t *bitmap = NULL;      /* виртуальный адрес карты (через HHDM) */
static uint64_t bitmap_bits = 0;    /* сколько страниц покрывает карта */
static uint64_t region_base = 0;    /* физический базис региона */
static uint64_t region_pages = 0;   /* страниц в регионе */
static uint64_t free_hint = 0;      /* страница поиска с последнего успеха */

/* Free-list heap: блок { size, used } перед каждым выделением. */
struct heap_block {
    size_t size;   /* полезный размер блока */
    size_t used;   /* 0 = свободен */
};

static uint8_t *heap_start = NULL;
static size_t heap_len = 0;

static size_t align_up(size_t v, size_t a) { return (v + a - 1) & ~(a - 1); }

static uint64_t bitmap_reserved_pages(void) {
    return align_up((bitmap_bits + 7) / 8, PAGE_SIZE) / PAGE_SIZE;
}

/* Отметить диапазон страниц занятым/свободным в bitmap. */
static void mark_range(uint64_t page_start, uint64_t pages, int used) {
    for (uint64_t p = page_start; p < page_start + pages && p < region_pages; ++p) {
        uint64_t byte = p >> 3;
        uint8_t mask = (uint8_t)(1u << (p & 7));
        if (used) bitmap[byte] |= mask;
        else bitmap[byte] &= (uint8_t)~mask;
    }
}

void pmm_init(uint64_t hhdm_offset, struct limine_memmap_response *memmap,
              uint64_t kernel_phys_base, uint64_t kernel_phys_end) {
    g_hhdm = hhdm_offset;
    bitmap = NULL;
    bitmap_bits = 0;
    region_base = 0;
    region_pages = 0;
    free_hint = 0;
    heap_start = NULL;
    heap_len = 0;

    if (!memmap) return;

    /* Выбрать наибольший usable-регион выше 1 МБ, исключив ядро. */
    uint64_t best_base = 0, best_len = 0;
    for (uint64_t i = 0; i < memmap->entry_count; ++i) {
        struct limine_memmap_entry *e = memmap->entries[i];
        if (!e || e->type != LIMINE_MEMMAP_USABLE) continue;
        if (e->base < 0x100000) continue;
        uint64_t lo = e->base, hi = e->base + e->length;
        if (kernel_phys_end > lo && kernel_phys_base < hi) {
            if (kernel_phys_base <= lo) lo = kernel_phys_end;
            else if (kernel_phys_end >= hi) hi = kernel_phys_base;
            else {
                if (kernel_phys_base - lo >= hi - kernel_phys_end) hi = kernel_phys_base;
                else lo = kernel_phys_end;
            }
        }
        if (hi <= lo) continue;
        if (hi - lo > best_len) { best_len = hi - lo; best_base = lo; }
    }

    if (best_len < 256 * 1024) return;

    region_base = best_base;
    region_pages = best_len / PAGE_SIZE;
    bitmap_bits = region_pages;

    uint64_t bitmap_bytes = (bitmap_bits + 7) / 8;
    bitmap = (uint8_t *)(g_hhdm + region_base);
    /* RAM под карту не обнулена никем (UEFI/прошивка оставляют мусор):
       без memset случайные биты выдают чужие страницы за «свободные» или
       наоборот навсегда «занятые». */
    for (uint64_t i = 0; i < bitmap_bytes; ++i) bitmap[i] = 0;
    /* Карта выровнена на 4 КБ; страницы под карту сразу заняты. */
    uint64_t map_pages = align_up(bitmap_bytes, PAGE_SIZE) / PAGE_SIZE;
    mark_range(0, map_pages, 1);
    free_hint = map_pages;
}

void *pmm_alloc(void) {
    if (!bitmap) return NULL;
    for (uint64_t p = free_hint; p < region_pages; ++p) {
        uint64_t byte = p >> 3;
        if (bitmap[byte] == 0xff) { p += 7; continue; }
        uint8_t mask = (uint8_t)(1u << (p & 7));
        if (!(bitmap[byte] & mask)) {
            bitmap[byte] |= mask;
            free_hint = p + 1;
            return (void *)(g_hhdm + region_base + p * PAGE_SIZE);
        }
    }
    for (uint64_t p = 0; p < free_hint; ++p) {
        uint64_t byte = p >> 3;
        if (bitmap[byte] == 0xff) { p += 7; continue; }
        uint8_t mask = (uint8_t)(1u << (p & 7));
        if (!(bitmap[byte] & mask)) {
            bitmap[byte] |= mask;
            free_hint = p + 1;
            return (void *)(g_hhdm + region_base + p * PAGE_SIZE);
        }
    }
    return NULL;
}

/* Выделить подряд идущие страницы (для кадровых/Z-буферов рендера). */
void *pmm_alloc_contig(uint64_t pages) {
    if (!bitmap || !pages) return NULL;
    uint64_t run = 0, start = 0;
    for (uint64_t p = 0; p < region_pages; ++p) {
        uint64_t byte = p >> 3;
        uint8_t mask = (uint8_t)(1u << (p & 7));
        if (!(bitmap[byte] & mask)) {
            if (!run) start = p;
            if (++run >= pages) {
                mark_range(start, pages, 1);
                return (void *)(g_hhdm + region_base + start * PAGE_SIZE);
            }
        } else {
            run = 0;
        }
    }
    return NULL;
}

void pmm_free(void *page) {
    pmm_free_contig(page, 1);
}

void pmm_free_contig(void *page, uint64_t pages) {
    if (!bitmap || !page || !pages) return;
    uint64_t addr = (uint64_t)page;
    if (addr < g_hhdm + region_base) return;
    uint64_t p = (addr - g_hhdm - region_base) / PAGE_SIZE;
    if (p >= region_pages) return;
    uint64_t reserved = bitmap_reserved_pages();
    uint64_t end = p + pages;
    if (end > region_pages) end = region_pages;
    for (uint64_t i = p; i < end; ++i) {
        if (i < reserved) continue; /* карта не освобождается */
        bitmap[i >> 3] &= (uint8_t)~(1u << (i & 7));
        if (i < free_hint) free_hint = i;
    }
}

static void heap_coalesce(void) {
    if (!heap_start) return;
    uint8_t *p = heap_start;
    uint8_t *end = heap_start + heap_len;
    while (p + sizeof(struct heap_block) <= end) {
        struct heap_block *b = (struct heap_block *)p;
        uint8_t *next = p + sizeof(struct heap_block) + align_up(b->size, 16);
        if (!b->used && next + sizeof(struct heap_block) <= end) {
            struct heap_block *n = (struct heap_block *)next;
            if (!n->used) {
                b->size = align_up(b->size, 16) + sizeof(struct heap_block) + n->size;
                continue;
            }
        }
        p = next;
    }
}

void *kmalloc(size_t size) {
    if (!heap_start || !size) return NULL;
    size = align_up(size, 16);
    uint8_t *p = heap_start;
    uint8_t *end = heap_start + heap_len;
    while (p + sizeof(struct heap_block) <= end) {
        struct heap_block *b = (struct heap_block *)p;
        if (b->used == 0 && b->size >= size) {
            /* Расколоть, если остаток вмещает ещё один блок. */
            if (b->size >= size + sizeof(struct heap_block) + 16) {
                struct heap_block *rest = (struct heap_block *)(p + sizeof(struct heap_block) + size);
                rest->size = b->size - size - sizeof(struct heap_block);
                rest->used = 0;
                b->size = size;
            }
            b->used = 1;
            return p + sizeof(struct heap_block);
        }
        p += sizeof(struct heap_block) + align_up(b->size, 16);
    }
    return NULL;
}

void heap_attach(void *start, size_t length) {
    if (!start || length < PAGE_SIZE) return;
    heap_start = (uint8_t *)start;
    heap_len = align_up(length, PAGE_SIZE);
    struct heap_block *b = (struct heap_block *)heap_start;
    b->size = heap_len - sizeof(struct heap_block);
    b->used = 0;
}

void kfree(void *ptr) {
    if (!ptr || !heap_start) return;
    struct heap_block *b = (struct heap_block *)((uint8_t *)ptr - sizeof(struct heap_block));
    if ((uint8_t *)b < heap_start || (uint8_t *)b >= heap_start + heap_len) return;
    b->used = 0;
    heap_coalesce();
}

uint64_t pmm_free_pages(void) {
    if (!bitmap) return 0;
    uint64_t free_pages = 0;
    for (uint64_t p = 0; p < region_pages; ++p) {
        uint64_t byte = p >> 3;
        uint8_t mask = (uint8_t)(1u << (p & 7));
        if (!(bitmap[byte] & mask)) ++free_pages;
    }
    return free_pages;
}

uint64_t pmm_total_pages(void) {
    return region_pages;
}

uint64_t mem_hhdm(void) {
    return g_hhdm;
}