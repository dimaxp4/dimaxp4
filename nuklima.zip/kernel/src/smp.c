/* SMP: ACPI MADT (список AP-ядер), LAPIC, INIT/SIPI запуск AP,
   вход AP в C (ap_entry), per-CPU онлайн-статус.
   Трамплин (16->64 бит) копируется на физический 0x8000. */

#include <stdint.h>
#include <stddef.h>
#include <limine.h>
#include <mem.h>
#include <cpu.h>
#include <sched.h>
#include <smp.h>

#if !defined(_MSC_VER)

#define LAPIC_BASE 0xfee00000u
#define LAPIC_ID   0x20
#define LAPIC_EOI  0x0b0
#define LAPIC_ICR_LO 0x300
#define LAPIC_ICR_HI 0x310
#define IOAPIC_REGSEL 0x00
#define IOAPIC_WINDOW 0x10
#define IOAPIC_REDTBL 0x10

extern const uint8_t trampoline_blob[];
extern const uint8_t trampoline_blob_end[];

static volatile uint32_t *lapic = NULL;
static volatile uint32_t *ioapic = NULL;
static int smp_initialized = 0;
static int online_cpus = 1;
static int lapic_to_idx[256];
static uint32_t isa_gsi[16];

static uint32_t lapic_read(uint32_t reg) { return lapic[reg / 4]; }
static void lapic_write(uint32_t reg, uint32_t v) { lapic[reg / 4] = v; }
static void ioapic_write(uint32_t reg, uint32_t value) {
    ioapic[IOAPIC_REGSEL / 4] = reg;
    ioapic[IOAPIC_WINDOW / 4] = value;
}

static int lapic_self_id(void) { return (int)((lapic_read(LAPIC_ID) >> 24) & 0xff); }

int smp_up(void) { return smp_initialized; }

int smp_self_index(void) {
    if (!smp_initialized) return 0;
    return lapic_to_idx[lapic_self_id()];
}

int smp_online_count(void) { return online_cpus; }
int smp_ioapic_ready(void) { return ioapic != NULL; }
void smp_irq_eoi(void) { if (lapic) lapic_write(LAPIC_EOI, 0); }

/* --- ACPI --- */
struct acpi_rsdp {
    char sig[8]; uint8_t csum; char oem[6]; uint8_t rev;
    uint32_t rsdt; uint32_t len; uint64_t xsdt;
};

struct acpi_header {
    char sig[4]; uint32_t len; uint8_t rev, csum; char oem[6];
    char table[8]; uint32_t oemrev; uint32_t creator; uint32_t creatorrev;
};

static int sig_eq(const char *a, const char *b) {
    for (int i = 0; i < 4; ++i) if (a[i] != b[i]) return 0;
    return 1;
}

static void smp_log(const char *s) {
    while (*s) {
        uint8_t lsr;
        do { __asm__ volatile("inb %1, %0" : "=a"(lsr) : "Nd"((uint16_t)0x3fd)); } while (!(lsr & 0x20));
        __asm__ volatile("outb %0, %1" : : "a"((uint8_t)*s), "Nd"((uint16_t)0x3f8));
        ++s;
    }
}

static void smp_log_hex(uint64_t v) {
    char buf[20]; int n = 0;
    buf[n++] = '0'; buf[n++] = 'x';
    int started = 0;
    for (int sh = 60; sh >= 0; sh -= 4) {
        uint8_t d = (v >> sh) & 0xf;
        if (!started && sh > 0 && d == 0) continue;
        started = 1;
        buf[n++] = d < 10 ? '0' + d : 'a' + d - 10;
    }
    if (!started) buf[n++] = '0';
    buf[n] = 0;
    smp_log(buf);
}

static void ioapic_route(uint32_t gsi, uint8_t vector, uint16_t flags) {
    /* MADT ISO flags: bit1 polarity low, bit3 level trigger. ISA defaults
       to active-high edge; use overrides only when firmware specifies them. */
    uint32_t low = vector;
    if (flags & 0x0002) low |= 1u << 13;
    if (flags & 0x0008) low |= 1u << 15;
    ioapic_write(IOAPIC_REDTBL + gsi * 2 + 1, 0); /* BSP LAPIC ID = 0 */
    ioapic_write(IOAPIC_REDTBL + gsi * 2, low);
}

static uint64_t find_madt(const struct acpi_rsdp *rp) {
    int use_xsdt = rp->rev >= 2 && rp->xsdt;
    uint64_t root_phys = use_xsdt ? rp->xsdt : (uint64_t)rp->rsdt;
    smp_log("NYKLIMA OS: ACPI root_phys=");
    smp_log_hex(root_phys);
    smp_log(" use_xsdt=");
    smp_log_hex(use_xsdt);
    smp_log("\n");
    
    const struct acpi_header *h =
        (const struct acpi_header *)(mem_hhdm() + root_phys);
    uint32_t len = h->len;
    uint32_t count = (len - 36) / (use_xsdt ? 8 : 4);
    smp_log("NYKLIMA OS: ACPI entries count=");
    smp_log_hex(count);
    smp_log("\n");
    
    for (uint32_t i = 0; i < count && i < 64; ++i) {
        uint64_t ent_phys = use_xsdt
            ? *(volatile uint64_t *)(mem_hhdm() + root_phys + 36 + i * 8)
            : (uint64_t)*(volatile uint32_t *)(mem_hhdm() + root_phys + 36 + i * 4);
        if (!ent_phys) continue;
        const struct acpi_header *t = (const struct acpi_header *)(mem_hhdm() + ent_phys);
        char sig[5]; sig[0] = t->sig[0]; sig[1] = t->sig[1]; sig[2] = t->sig[2]; sig[3] = t->sig[3]; sig[4] = 0;
        smp_log("NYKLIMA OS: ACPI table ");
        smp_log(sig);
        smp_log("\n");
        if (sig_eq(t->sig, "APIC")) return ent_phys;
    }
    return 0;
}

/* Задержка INIT/SIPI не зависит от PIT: после включения IOAPIC маршрут
   legacy IRQ0 может отличаться, поэтому ожидание pit_ticks здесь способно
   навсегда заблокировать запуск всех AP. */
static void wait_ticks(uint32_t n) {
    for (uint32_t i = 0; i < n * 10000u; ++i)
        __asm__ volatile("pause");
}

static volatile int ap_booted[SMP_MAX_CPUS];

/* Вход AP после трамплина (64-бит). arg — lapic id. */
void ap_entry(uint64_t lapic_id) {
    cpu_init(); /* CR4/XCR0 — на каждом ядре свои */
    int idx = lapic_to_idx[(int)lapic_id];
    if (idx <= 0 || idx >= SMP_MAX_CPUS) idx = 1;
    /* Этап bootstrap: AP подтверждает готовность, но ещё не исполняет общую
       очередь потоков. Для этого сначала нужны APIC timer, IPI и per-CPU
       очереди, иначе AP может украсть поток BSP до полной инициализации ОС. */
    sched_ap_online(idx);
    ap_booted[idx] = 1;
    for (;;) __asm__ volatile("hlt");
}

int smp_init(struct limine_rsdp_response *rsdp,
             struct limine_memmap_response *memmap,
             uint64_t pml4_phys) {
    (void)memmap;
    smp_log("NYKLIMA OS: smp_init start\n");
    if (!rsdp || !rsdp->address) { smp_log("NYKLIMA OS: no RSDP\n"); return 0; }
    /* Загрузчик отдаёт виртуальный (identity) адрес, повторно HHDM не добавляем */
    const struct acpi_rsdp *rp = (const struct acpi_rsdp *)rsdp->address;
    if (rp->sig[0] != 'R' || rp->sig[1] != 'S') { smp_log("NYKLIMA OS: bad RSDP sig\n"); return 0; }

    uint64_t madt_phys = find_madt(rp);
    if (!madt_phys) { smp_log("NYKLIMA OS: MADT not found\n"); return 0; }
    smp_log("NYKLIMA OS: MADT found\n");
    const struct acpi_header *madt = (const struct acpi_header *)(mem_hhdm() + madt_phys);
    uint64_t lapic_base = *(volatile uint32_t *)(mem_hhdm() + madt_phys + 36);

    /* ISA IRQ по умолчанию совпадает с GSI; MADT type 2 может его переопределить. */
    for (int i = 0; i < 16; ++i) isa_gsi[i] = (uint32_t)i;
    uint16_t isa_flags[16] = {0};
    uint64_t ioapic_phys = 0;
    uint64_t madt_entry = madt_phys + 44;
    uint64_t madt_end = madt_phys + madt->len;
    while (madt_entry + 2 <= madt_end) {
        uint8_t type = *(volatile uint8_t *)(mem_hhdm() + madt_entry);
        uint8_t len = *(volatile uint8_t *)(mem_hhdm() + madt_entry + 1);
        if (len < 2 || madt_entry + len > madt_end) break;
        if (type == 1 && len >= 12 && !ioapic_phys)
            ioapic_phys = *(volatile uint32_t *)(mem_hhdm() + madt_entry + 4);
        if (type == 2 && len >= 10) {
            uint8_t source = *(volatile uint8_t *)(mem_hhdm() + madt_entry + 3);
            if (source < 16) {
                isa_gsi[source] = *(volatile uint32_t *)(mem_hhdm() + madt_entry + 4);
                isa_flags[source] = *(volatile uint16_t *)(mem_hhdm() + madt_entry + 8);
            }
        }
        madt_entry += len;
    }

    /* Собираем AP-ядра: LAPIC-записи MADT (type 0, len 8, flags bit0). */
    int ap_ids[SMP_MAX_CPUS];
    int ap_count = 0;
    uint64_t ent = madt_phys + 44;
    uint64_t end = madt_phys + madt->len;
    /* Сначала читаем до SMP_MAX_CPUS записей, поскольку одна из них — BSP. */
    while (ent + 2 <= end && ap_count < SMP_MAX_CPUS) {
        uint8_t type = *(volatile uint8_t *)(mem_hhdm() + ent);
        uint8_t elen = *(volatile uint8_t *)(mem_hhdm() + ent + 1);
        if (!elen) break;
        if (type == 0 && elen >= 8) {
            uint8_t apic_id = *(volatile uint8_t *)(mem_hhdm() + ent + 3);
            uint32_t flags = *(volatile uint32_t *)(mem_hhdm() + ent + 4);
            if (flags & 1) ap_ids[ap_count++] = apic_id;
        }
        ent += elen;
    }

    /* LAPIC находится в физической памяти, доступной через HHDM. */
    lapic = (volatile uint32_t *)(mem_hhdm() + lapic_base);
    if (ioapic_phys) ioapic = (volatile uint32_t *)(mem_hhdm() + ioapic_phys);
    smp_log("NYKLIMA OS: LAPIC mapped\n");
    int bsp_id = lapic_self_id();
    smp_log("NYKLIMA OS: BSP LAPIC ID=");
    smp_log_hex((uint64_t)bsp_id);
    smp_log("\n");

    /* MADT содержит и BSP. Удаляем его: SIPI отправляются только AP. */
    int ap_write = 0;
    for (int i = 0; i < ap_count; ++i)
        if (ap_ids[i] != bsp_id) ap_ids[ap_write++] = ap_ids[i];
    ap_count = ap_write;
    smp_log("NYKLIMA OS: AP count=");
    smp_log_hex((uint64_t)ap_count);
    smp_log("\n");

    /* Карта LAPIC ID -> индекс CPU (BSP = 0). */
    for (int i = 0; i < 256; ++i) lapic_to_idx[i] = -1;
    lapic_to_idx[bsp_id] = 0;
    for (int i = 0; i < ap_count; ++i) lapic_to_idx[ap_ids[i]] = i + 1;

    /* Проверить, что 0x8000..0x9000 — usable по карте памяти загрузчика. */
    int low_ok = 0;
    if (memmap) {
        for (uint64_t i = 0; i < memmap->entry_count; ++i) {
            struct limine_memmap_entry *e = memmap->entries[i];
            if (e && e->type == LIMINE_MEMMAP_USABLE &&
                e->base <= 0x8000 && e->base + e->length >= 0x9000) { low_ok = 1; break; }
        }
    }
    if (!low_ok) { smp_log("NYKLIMA OS: trampoline page unavailable\n"); return 0; }
    smp_log("NYKLIMA OS: trampoline page ready\n");

    /* Скопировать трамплин на 0x8000 и заполнить данные. */
    uint64_t blob_len = (uint64_t)(trampoline_blob_end - trampoline_blob);
    volatile uint8_t *dst = (volatile uint8_t *)0x8000;
    for (uint64_t i = 0; i < blob_len; ++i) dst[i] = trampoline_blob[i];
    *(volatile uint64_t *)(0x8000 + 0x140) = pml4_phys;
    *(volatile uint64_t *)(0x8000 + 0x1e0) = (uint64_t)ap_entry;
    /* Стеки адресуются по LAPIC ID в трамплине (слоты 0..15) — больший ID
       писал бы за границы блоба в чужую память, поэтому такие AP пропускаем. */
    for (int a = 0; a < ap_count; ++a) {
        if (ap_ids[a] >= 16) {
            smp_log("NYKLIMA OS: AP LAPIC ID>=16 unsupported, skipped\n");
            continue;
        }
        uint8_t *st = (uint8_t *)pmm_alloc_contig(16); /* 64 КБ стек AP */
        if (!st) return 0;
        uint64_t top = (uint64_t)st + 16 * 4096;
        *(volatile uint64_t *)(0x8000 + 0x160 + (uint64_t)ap_ids[a] * 8) = top;
    }
    smp_log("NYKLIMA OS: AP stacks ready\n");

    /* smp_self_index() должен выдавать верный CPU уже в ap_entry/scheduler. */
    smp_initialized = 1;

    /* INIT-SIPI и ожидание запускаем последовательно: trampoline общий, а
       неуспешный AP не должен нарушать запуск следующих ядер. */
    for (int a = 0; a < ap_count; ++a) {
        if (ap_ids[a] >= 16) continue; /* стек не назначен — не запускаем */
        uint32_t id = (uint32_t)ap_ids[a];
        int idx = a + 1;
        smp_log("NYKLIMA OS: starting AP ");
        smp_log_hex(id);
        smp_log("\n");
        lapic_write(LAPIC_ICR_HI, id << 24);
        lapic_write(LAPIC_ICR_LO, 0x00004500); /* INIT, assert */
        wait_ticks(2);
        lapic_write(LAPIC_ICR_LO, 0x00004600); /* INIT, deassert */
        wait_ticks(1);
        lapic_write(LAPIC_ICR_HI, id << 24);
        lapic_write(LAPIC_ICR_LO, 0x00000608); /* SIPI, вектор 0x08 */
        wait_ticks(2);
        lapic_write(LAPIC_ICR_LO, 0x00000608); /* второй SIPI */
        for (int wait = 0; wait < 32 && !ap_booted[idx]; ++wait) wait_ticks(1);
    }
    online_cpus = 1;
    for (int a = 0; a < SMP_MAX_CPUS; ++a) if (ap_booted[a]) ++online_cpus;

    /* Legacy input и PIT идут через IOAPIC, когда он опубликован в MADT. */
    if (ioapic) {
        ioapic_route(isa_gsi[0], 32, isa_flags[0]);   /* PIT */
        ioapic_route(isa_gsi[1], 33, isa_flags[1]);   /* PS/2 keyboard */
        ioapic_route(isa_gsi[12], 44, isa_flags[12]); /* PS/2 mouse */
        smp_log("NYKLIMA OS: IOAPIC input routes ready\n");
    }
    return online_cpus - 1;
}

/* Заглушки для MSC-сборки */
#else
int smp_init(struct limine_rsdp_response *rsdp, struct limine_memmap_response *m, uint64_t p) {
    (void)rsdp; (void)m; (void)p; return 0;
}
int smp_up(void) { return 0; }
int smp_self_index(void) { return 0; }
int smp_online_count(void) { return 1; }
#endif
